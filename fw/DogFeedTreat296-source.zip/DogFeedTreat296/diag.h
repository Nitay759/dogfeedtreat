extern bool rmOn; extern volatile int rmPollCode; extern volatile uint16_t rmApiToday;   // v2.9.9: defined in remote.h (included after this file)
// ---------------------------------------------------------------- v2.9.6 help: "למה משהו לא עובד" diagnostics
// GET /api/diag            -> everything the board can know or infer about its parts, as plain numbers (the page explains them).
// GET /api/diag?cam=1      -> also asks the ESP32-CAM for one photo (skipped while the motor runs: it blocks up to ~4.5 s).
// READ-ONLY: watches pins and counters, never moves, beeps, saves or changes a setting. Does not open the self-test
// (so barks keep counting while this page is open).
uint32_t dgIrBlockSinceMs = 0;      // IR beam blocked continuously since (0 = clear now)
uint32_t dgPirHighSinceMs = 0;      // indoor PIR output HIGH continuously since
uint32_t dgPirRises = 0;            // indoor PIR rising edges since power on (after its 60 s warm-up)
bool     dgPirPrev = false;
uint32_t dgMicWinPrev = 0, dgMicZeroPrev = 0, dgMicSamePrev = 0;   // self-test counters at the last snapshot
int32_t  dgMicWin1 = -1, dgMicZero1 = 0, dgMicSame1 = 0;             // windows in the last ~60 s (-1 = not measured yet)
uint32_t dgOutPirRing[11];          // outdoor PIR total, one sample a minute -> motion packets in the last 10 min
uint8_t  dgRingN = 0, dgRingI = 0;
uint32_t dgOutBadPrev = 0; int32_t dgOutBad1 = 0;                   // packets with the wrong token in the last minute

void diagTick() {
  static uint32_t lastS = 0, lastM = 0;
  uint32_t now = millis();
  if (now - lastS >= 1000) {
    lastS = now;
    bool blocked = digitalRead(PIN_IR) == LOW;
    if (blocked) { if (!dgIrBlockSinceMs) dgIrBlockSinceMs = now ? now : 1; } else dgIrBlockSinceMs = 0;
    bool pir = digitalRead(PIN_PIR);
    if (pir) { if (!dgPirHighSinceMs) dgPirHighSinceMs = now ? now : 1; } else dgPirHighSinceMs = 0;
    if (pir && !dgPirPrev && now > 60000) dgPirRises++;
    dgPirPrev = pir;
  }
  if (now - lastM >= 60000) {
    lastM = now;
    // the /check page may reset the self-test counters: a counter that went down counts from zero
    dgMicWin1  = stMicWin  >= dgMicWinPrev  ? (int32_t)(stMicWin  - dgMicWinPrev)  : (int32_t)stMicWin;
    dgMicZero1 = stMicZeroWin >= dgMicZeroPrev ? (int32_t)(stMicZeroWin - dgMicZeroPrev) : (int32_t)stMicZeroWin;
    dgMicSame1 = stMicSameWin >= dgMicSamePrev ? (int32_t)(stMicSameWin - dgMicSamePrev) : (int32_t)stMicSameWin;
    dgMicWinPrev = stMicWin; dgMicZeroPrev = stMicZeroWin; dgMicSamePrev = stMicSameWin;
    if (now < 30000) dgMicWin1 = -1;                     // the first minute after boot is not a full minute
    dgOutBad1 = stOutBadTok >= dgOutBadPrev ? (int32_t)(stOutBadTok - dgOutBadPrev) : (int32_t)stOutBadTok;
    dgOutBadPrev = stOutBadTok;
    dgOutPirRing[dgRingI] = outPirTotal; dgRingI = (dgRingI + 1) % 11; if (dgRingN < 11) dgRingN++;
  }
}

String diagCam() {                                   // one photo from the ESP32-CAM, with the reason when it fails
  String h = cfg.camHost; h.trim();
  if (h.length() == 0) return "{\"st\":\"nohost\"}";
  if (motorBusy() || dispBusy() || mealBusy() || stagingNow || cState) return "{\"st\":\"busy\"}";
  String addr = h;
  if (h.endsWith(".local")) {
    IPAddress ip = MDNS.queryHost(h.substring(0, h.length() - 6), 1500);
    if (ip == IPAddress(0, 0, 0, 0)) return "{\"st\":\"mdns\",\"host\":\"" + jsonEsc(h) + "\"}";
    addr = ip.toString();
  }
  HTTPClient http; http.setTimeout(3000);
  if (!http.begin("http://" + addr + "/jpg")) return "{\"st\":\"nohttp\",\"ip\":\"" + jsonEsc(addr) + "\"}";
  int code = http.GET();
  String st = "ok"; int size = 0; bool jpg = false;
  if (code <= 0) st = "nohttp";
  else if (code != 200) st = "http";
  else {
    size = http.getSize();
    WiFiClient* s = http.getStreamPtr(); uint8_t b[2] = {0, 0}; uint32_t t0 = millis(); size_t got = 0;
    while (got < 2 && millis() - t0 < 2000) { if (s->available()) got += s->readBytes(b + got, 2 - got); else delay(2); }
    jpg = got == 2 && b[0] == 0xFF && b[1] == 0xD8;
    if (!jpg) st = "notjpg";
  }
  http.end();
  return "{\"st\":\"" + st + "\",\"code\":" + String(code) + ",\"ip\":\"" + jsonEsc(addr) + "\",\"bytes\":" + String(size) + "}";
}

void handleDiag() {
  uint32_t now = millis();
  uint32_t seen; noInterrupts(); seen = irSeenTotal; interrupts();
  String j = "{\"fw\":\"2.9.9\",\"up\":" + String(now / 1000);
  j += ",\"rssi\":" + String(WiFi.RSSI()) + ",\"ssid\":\"" + jsonEsc(WiFi.SSID()) + "\",\"clock\":" + String(clockValid() ? "true" : "false");
  j += ",\"heap\":" + String(ESP.getFreeHeap());
  j += ",\"mic\":{\"init\":" + String(micInitOk ? "true" : "false") + ",\"win\":" + String(dgMicWin1) + ",\"zero\":" + String(dgMicZero1);
  j += ",\"same\":" + String(dgMicSame1) + ",\"db\":" + String(levelDb, 1) + ",\"base\":" + String(baseDb, 1) + "}";
  j += ",\"ir\":{\"fit\":" + String(cfg.irFitted ? "true" : "false") + ",\"blocked\":" + String(digitalRead(PIN_IR) == LOW ? "true" : "false");
  j += ",\"blockedS\":" + String(dgIrBlockSinceMs ? (now - dgIrBlockSinceMs) / 1000 : 0) + ",\"seen\":" + String(seen);
  j += ",\"ok\":" + String(dgTreatOk) + ",\"miss\":" + String(dgTreatMiss) + ",\"streak\":" + String(noDropStreak);
  j += ",\"after\":" + String(cfg.emptyAfter) + ",\"emptyT\":" + String(outOfTreats ? "true" : "false") + ",\"emptyF\":" + String(outOfFood ? "true" : "false");
  j += ",\"jams\":" + String(day.jams) + "}";
  j += ",\"pir\":{\"on\":" + String(cfg.srcMotion ? "true" : "false") + ",\"high\":" + String(digitalRead(PIN_PIR) ? "true" : "false");
  j += ",\"highS\":" + String(dgPirHighSinceMs ? (now - dgPirHighSinceMs) / 1000 : 0) + ",\"rises\":" + String(dgPirRises) + "}";
  uint32_t pir10 = 0;
  if (dgRingN > 0) { uint8_t oldest = dgRingN < 11 ? 0 : dgRingI; pir10 = outPirTotal - dgOutPirRing[oldest]; }
  j += ",\"out\":{\"on\":" + String(cfg.srcOutdoor ? "true" : "false") + ",\"age\":" + String(lastOutdoorSeenMs ? (int32_t)((now - lastOutdoorSeenMs) / 1000) : -1);
  j += ",\"bad\":" + String(dgOutBad1) + ",\"badAll\":" + String(stOutBadTok) + ",\"pir10\":" + String(pir10) + ",\"pirAll\":" + String(outPirTotal);
  j += ",\"tok\":" + String(cfg.token.length() ? "true" : "false") + "}";
  j += ",\"spk\":{\"fit\":" + String(cfg.spkFitted ? "true" : "false") + ",\"ok\":" + String(spkOk ? "true" : "false") + "}";
  j += ",\"fs\":" + String(fsOk ? "true" : "false");
  j += ",\"cam\":{\"host\":\"" + jsonEsc(cfg.camHost) + "\"";
  if (server.hasArg("cam")) j += ",\"probe\":" + diagCam();
  j += "}";
  j += ",\"clutch\":" + String(clutchValid ? "true" : "false") + ",\"motor\":" + String(motorBusy() ? "true" : "false");
  j += ",\"cleaning\":" + String(cleanOn ? "true" : "false") + ",\"cleanSt\":" + String(cState);
  j += ",\"stop\":" + String(stopActive() ? (int32_t)((stopUntilMs - now) / 1000) : 0) + ",\"enabled\":" + String(cfg.enabled ? "true" : "false");
  j += ",\"mode\":" + String(cfg.mode) + ",\"payHand\":" + String(payByHand ? "true" : "false");
  j += ",\"mealsOn\":" + String(cfg.mealsOn ? "true" : "false") + ",\"mealLast\":\"" + jsonEsc(mLast) + "\"";
  j += ",\"ntfy\":" + String(cfg.pushOn && cfg.ntfyTopic.length() ? "true" : "false");   // v2.9.7: + master switch
  j += ",\"remote\":" + String(rmOn ? "true" : "false") + ",\"rpoll\":" + String((int)rmPollCode) + ",\"rapi\":" + String((int)rmApiToday);   // v2.9.9 (no key/topic here)
  j += ",\"reason\":\"" + jsonEsc(lastReason) + "\"}";
  server.send(200, "application/json", j);
}

void setupDiag() { server.on("/api/diag", HTTP_GET, handleDiag); }
