#pragma once
// ---------------------------------------------------------------- v2.9.9: "api" tunnel helpers (pure; also compiled by the host test)
// Encrypted, signed tunnel for the WHOLE web page API through ntfy.sh. Protocol: REMOTE_PROTOCOL.md rev 3, sections 10–16.
//   kEnc = HMAC-SHA256(K, "feeder-enc")[0..16]; AES-128-CTR, random 16-byte IV per message/file; base64 standard with padding.
//   request  g = "<iv hex>.<b64(ctr(Q))>"   Q = {"id":..,"r":[{"m","p","b","ct","u"}...]}
//   response {"id","i":0,"n":1,"iv","x":b64(ctr(R)),"m":hex(HMAC(K,"r|id|i|n|iv|x"))[0..32]}  (or a file: x "" + "a":size)
#include <stdint.h>
#include <string.h>
#ifdef RM_HOST_TEST
#include <openssl/hmac.h>
#include <openssl/evp.h>
struct RmHmac {
  HMAC_CTX* c = nullptr;
  void begin(const uint8_t* k, size_t n) { c = HMAC_CTX_new(); HMAC_Init_ex(c, k, (int)n, EVP_sha256(), nullptr); }
  void update(const void* p, size_t n) { HMAC_Update(c, (const uint8_t*)p, n); }
  void finish(uint8_t* o) { unsigned l = 32; HMAC_Final(c, o, &l); HMAC_CTX_free(c); c = nullptr; }
};
struct RmCtr {
  EVP_CIPHER_CTX* c = nullptr;
  void begin(const uint8_t* k, const uint8_t* iv) { c = EVP_CIPHER_CTX_new(); EVP_EncryptInit_ex(c, EVP_aes_128_ctr(), nullptr, k, iv); }
  void apply(uint8_t* b, size_t n) { int l = 0; EVP_EncryptUpdate(c, b, &l, b, (int)n); }
  void end() { if (c) EVP_CIPHER_CTX_free(c); c = nullptr; }
};
#else
#include <mbedtls/md.h>
#include <mbedtls/aes.h>
struct RmHmac {
  mbedtls_md_context_t c;
  void begin(const uint8_t* k, size_t n) { mbedtls_md_init(&c); mbedtls_md_setup(&c, mbedtls_md_info_from_type(MBEDTLS_MD_SHA256), 1); mbedtls_md_hmac_starts(&c, k, n); }
  void update(const void* p, size_t n) { mbedtls_md_hmac_update(&c, (const uint8_t*)p, n); }
  void finish(uint8_t* o) { mbedtls_md_hmac_finish(&c, o); mbedtls_md_free(&c); }
};
struct RmCtr {
  mbedtls_aes_context a; uint8_t nc[16], sb[16]; size_t off = 0;
  void begin(const uint8_t* k, const uint8_t* iv) { mbedtls_aes_init(&a); mbedtls_aes_setkey_enc(&a, k, 128); memcpy(nc, iv, 16); memset(sb, 0, 16); off = 0; }
  void apply(uint8_t* b, size_t n) { mbedtls_aes_crypt_ctr(&a, n, &off, nc, sb, b, b); }
  void end() { mbedtls_aes_free(&a); }
};
#endif

static const size_t RM_G_MAX      = 3600;    // max chars of g in an api command (ntfy message limit 4096 B)
static const size_t RM_INLINE_MAX = 2600;    // R bytes that still fit one message; bigger -> ntfy file
static const uint8_t RM_ITEMS_MAX = 8;

void rmKEnc(const uint8_t* K, uint8_t* out16) {
  RmHmac h; uint8_t o[32]; h.begin(K, 16); h.update("feeder-enc", 10); h.finish(o); memcpy(out16, o, 16);
}

// ---- base64 (standard, padded)
static const char RM_B64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
struct RmB64Enc {                                    // streaming: put bytes, flush at the end; out(const char*, size_t)
  uint8_t r[3]; uint8_t rn = 0;
  template <class F> void put(const uint8_t* p, size_t n, F out) {
    char q[4];
    for (size_t i = 0; i < n; i++) { r[rn++] = p[i];
      if (rn == 3) { q[0] = RM_B64[r[0] >> 2]; q[1] = RM_B64[((r[0] & 3) << 4) | (r[1] >> 4)]; q[2] = RM_B64[((r[1] & 15) << 2) | (r[2] >> 6)]; q[3] = RM_B64[r[2] & 63]; out(q, 4); rn = 0; } }
  }
  template <class F> void flush(F out) {
    if (!rn) return; char q[4];
    q[0] = RM_B64[r[0] >> 2];
    if (rn == 1) { q[1] = RM_B64[(r[0] & 3) << 4]; q[2] = '='; q[3] = '='; }
    else { q[1] = RM_B64[((r[0] & 3) << 4) | (r[1] >> 4)]; q[2] = RM_B64[(r[1] & 15) << 2]; q[3] = '='; }
    out(q, 4); rn = 0;
  }
};
size_t rmB64Len(size_t n) { return (n + 2) / 3 * 4; }
int rmB64V(char c) { if (c >= 'A' && c <= 'Z') return c - 'A'; if (c >= 'a' && c <= 'z') return c - 'a' + 26; if (c >= '0' && c <= '9') return c - '0' + 52; if (c == '+') return 62; if (c == '/') return 63; return -1; }
// decodes s[0..n) into out (cap bytes); returns decoded length or -1 (bad char / bad padding / too big)
long rmB64Dec(const char* s, size_t n, uint8_t* out, size_t cap) {
  if (n % 4) return -1; size_t o = 0;
  for (size_t i = 0; i < n; i += 4) {
    int v[4]; int pad = 0;
    for (int k = 0; k < 4; k++) { char c = s[i + k];
      if (c == '=') { if (i + 4 != n || k < 2) return -1; v[k] = 0; pad++; } else { if (pad) return -1; v[k] = rmB64V(c); if (v[k] < 0) return -1; } }
    uint32_t w = (v[0] << 18) | (v[1] << 12) | (v[2] << 6) | v[3];
    uint8_t b[3] = { (uint8_t)(w >> 16), (uint8_t)(w >> 8), (uint8_t)w };
    for (int k = 0; k < 3 - pad; k++) { if (o >= cap) return -1; out[o++] = b[k]; }
  }
  return (long)o;
}

// ---- minimal JSON walker (top-level members only; strings decoded to UTF-8 incl. \uXXXX surrogate pairs)
int rmJWs(const char* s, int n, int i) { while (i < n && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\r')) i++; return i; }
int rmJSkipStr(const char* s, int n, int i) {        // i at '"'; returns index after closing quote or -1
  for (i++; i < n; i++) { if (s[i] == '\\') { i++; continue; } if (s[i] == '"') return i + 1; if ((uint8_t)s[i] < 0x20) return -1; }
  return -1;
}
int rmJSkip(const char* s, int n, int i) {           // skips one value; returns index after it or -1
  i = rmJWs(s, n, i); if (i >= n) return -1;
  if (s[i] == '"') return rmJSkipStr(s, n, i);
  if (s[i] == '{' || s[i] == '[') {
    int depth = 0;
    for (; i < n; i++) {
      char c = s[i];
      if (c == '"') { int e = rmJSkipStr(s, n, i); if (e < 0) return -1; i = e - 1; continue; }
      if (c == '{' || c == '[') { if (++depth > 6) return -1; }
      else if (c == '}' || c == ']') { if (--depth == 0) return i + 1; }
    }
    return -1;
  }
  int b = i; while (i < n && (isalnum((uint8_t)s[i]) || s[i] == '-' || s[i] == '+' || s[i] == '.')) i++;
  return i > b ? i : -1;
}
// finds top-level key in the object starting at s[i]=='{' (end n); sets [vs,ve) of its value. 1 found, 0 missing, -1 bad JSON
int rmJGet(const char* s, int n, int i, const char* key, int& vs, int& ve) {
  i = rmJWs(s, n, i); if (i >= n || s[i] != '{') return -1; i = rmJWs(s, n, i + 1);
  if (i < n && s[i] == '}') return 0;
  size_t kl = strlen(key);
  for (;;) {
    if (i >= n || s[i] != '"') return -1;
    int ke = rmJSkipStr(s, n, i); if (ke < 0) return -1;
    bool match = (size_t)(ke - i - 2) == kl && !memcmp(s + i + 1, key, kl);
    i = rmJWs(s, n, ke); if (i >= n || s[i] != ':') return -1;
    int v0 = rmJWs(s, n, i + 1), v1 = rmJSkip(s, n, v0); if (v1 < 0) return -1;
    if (match) { vs = v0; ve = v1; return 1; }
    i = rmJWs(s, n, v1); if (i < n && s[i] == ',') { i = rmJWs(s, n, i + 1); continue; }
    if (i < n && s[i] == '}') return 0;
    return -1;
  }
}
static void rmUtf8(String& o, uint32_t cp) {
  if (cp < 0x80) o += (char)cp;
  else if (cp < 0x800) { o += (char)(0xC0 | (cp >> 6)); o += (char)(0x80 | (cp & 63)); }
  else if (cp < 0x10000) { o += (char)(0xE0 | (cp >> 12)); o += (char)(0x80 | ((cp >> 6) & 63)); o += (char)(0x80 | (cp & 63)); }
  else { o += (char)(0xF0 | (cp >> 18)); o += (char)(0x80 | ((cp >> 12) & 63)); o += (char)(0x80 | ((cp >> 6) & 63)); o += (char)(0x80 | (cp & 63)); }
}
// decodes the JSON string value at [vs,ve) into out. false if not a string, bad escape, NUL, or longer than maxLen bytes
bool rmJStr(const char* s, int vs, int ve, String& out, size_t maxLen) {
  out = ""; if (ve - vs < 2 || s[vs] != '"' || s[ve - 1] != '"') return false;
  for (int i = vs + 1; i < ve - 1; i++) {
    char c = s[i];
    if (c == '\\') {
      if (++i >= ve - 1) return false; char e = s[i];
      if (e == 'n') out += '\n'; else if (e == 't') out += '\t'; else if (e == 'r') out += '\r'; else if (e == 'b') out += '\b'; else if (e == 'f') out += '\f';
      else if (e == '"' || e == '\\' || e == '/') out += e;
      else if (e == 'u') {
        auto hex4 = [&](int at, uint32_t& v) { if (at + 4 > ve - 1) return false; v = 0; for (int k = 0; k < 4; k++) { int h = rmHexV(s[at + k]); if (h < 0) return false; v = v * 16 + h; } return true; };
        uint32_t v; if (!hex4(i + 1, v)) return false; i += 4;
        if (v >= 0xD800 && v < 0xDC00) { uint32_t lo; if (i + 2 >= ve - 1 || s[i + 1] != '\\' || s[i + 2] != 'u' || !hex4(i + 3, lo) || lo < 0xDC00 || lo > 0xDFFF) return false; i += 6; v = 0x10000 + ((v - 0xD800) << 10) + (lo - 0xDC00); }
        else if (v >= 0xDC00 && v < 0xE000) return false;
        if (v == 0) return false;
        rmUtf8(out, v);
      } else return false;
    } else { if (!c) return false; out += c; }
    if (out.length() > maxLen) return false;
  }
  return true;
}
// convenience: string member of object text j (whole string). 1 ok, 0 missing, -1 bad/too long
int rmJGetStr(const String& j, const char* key, String& out, size_t maxLen) {
  int vs, ve; int r = rmJGet(j.c_str(), (int)j.length(), 0, key, vs, ve); out = "";
  if (r <= 0) return r;
  return rmJStr(j.c_str(), vs, ve, out, maxLen) ? 1 : -1;
}
int rmJGetInt(const String& j, const char* key, long long& v) {
  int vs, ve; int r = rmJGet(j.c_str(), (int)j.length(), 0, key, vs, ve);
  if (r <= 0) return r;
  String t = j.substring(vs, ve); if (!rmIsInt(t)) return -1; v = atoll(t.c_str()); return 1;
}
// JSON-escape bytes (UTF-8 passed through) for output
template <class F> void rmJEsc(const char* p, size_t n, F out) {
  size_t a = 0; char u[7];
  for (size_t i = 0; i < n; i++) {
    uint8_t c = (uint8_t)p[i]; const char* rep = nullptr; size_t rl = 2;
    if (c == '"') rep = "\\\""; else if (c == '\\') rep = "\\\\"; else if (c == '\n') rep = "\\n"; else if (c == '\r') rep = "\\r"; else if (c == '\t') rep = "\\t";
    else if (c < 0x20 || c == 0x7f) { snprintf(u, sizeof u, "\\u%04x", c); rep = u; rl = 6; }
    if (rep) { if (i > a) out(p + a, i - a); out(rep, rl); a = i + 1; }
  }
  if (n > a) out(p + a, n - a);
}

// ---- request: open g, and the allowlist
bool rmIdOk(const String& id) {
  if (id.length() < 4 || id.length() > 16) return false;
  for (char c : id) if (!(isalnum((uint8_t)c) || c == '-' || c == '_')) return false;
  return true;
}
bool rmGShapeOk(const String& g) {                   // "<32 hex>.<base64>", total <= RM_G_MAX
  if (g.length() < 37 || g.length() > RM_G_MAX || g[32] != '.' || (g.length() - 33) % 4) return false;
  for (int i = 0; i < 32; i++) if (rmHexV(g[i]) < 0) return false;
  return true;
}
// decrypts g with kEnc into Q (UTF-8 text). false on shape/base64 errors.
bool rmOpenReq(const uint8_t* K, const String& g, String& Q) {
  Q = ""; if (!rmGShapeOk(g)) return false;
  uint8_t iv[16]; if (!rmUnhex(g.substring(0, 32), iv, 16)) return false;
  size_t cap = (g.length() - 33) / 4 * 3; uint8_t* buf = (uint8_t*)malloc(cap + 1); if (!buf) return false;
  long n = rmB64Dec(g.c_str() + 33, g.length() - 33, buf, cap);
  if (n <= 0) { free(buf); return false; }
  uint8_t ke[16]; rmKEnc(K, ke); RmCtr c; c.begin(ke, iv); c.apply(buf, (size_t)n); c.end();
  bool ok = true; for (long i = 0; i < n; i++) if (!buf[i]) { ok = false; break; }
  if (ok) { buf[n] = 0; Q = String((const char*)buf); }
  free(buf); return ok;
}
// 0 allowed, 1 blocked at home only (403), 2 unknown (404), 3 camera photo (tunnel itself), 4 upload endpoint (needs "u")
uint8_t rmApiClass(const String& m, const String& p) {
  if (!p.startsWith("/api/") || p.length() > 240) return 2;
  for (char c : p) if ((uint8_t)c <= 0x20 || (uint8_t)c >= 0x7f) return 2;   // one clean path, no spaces / CRLF injection
  int q = p.indexOf('?'); String path = q >= 0 ? p.substring(0, q) : p;
  if (path.indexOf("..") >= 0) return 2;
  if (path.startsWith("/api/remote") || path == "/api/reset-wifi" || path == "/api/reset-stats" || path.startsWith("/api/update") || path.startsWith("/api/ota") || path.startsWith("/api/fw") || path.startsWith("/api/flash") || path.startsWith("/update")) return 1;
  static const char* GETS[] = { "/api/status", "/api/stats", "/api/settings", "/api/days", "/api/days.csv", "/api/weight", "/api/stage", "/api/bursts",
                                "/api/ask", "/api/diag", "/api/meal", "/api/check/state", "/api/check/cam", nullptr };
  static const char* POSTS[] = { "/api/settings", "/api/treat", "/api/calibrate", "/api/ask-test", "/api/ask-ping", "/api/play", "/api/sound-del", "/api/refilled",
                                 "/api/weekly-now", "/api/train-now", "/api/bark-learn", "/api/bark-label", "/api/led-test", "/api/meal", "/api/meal-now", "/api/meal-stop",
                                 "/api/meal-cal", "/api/clean-start", "/api/clean-done", "/api/doorbell", "/api/stop", "/api/resume", "/api/paid", "/api/weight", "/api/stage",
                                 "/api/check/reset", "/api/check/beep", "/api/check/led", "/api/check/motor", nullptr };
  if (m == "GET") { if (path == "/api/cam.jpg") return 3; for (int i = 0; GETS[i]; i++) if (path == GETS[i]) return 0; return 2; }
  if (m == "POST") { if (path == "/api/sound") return 4; if (path == "/api/ask-ping") return 0; for (int i = 0; POSTS[i]; i++) if (path == POSTS[i]) return 0; return 2; }
  return 2;
}
// ---- response sealing (inline message). R = plaintext bytes; iv = 16 random bytes. Returns the one-line message JSON.
String rmRespTag(const uint8_t* K, const String& id, int i, int n, const String& ivh, const String& x) {
  String msg = String("r|") + id + "|" + String((long long)i) + "|" + String((long long)n) + "|" + ivh + "|" + x;
  RmHmac h; uint8_t o[32]; h.begin(K, 16); h.update(msg.c_str(), msg.length()); h.finish(o); return rmHex(o, 16);
}
String rmSealInline(const uint8_t* K, const String& id, const uint8_t* R, size_t n, const uint8_t* iv) {
  uint8_t ke[16]; rmKEnc(K, ke);
  uint8_t* b = (uint8_t*)malloc(n ? n : 1); if (!b) return "";
  memcpy(b, R, n); RmCtr c; c.begin(ke, iv); c.apply(b, n); c.end();
  String x; x.reserve(rmB64Len(n) + 1); RmB64Enc e;
  auto out = [&](const char* p, size_t k) { for (size_t q = 0; q < k; q++) x += p[q]; };
  e.put(b, n, out); e.flush(out); free(b);
  String ivh = rmHex(iv, 16);
  return String("{\"id\":\"") + id + "\",\"i\":0,\"n\":1,\"iv\":\"" + ivh + "\",\"x\":\"" + x + "\",\"m\":\"" + rmRespTag(K, id, 0, 1, ivh, x) + "\"}";
}
// header message of a file response (x empty, a = file size incl. 32-byte tag)
String rmFileMsg(const uint8_t* K, const String& id, const String& ivh, size_t fileLen) {
  return String("{\"id\":\"") + id + "\",\"i\":0,\"n\":1,\"iv\":\"" + ivh + "\",\"x\":\"\",\"a\":" + String((long long)fileLen) + ",\"m\":\"" + rmRespTag(K, id, 0, 1, ivh, "") + "\"}";
}
// starts the file / upload tag: HMAC(K, kind + "|" + id + "|" + ivhex + "|" || ciphertext)
void rmTagBegin(RmHmac& h, const uint8_t* K, char kind, const String& id, const String& ivh) {
  String pre = String(kind) + "|" + id + "|" + ivh + "|"; h.begin(K, 16); h.update(pre.c_str(), pre.length());
}
// replay ring: 64-bit FNV-1a of the nonce, last 256 kept
uint64_t rmNonceHash(const String& n) { uint64_t h = 1469598103934665603ULL; for (char c : n) { h ^= (uint8_t)c; h *= 1099511628211ULL; } return h; }
