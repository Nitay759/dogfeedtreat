#pragma once
#include <stdint.h>
// One day of progress numbers, stored in /days296.bin (LittleFS). נתוני יום אחד
// v2.9.6: the record changed (recall numbers removed, food grams / per-trigger / doorbell / difficulty added) -> new file name.
struct __attribute__((packed)) DayRec {
  int32_t  dayKey;        // yyyymmdd, 0 = empty slot
  uint16_t barks, episodes, triggers, reactions, treats, jams, doubles, trainTrials, trainPass, calmN;
  uint32_t calmSumS;      // sum of episode lengths (first bark -> last bark), seconds
  uint32_t quietMaxS;     // longest quiet streak in ALONE mode, seconds
  uint8_t  modeMask;      // bit per mode used that day (1 home, 2 alone, 4 measure, 8 noise training, 16 doorbell = good thing)
  uint8_t  trainVol;      // training volume that day
  // ---- v2.9.6
  uint16_t treatDg;       // treat grams that day x10 (every treat: auto, manual, training)
  uint16_t mealG;         // grams the meals served that day
  uint16_t trigC[3];      // triggers per kind: 0 doorbell, 1 noise / street, 2 motion
  uint16_t reactC[3];     // ... she barked within 10 s
  uint16_t passC[3];      // ... she stayed quiet and earned a treat
  uint16_t bellTrials, bellPass;   // "פעמון = דבר טוב": bells played / calm -> treat
  uint16_t aloneTry, alonePass;    // ALONE: intervals that ended with a bark / with a treat
  uint8_t  lvl[4];        // difficulty at the end of the day: 0 alone, 1 doorbell, 2 noise, 3 motion
  uint16_t spills;        // fast treat: pocket empty at the click (it fell before the click)
  uint16_t reserved;
};
