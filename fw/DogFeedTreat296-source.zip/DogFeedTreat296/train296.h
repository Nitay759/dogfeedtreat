#pragma once
// ---------------------------------------------------------------- v2.9.6 (Nov 10 2026): training upgrades, all code-only
//  A. FOOD GRAMS: every treat (auto, manual, training) is counted in grams against the day's food (default 300 g) and the
//     treat grams are taken off the NEXT meal. A meal is never cut below cfg.mealFloorPct (50 %) of its size. No daily cap.
//  B+C. AUTO DIFFICULTY per engine (alone, doorbell, noise/street, motion): last 8-10 outcomes >= 80 % calm -> one level up,
//     <= 50 % -> one level down. ALONE: the level stretches the random interval (as the old 1-10 slider). HOME / outside events:
//     the level stretches the quiet she must keep before the treat (x1.0 at level 1 ... x4.15 at level 10) = treat thinning.
//     The levels can always be changed by hand; "קושי אוטומטי" off keeps them where you put them.
//  D. PER-TRIGGER numbers: doorbell / noise+street / motion -> triggers, barked-at, earned, in /api/days + CSV.
//  E. "פעמון = דבר טוב" (mode 4): the doorbell sound very quietly (start 8 %, max 40 %), she stays calm 1.5 s -> treat at once.
//     Barked -> no treat, the bell gets 3 % quieter and the next one waits longer. 5 calm in a row -> 2 % louder.
//  F. WEIGHT LOG (/weight.bin): one weight per day, graph with the 25 kg target.
//  G. STOP (POST /api/stop, a button on every page): motor stops at once; treat / meal / training / doorbell / sound /
//     pending events stop; automatic treats, training sounds and meal starts pause for 10 minutes (or until "המשך").
//  FAST TREAT (round 2, item 3): between treats the TREAT wheel waits "pre-staged" at cfg.stagePct % (85) of a pocket, so a
//     treat is click -> the last ~15 % of the turn (~0.5 s) -> IR sees it fall. Re-staged 2 s after every treat. If the
//     pocket is empty at the click (it fell early) the next full pocket is turned at once, the staging angle drops 3 %, logged.
//  PAY BY HAND (round 2, item 8, minimal): a click whose treat jams / finds the wheel empty -> red banner + ntfy
//     "give her a treat by hand", until "נתתי ביד" or "מילאתי".
// Log types added: 27 STOP · 28 fast treat: pocket was empty at the click · 29 difficulty changed (db = level, conf = engine)
//   30 doorbell=good: bell played · 31 bell: calm -> treat · 32 bell: barked -> no treat · 33 doorbell (you tapped)
//   34 weight saved (db = kg) · 35 click not paid -> give by hand

// ---------------------------------------------------------------- A. grams
float treatGToday() { return day.treatDg / 10.0f; }
void  debtSave() { prefs.begin("dogtreat", false); prefs.putFloat("debt", treatDebtG); prefs.end(); }
void  addTreatGrams(float g) {
  day.treatDg = (uint16_t)min(65000.0f, day.treatDg + g * 10.0f + 0.5f);
  if (cfg.treatFromMeal) { treatDebtG += g; debtSave(); }
}
float mealMaxCut() { return cfg.mealG * (100 - cfg.mealFloorPct) / 100.0f; }
float nextMealG()  { return cfg.mealG - (cfg.treatFromMeal ? min(treatDebtG, mealMaxCut()) : 0.0f); }
// called by startMeal(): returns the grams this meal gives (never below the floor) and books the cut
float mealTargetWithTreats() {
  mealCutG = cfg.treatFromMeal ? min(treatDebtG, mealMaxCut()) : 0.0f;
  if (mealCutG > 0) {
    treatDebtG -= mealCutG;
    if (treatDebtG > mealMaxCut()) treatDebtG = mealMaxCut();   // at most one more meal's cut carries over (welfare floor)
    debtSave();
  }
  return cfg.mealG - mealCutG;
}
float gramsLeftToday() { return max(0.0f, (float)cfg.dailyFoodG - day.mealG - treatGToday()); }

// ---------------------------------------------------------------- B + C. auto difficulty
DiffRing dRing[4];      // struct DiffRing is declared in the .ino (used by /api/status)
const char* ENGINE_HE[4] = {"לבד", "פעמון", "רעש ורחוב", "תנועה"};
uint8_t& lvlRef(uint8_t e) { return e == 0 ? cfg.difficulty : cfg.lvl[e - 1]; }
float quietMult(uint8_t L) { return 1.0f + (constrain(L, 1, 10) - 1) * 0.35f; }
uint8_t catOf(uint8_t src) { return src == 33 ? 0 : (src == 7 ? 1 : 2); }     // log src -> trigger kind
String diffMsg = "";
void diffOutcome(uint8_t e, bool pass) {
  if (e > 3) return;
  DiffRing& r = dRing[e];
  r.bits = (uint16_t)((r.bits << 1) | (pass ? 1 : 0)); if (r.n < 10) r.n++;
  if (!cfg.autoDiff || r.n < 8) return;
  int p = 0; for (int i = 0; i < r.n; i++) p += (r.bits >> i) & 1;
  uint8_t& L = lvlRef(e); uint8_t old = L;
  if (p * 100 >= 80 * r.n && L < 10) L++;
  else if (p * 100 <= 50 * r.n && L > 1) L--;
  if (L != old) {
    r.n = 0; r.bits = 0; saveSettings(); logEvent(29, L, e);
    diffMsg = String("קושי ") + ENGINE_HE[e] + ": " + old + " ← " + L + (L > old ? " (הצליחה " : " (קשה לה, ") + p + " מתוך 10)";
    Serial.printf("[diff] engine %u %u -> %u\n", e, old, L);
  }
}
uint8_t ringPass(uint8_t e) { int p = 0; for (int i = 0; i < dRing[e].n; i++) p += (dRing[e].bits >> i) & 1; return p; }

// ---------------------------------------------------------------- E. doorbell = good thing (mode 4)
uint8_t  bgState = 0;            // 0 waiting · 1 bell playing · 2 listening 1.5 s
uint32_t bgNextMs = 0, bgEndMs = 0, bgBark0 = 0;
uint8_t  bgStreak = 0;
void bgSchedule(float mult = 1.0f) {
  uint32_t lo = cfg.trainGapMinS, hi = max(cfg.trainGapMaxS, cfg.trainGapMinS);
  bgNextMs = millis() + (uint32_t)((lo + (hi > lo ? esp_random() % (hi - lo + 1) : 0)) * mult * 1000.0f);
}
void bellGoodTick() {
  uint32_t now = millis();
  if (bgState == 0) {
    if (!bgNextMs) bgSchedule(0.5f);
    if ((int32_t)(now - bgNextMs) < 0) return;
    if (inBarkCooldown() || burstActive || now - lastSoundMs < 3000 || dispBusy() || playing) return;   // wait for a calm moment
    if (day.bellTrials >= cfg.trainMaxDay) { bgSchedule(); return; }
    if (!playSound("bell", cfg.bellVol)) { lastReason = "doorbell mode: no speaker"; bgSchedule(); return; }
    logEvent(30, cfg.bellVol); noteTrigger(0); bgState = 1; bgBark0 = lastBarkMs;
    return;
  }
  if (bgState == 1) { if (!playing) { bgState = 2; bgEndMs = now; } return; }
  // listening: the mic is deaf while the bell plays (+400 ms), so a bark at the bell shows up here
  if (lastBarkMs != bgBark0) {
    bgState = 0; day.bellTrials++; logEvent(32, cfg.bellVol); bgStreak = 0;
    cfg.bellVol = max(3, (int)cfg.bellVol - 3); saveSettings(); bgSchedule(2.0f); return;
  }
  if (burstActive && now - bgEndMs < 4500) return;            // a sound is still being classified
  if (now - bgEndMs >= 1500 + 400) {
    bgState = 0; day.bellTrials++; day.bellPass++;
    dispense(false, "doorbell = good thing", 31);
    if (++bgStreak >= 5) { bgStreak = 0; if (cfg.bellVol < cfg.bellVolMax) { cfg.bellVol = min((int)cfg.bellVolMax, cfg.bellVol + 2); saveSettings(); } }
    bgSchedule();
  }
}

// ---------------------------------------------------------------- FAST TREAT: pre-staged treat wheel
int32_t pocketSteps() { return (cfg.stepsPerRev ? cfg.stepsPerRev : 4608) / 2; }
int32_t pocketStart(int32_t a) {                       // start (boundary) of the pocket that position a is in
  int32_t r = cfg.stepsPerRev ? cfg.stepsPerRev : 4608;
  int32_t k = (int32_t)floor((double)a * 2 / r);
  return (int32_t)(((int64_t)k * r + 1) / 2);
}
bool stageReady() { return cfg.stageOn && staged && clutchValid && wAng[0] == stagedAng && !cleanOn; }
bool stageStart() {                                    // rock (stir the hopper) -> drive to stagePct of the next pocket -> park
  if (!cfg.stageOn || cleanOn || !clutchValid || motorBusy() || dispBusy() || mealBusy() || cState) return false;
  if (stageReady()) return true;
  // stage the pocket we are in (never cross a boundary here: that would drop a treat without a click)
  int32_t target = pocketStart(wAng[0]) + pocketSteps() * constrain(cfg.stagePct, 40, 95) / 100;
  if (target <= wAng[0]) { staged = true; stagedAng = wAng[0]; return true; }   // already past the angle (e.g. % lowered)
  activeWheel = 0; segN = 0;
  int32_t a = safeRock(0);
  if (a > 0) { qSeg(SEG_REL, 0, -a); qSeg(SEG_REL, 0, a); }
  qSeg(SEG_DRIVE, 0, target); qSeg(SEG_PARK, 0, 0);
  beginMotion(); stagingNow = true; staged = false;
  return true;
}
void stageTick() {                                     // loop(): finish a staging move, re-stage when due
  if (stagingNow) {
    if (motorBusy()) return;
    stagingNow = false; staged = true; stagedAng = wAng[0]; stageIrHit = false;
    noInterrupts(); stageDrops0 = irDrops; interrupts();
    return;
  }
  if (stageDueMs && (int32_t)(millis() - stageDueMs) >= 0 && !stopActive()) {
    if (motorBusy() || dispBusy() || mealBusy() || playing) return;
    stageDueMs = 0; stageStart();
  }
}

// ---------------------------------------------------------------- G. STOP
bool stopActive() { return stopUntilMs && (int32_t)(stopUntilMs - millis()) > 0; }
void stopAll() {
  playAbort = true; if (playQ) xQueueReset(playQ);    // the speaker task drops the rest of the clip
  bool wasStaging = stagingNow;
  motorStopNow();                                      // coils off
  if (wasStaging) { stagingNow = false; staged = false; }
  if (mealBusy()) mealEnd("נעצרה (STOP)", false);
  if (dState != D_IDLE) { dState = D_IDLE; setRgb(false, false, false); }
  if (cState) { cState = 0; clutchValid = false; clutchSave(); }   // cleaning: emptying stops, mode stays on
  pendingNoise = false; pendingExt = false;
  tState = T_IDLE; trainScheduleNext(2.0f);
  bgState = 0; bgSchedule(2.0f);
  calibrateUntil = 0; stageDueMs = 0;
  stopUntilMs = millis() + 600000UL; if (!stopUntilMs) stopUntilMs = 1;
  lastReason = "STOP"; logEvent(27, 0);
  Serial.println("[stop] everything stopped, auto paused 10 min");
}
void handleStop()   { stopAll(); server.send(200, "application/json", "{\"ok\":true,\"pausedS\":600}"); }
void handleResume() { stopUntilMs = 0; playAbort = false; if (cfg.stageOn) stageDueMs = millis() + 500; server.send(200, "application/json", "{\"ok\":true}"); }

// ---------------------------------------------------------------- PAY BY HAND
void clickUnpaid(const char* why) {
  if (payByHand) return;
  payByHand = true; logEvent(35, 0);
  sendNtfy(String("✋ הקליק לא שולם (") + why + "). תן לה חטיף ביד עכשיו, ואז בדוק את גלגל החטיפים.", "Give a treat by hand", false);
}
void handlePaid() { payByHand = false; server.send(200, "application/json", "{\"ok\":true}"); }

// ---------------------------------------------------------------- F. weight log
struct __attribute__((packed)) WRec { int32_t dayKey; uint16_t dkg; uint16_t pad; };
static const char* W_FILE = "/weight.bin";
static const int   W_MAX  = 400;
int wLoad(WRec* out, int maxN) {
  int n = 0; if (!fsOk) return 0;
  File f = LittleFS.open(W_FILE, "r"); if (!f) return 0;
  while (n < maxN && f.read((uint8_t*)&out[n], sizeof(WRec)) == sizeof(WRec)) { if (out[n].dayKey > 0) n++; }
  f.close(); return n;
}
void wStore(WRec* a, int n) {
  for (int i = 1; i < n; i++) { WRec t = a[i]; int j = i - 1; while (j >= 0 && a[j].dayKey > t.dayKey) { a[j + 1] = a[j]; j--; } a[j + 1] = t; }
  File f = LittleFS.open(W_FILE, "w"); if (!f) return;
  for (int i = max(0, n - W_MAX); i < n; i++) f.write((uint8_t*)&a[i], sizeof(WRec));
  f.close();
}
void handleWeightGet() {
  static WRec a[W_MAX + 1]; int n = wLoad(a, W_MAX);
  String j = "{\"target\":" + String(cfg.targetKg, 1) + ",\"today\":" + String(currentDayKey()) + ",\"list\":[";
  for (int i = 0; i < n; i++) { if (i) j += ","; j += "[" + String(a[i].dayKey) + "," + String(a[i].dkg / 10.0f, 1) + "]"; }
  j += "]}"; server.send(200, "application/json", j);
}
void handleWeightSet() {           // POST /api/weight  kg=27.3 [&date=20261110]  |  target=25  |  del=20261110
  static WRec a[W_MAX + 2];
  if (server.hasArg("target")) { float t = server.arg("target").toFloat(); if (t >= 2 && t <= 120) { cfg.targetKg = t; saveSettings(); } }
  if (!fsOk && (server.hasArg("kg") || server.hasArg("del"))) { server.send(500, "application/json", "{\"ok\":false,\"error\":\"no file system\"}"); return; }
  if (server.hasArg("del")) {
    int32_t k = server.arg("del").toInt(); int n = wLoad(a, W_MAX), m = 0;
    for (int i = 0; i < n; i++) if (a[i].dayKey != k) a[m++] = a[i];
    wStore(a, m);
  }
  if (server.hasArg("kg")) {
    float kg = server.arg("kg").toFloat();
    int32_t k = server.hasArg("date") ? server.arg("date").toInt() : currentDayKey();
    if (kg < 1 || kg > 150 || k < 20200101 || k > 21001231) { server.send(400, "application/json", "{\"ok\":false,\"error\":\"bad weight or date (clock not set?)\"}"); return; }
    int n = wLoad(a, W_MAX); bool rep = false;
    for (int i = 0; i < n; i++) if (a[i].dayKey == k) { a[i].dkg = (uint16_t)lroundf(kg * 10); rep = true; }
    if (!rep) { a[n].dayKey = k; a[n].dkg = (uint16_t)lroundf(kg * 10); a[n].pad = 0; n++; }
    wStore(a, n); logEvent(34, kg);
  }
  handleWeightGet();
}

// ---------------------------------------------------------------- fast-treat calibration API (page: /meal)
void handleStageGet() {
  String j = "{\"on\":" + String(cfg.stageOn ? "true" : "false") + ",\"pct\":" + String(cfg.stagePct);
  j += ",\"staged\":" + String(stageReady() ? "true" : "false") + ",\"staging\":" + String(stagingNow ? "true" : "false");
  j += ",\"lat\":" + String(lastLatencyMs) + ",\"spills\":" + String(day.spills) + ",\"idleIr\":" + String(idleIrSeen);
  j += ",\"ir\":" + String(cfg.irFitted ? "true" : "false") + ",\"pos\":" + String(stageReady() ? (wAng[0] - pocketStart(wAng[0])) * 100 / pocketSteps() : -1) + "}";
  server.send(200, "application/json", j);
}
void handleStageSet() {            // POST /api/stage  on=0|1  pct=50..95  act=now|spill
  if (server.hasArg("on"))  { cfg.stageOn = server.arg("on") == "1"; if (!cfg.stageOn) staged = false; }
  if (server.hasArg("pct")) { cfg.stagePct = constrain(server.arg("pct").toInt(), 40, 95); staged = false; }
  saveSettings();
  String a = server.arg("act");
  if (a == "spill") { cfg.stagePct = max(40, (int)cfg.stagePct - 3); staged = false; day.spills++; logEvent(28, cfg.stagePct); saveSettings(); }
  if (a == "now" || a == "spill" || server.hasArg("pct") || server.hasArg("on")) { if (cfg.stageOn && !stopActive()) stageDueMs = millis() + 200; }
  handleStageGet();
}
// idle IR watch: a treat falling while the wheel is staged and nothing runs = it fell early (only shown; the decisive check
// is "pocket empty at the click" in dispenseTick, because her nose in the tray breaks the beam too)
void stageIrTick() {
  if (!stageReady() || !cfg.irFitted || dispBusy() || motorBusy() || mealBusy()) return;
  uint16_t d; noInterrupts(); d = irDrops; interrupts();
  if (d != stageDrops0) { stageDrops0 = d; idleIrSeen++; stageIrHit = true; }
}

void setupTrain296() {
  server.on("/api/stop", HTTP_POST, handleStop);
  server.on("/api/resume", HTTP_POST, handleResume);
  server.on("/api/paid", HTTP_POST, handlePaid);
  server.on("/api/weight", HTTP_GET, handleWeightGet);
  server.on("/api/weight", HTTP_POST, handleWeightSet);
  server.on("/api/stage", HTTP_GET, handleStageGet);
  server.on("/api/stage", HTTP_POST, handleStageSet);
  prefs.begin("dogtreat", true); treatDebtG = prefs.getFloat("debt", 0); prefs.end();
  if (cfg.stageOn) stageDueMs = millis() + 15000;      // after the boot clutch sync / calibration
}
void train296Tick() { stageTick(); stageIrTick(); if (stopUntilMs && !stopActive()) stopUntilMs = 0; }
