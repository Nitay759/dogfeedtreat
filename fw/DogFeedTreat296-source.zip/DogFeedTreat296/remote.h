#pragma once
// ---------------------------------------------------------------- v2.9.8: "שליטה מרחוק" — control the feeder from anywhere
// v2.9.9: + command "api" = encrypted tunnel for the whole web page API (rmapi.h; REMOTE_PROTOCOL.md rev 3 §10–16),
//         answers on <rtopic>-r, status every 30 min (ntfy.sh: 250 published messages/day per IP), nonce ring 256.
// The feeder polls a secret ntfy.sh topic (no account, no server of ours) for signed commands from NITAY's app
// and posts a short status back. Full protocol + test vectors: REMOTE_PROTOCOL.md (kept next to the sketch).
//   NVS namespace "remote": rkey (16 random bytes as 32 hex), rtopic ("dt-" + 16 [a-z0-9]), ron (switch, default OFF).
//   commands  <rtopic>-c : {"c":..,"g":..,"t":unix,"n":nonce,"h":hex HMAC-SHA256(key bytes, c|g|t|n)}
//   status    <rtopic>-s : {"v","t","ok","last","msg","food","treats","lastMeal","jam","online"} (never the key)
// Network work runs in its own FreeRTOS task (core 0, 4 s timeouts); accepted commands go through a queue and are
// executed by loop() with the SAME functions the web buttons call, so meals, treats and bark detection never wait.
// Kept outside barkml.h; barkml.h is untouched.
#include <mbedtls/md.h>

static const char*    RM_VER       = "2.9.9";
static const uint32_t RM_POLL_MS   = 10000UL;    // poll the command topic every 10 s
static const uint32_t RM_STATUS_MS = 1800000UL;  // status every 30 min while on (2.9.9; 5 min = 288 msgs/day > ntfy.sh 250/day/IP)
static const uint32_t RM_FAST_MS   = 2000UL;     // after an api command: poll every 2 s ...
static const uint32_t RM_FAST_FOR_MS = 60000UL;  // ... for 60 s
static const uint32_t RM_SLOW_MS   = 30000UL;    // ntfy said 429: poll every 30 s ...
static const uint32_t RM_SLOW_FOR_MS = 120000UL; // ... for 2 min
static const uint16_t RM_API_DAY_MAX = 150;      // api answers per local day (the rest of the 250 is for alerts/status)
static const int32_t  RM_WINDOW_S  = 300;        // |t - now| <= 5 min
static const uint32_t RM_REJ_GAP_MS = 30000UL;   // at most one "rejected" status per 30 s

String   rmKey, rmTopic;                         // guarded by rmMux (the task reads them)
bool     rmOn = false;
SemaphoreHandle_t rmMux = nullptr;
QueueHandle_t rmQ = nullptr;                     // accepted commands, task -> loop()
struct RmCmd { uint8_t c; int16_t g; uint16_t id; uint8_t bark; };   // c: 1 treat 2 meal 3 status 4 clean_start 5 clean_done 6 label 7 api; g -1 = none
static const char* RM_NAMES[] = { "", "treat", "meal", "status", "clean_start", "clean_done", "label", "api" };
static const uint8_t RM_NCMD = 7;
String   rmPendStatus;                           // status JSON waiting for the task to post (guarded by rmMux)
volatile bool rmWake = false;                    // ask the task to post now
volatile uint8_t rmRejKind = 0;                  // task -> loop: 1 sig, 2 time, 3 replay (a rejected command)
volatile int  rmPollCode = 0, rmPostCode = 0;    // last HTTP answers (diagnostics)
volatile uint32_t rmPollMs = 0;                  // last successful poll (millis)
time_t   rmLastCmdT = 0; String rmLastCmd = ""; String rmLastErr = "";
uint32_t rmLastStatusMs = 0, rmLastRejMs = 0;
uint8_t  rmFollow = 0; uint16_t rmFollowTreats = 0; // 1 = report how a remote treat ended, 2 = a remote meal
String   rmSince = "2m";                         // task only: ntfy id of the last event read
String   rmApiPend[2]; uint8_t rmApiPendN = 0;   // task only: decrypted-later g strings of accepted api commands
volatile uint32_t rmFastUntil = 0, rmSlowUntil = 0;   // millis deadlines: fast poll (2 s) / slow poll (ntfy 429)
volatile uint16_t rmApiToday = 0; int rmApiDay = -1;  // api answers sent today (local day), cap RM_API_DAY_MAX
volatile uint32_t rmApiLastMs = 0;
float    rmTok = 60; uint32_t rmTokT = 0;        // task only: ntfy.sh request budget for this IP (burst 60, +1 per 5 s) -> fast polling never runs it dry
void rmTokUse() { uint32_t n = millis(); if (!rmTokT) rmTokT = n; rmTok += (n - rmTokT) / 5000.0f; if (rmTok > 60) rmTok = 60; rmTokT = n; rmTok -= 1; }
long long rmBootEpoch = 0;                         // task only: unix time of boot (events published before it are never run)
static const uint16_t RM_RING = 256;
uint64_t rmNonce[RM_RING]; uint16_t rmNonceN = 0, rmNonceI = 0;   // task only: FNV-1a hashes of the last 256 accepted nonces (2.9.9; was 64)

// ---- pure helpers (also compiled by the host unit test)
static const char RM_HEX[] = "0123456789abcdef";
String rmHex(const uint8_t* b, size_t n) { String s; s.reserve(n * 2); for (size_t i = 0; i < n; i++) { s += RM_HEX[b[i] >> 4]; s += RM_HEX[b[i] & 15]; } return s; }
int rmHexV(char c) { if (c >= '0' && c <= '9') return c - '0'; if (c >= 'a' && c <= 'f') return c - 'a' + 10; if (c >= 'A' && c <= 'F') return c - 'A' + 10; return -1; }
bool rmUnhex(const String& s, uint8_t* out, size_t n) {
  if (s.length() != n * 2) return false;
  for (size_t i = 0; i < n; i++) { int a = rmHexV(s[2 * i]), b = rmHexV(s[2 * i + 1]); if (a < 0 || b < 0) return false; out[i] = (a << 4) | b; }
  return true;
}
bool rmNonceOk(const String& n) {
  if (n.length() < 8 || n.length() > 16) return false;
  for (char c : n) if (!(isalnum((uint8_t)c) || c == '-' || c == '_')) return false;
  return true;
}
// hex HMAC-SHA256(key = 16 raw bytes, "c|g|t|n")
String rmSign(const uint8_t* key, const String& c, const String& g, long long t, const String& n) {
  String m = c + "|" + g + "|" + String((long long)t) + "|" + n;
  uint8_t out[32];
  const mbedtls_md_info_t* md = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
  if (!md || mbedtls_md_hmac(md, key, 16, (const uint8_t*)m.c_str(), m.length(), out) != 0) return "";
  return rmHex(out, 32);
}
bool rmEqCT(const String& a, const String& b) {     // constant-time, case-insensitive hex compare
  if (a.length() != b.length() || !a.length()) return false;
  uint8_t d = 0; for (size_t i = 0; i < a.length(); i++) d |= (uint8_t)(tolower((uint8_t)a[i]) ^ tolower((uint8_t)b[i]));
  return d == 0;
}
// tiny JSON readers: value of "key" in a flat object. String values are unescaped (\" \\ \/ \n \t \uXXXX ASCII only).
int rmFind(const String& j, const char* key) {
  String k = String("\"") + key + "\""; int p = 0;
  while ((p = j.indexOf(k, p)) >= 0) { int q = p + k.length(); while (q < (int)j.length() && j[q] == ' ') q++; if (q < (int)j.length() && j[q] == ':') { q++; while (q < (int)j.length() && j[q] == ' ') q++; return q; } p = q; }
  return -1;
}
// returns 1 = string, 2 = number/literal (raw text), 0 = missing/bad
int rmVal(const String& j, const char* key, String& out, size_t maxLen = 600) {
  int p = rmFind(j, key); out = ""; if (p < 0 || p >= (int)j.length()) return 0;
  if (j[p] == '"') {
    for (int i = p + 1; i < (int)j.length(); i++) {
      char c = j[i];
      if (c == '"') return 1;
      if (c == '\\') { if (++i >= (int)j.length()) return 0; char e = j[i];
        if (e == 'n') out += '\n'; else if (e == 't') out += '\t'; else if (e == 'r') out += '\r'; else if (e == 'b' || e == 'f') {}
        else if (e == 'u') { if (i + 4 >= (int)j.length()) return 0; int v = 0; for (int k = 1; k <= 4; k++) { int h = rmHexV(j[i + k]); if (h < 0) return 0; v = v * 16 + h; } i += 4; if (v < 128) out += (char)v; else out += '?'; }
        else out += e; }
      else out += c;
      if (out.length() > maxLen) return 0;
    }
    return 0;
  }
  int e = p; while (e < (int)j.length() && j[e] != ',' && j[e] != '}' && j[e] != ' ' && j[e] != '\n' && j[e] != '\r') e++;
  out = j.substring(p, e); return out.length() ? 2 : 0;
}
bool rmIsInt(const String& s) { if (!s.length() || s.length() > 12) return false; int i = s[0] == '-' ? 1 : 0; if (i >= (int)s.length()) return false; for (; i < (int)s.length(); i++) if (!isdigit((uint8_t)s[i])) return false; return true; }
uint8_t rmCmdCode(const String& c) { for (uint8_t i = 1; i <= RM_NCMD; i++) if (c == RM_NAMES[i]) return i; return 0; }
#include "rmapi.h"   // 2.9.9: api tunnel helpers (crypto, base64, JSON, allowlist)

// Checks one command JSON. Returns 0 accepted (cmd filled) or 1 sig / 2 time / 3 replay / 4 bad.
// now = unix seconds (0 = no clock). Records the nonce on success.
uint8_t rmCheck(const String& body, const uint8_t* key, long long now, RmCmd& cmd, String* gOut = nullptr) {
  String c, g, t, n, h; int tg;
  if (rmVal(body, "c", c) != 1 || rmVal(body, "n", n) != 1 || rmVal(body, "h", h) != 1 || rmVal(body, "t", t) != 2 || !rmIsInt(t)) return 4;
  uint8_t code = rmCmdCode(c); if (!code) return 4;
  if (!rmNonceOk(n)) return 4;
  tg = rmVal(body, "g", g, code == 7 ? RM_G_MAX : 600);   // g is signed exactly as sent (string content, or the number's text)
  if (code == 7 && (tg != 1 || !rmGShapeOk(g))) return 4;                                               // api: "<iv hex>.<base64>"
  if (tg == 2 && g == "null") g = "";
  if (tg == 2 && g.length() && !rmIsInt(g)) return 4;
  int colon = g.indexOf(':');
  if (code == 2 && g.length() && (!rmIsInt(g) || g[0] == '-' || g.length() > 4)) return 4;              // meal: grams
  if (code == 6 && (colon < 1 || colon > 5 || colon != (int)g.length() - 2 || (g[colon + 1] != '0' && g[colon + 1] != '1') || !rmIsInt(g.substring(0, colon)) || g[0] == '-')) return 4;  // label: "<id>:<1|0>"
  if (code != 2 && code != 6 && code != 7 && g.length()) return 4;                                                  // others: no g
  long long tv = atoll(t.c_str());
  if (!rmEqCT(rmSign(key, c, g, tv, n), h)) return 1;
  if (now < 1700000000LL) return 2;
  if (tv > now + RM_WINDOW_S || tv < now - RM_WINDOW_S) return 2;
  uint64_t nh = rmNonceHash(n);
  for (uint16_t i = 0; i < rmNonceN; i++) if (nh == rmNonce[i]) return 3;
  rmNonce[rmNonceI] = nh;
  rmNonceI = (rmNonceI + 1) % RM_RING; if (rmNonceN < RM_RING) rmNonceN++;
  cmd.c = code; cmd.g = -1; cmd.id = 0; cmd.bark = 0;
  if (code == 2 && g.length()) cmd.g = (int16_t)atol(g.c_str());
  if (code == 6) { cmd.id = (uint16_t)atol(g.substring(0, colon).c_str()); cmd.bark = g[colon + 1] == '1'; }
  if (gOut) *gOut = g;
  return 0;
}

#ifndef RM_HOST_TEST
// ---- settings
String rmNewTopic() { const char* a = "abcdefghijklmnopqrstuvwxyz0123456789"; String t = "dt-"; for (int i = 0; i < 16; i++) t += a[esp_random() % 36]; return t; }
String rmNewKey() { uint8_t b[16]; esp_fill_random(b, 16); return rmHex(b, 16); }
void rmSave() { prefs.begin("remote", false); prefs.putString("rkey", rmKey); prefs.putString("rtopic", rmTopic); prefs.putBool("ron", rmOn); prefs.end(); }
void rmLoad() {
  prefs.begin("remote", true);
  String k = prefs.getString("rkey", ""), t = prefs.getString("rtopic", ""); bool on = prefs.getBool("ron", false);
  prefs.end();
  uint8_t tmp[16];
  bool fresh = false;
  if (!rmUnhex(k, tmp, 16)) { k = rmNewKey(); fresh = true; }
  if (!t.startsWith("dt-") || t.length() != 19) { t = rmNewTopic(); fresh = true; }
  xSemaphoreTake(rmMux, portMAX_DELAY); rmKey = k; rmTopic = t; rmOn = on; xSemaphoreGive(rmMux);
  if (fresh) rmSave();
}
void rmReset() {
  String k = rmNewKey(), t = rmNewTopic();
  xSemaphoreTake(rmMux, portMAX_DELAY); rmKey = k; rmTopic = t; rmSince = "2m"; rmNonceN = 0; rmNonceI = 0; rmPendStatus = ""; xSemaphoreGive(rmMux);
  rmLastCmdT = 0; rmLastCmd = ""; rmLastErr = "";
  rmSave();
}

// ---- status (built in loop(): reads the loop's own state)
String rmStatus(bool ok, const String& last, const String& msg) {
  time_t now = time(nullptr);
  String lm = "";
  if (rmLastMealT > 0) { struct tm t; localtime_r(&rmLastMealT, &t); time_t nw = now; struct tm tn; localtime_r(&nw, &tn);
    if (t.tm_yday == tn.tm_yday && t.tm_year == tn.tm_year) { char b[8]; strftime(b, sizeof b, "%H:%M", &t); lm = b; } }
  String j = "{\"v\":\"" + String(RM_VER) + "\",\"t\":" + String((long long)now) + ",\"ok\":" + (ok ? "true" : "false");
  j += ",\"last\":" + askJ(last) + ",\"msg\":" + askJ(msg);
  j += ",\"food\":" + String(outOfFood ? "0" : "null");            // no level sensor: 0 = empty/jammed, null = unknown
  j += ",\"treats\":" + String(sum24(today.treats));
  j += ",\"lastMeal\":" + askJ(lm) + ",\"jam\":" + ((outOfTreats || outOfFood) ? "true" : "false") + ",\"online\":true}";
  return j;
}
void rmQueueStatus(const String& j) {
  xSemaphoreTake(rmMux, portMAX_DELAY); rmPendStatus = j; xSemaphoreGive(rmMux);
  rmWake = true; rmLastStatusMs = millis();
}
const char* rmWhyHe(const char* w) {
  if (!strcmp(w, "cleaning") || !strcmp(w, "emptying")) return "המתקן במצב ניקוי";
  if (!strcmp(w, "meal")) return "ארוחה רצה עכשיו";
  if (!strcmp(w, "cal")) return "כיול רץ עכשיו";
  if (!strcmp(w, "treat")) return "חטיף אחר יוצא עכשיו";
  if (!strcmp(w, "motor")) return "המנוע עסוק";
  return "המתקן עסוק";
}

// ---- the network task (core 0)
bool rmHttp(HTTPClient& h, WiFiClientSecure& c, const String& url) {
  c.setInsecure(); c.setTimeout(4);
  h.setConnectTimeout(4000); h.setTimeout(4000); h.setReuse(false);
  return h.begin(c, url);
}
void rmPostStatusNow() {
  String body, topic;
  xSemaphoreTake(rmMux, portMAX_DELAY); body = rmPendStatus; rmPendStatus = ""; topic = rmTopic; xSemaphoreGive(rmMux);
  if (!body.length()) return;
  rmTokUse(); WiFiClientSecure c; HTTPClient h; int code = -1;
  if (rmHttp(h, c, "https://ntfy.sh/" + topic + "-s")) { h.addHeader("Content-Type", "text/plain; charset=utf-8"); code = h.POST(body); h.end(); }
  rmPostCode = code;
  Serial.printf("[remote] status %d\n", code);
}
void rmPollNow() {
  String topic, since; uint8_t key[16];
  xSemaphoreTake(rmMux, portMAX_DELAY); topic = rmTopic; since = rmSince; bool kok = rmUnhex(rmKey, key, 16); xSemaphoreGive(rmMux);
  if (!kok) return;
  rmTokUse(); WiFiClientSecure c; HTTPClient h; int code = -1;
  if (!rmHttp(h, c, "https://ntfy.sh/" + topic + "-c/json?poll=1&since=" + since)) { rmPollCode = -1; return; }
  h.useHTTP10(true);                                  // plain body, no chunk markers
  code = h.GET(); rmPollCode = code;
  if (code == 200) {
    rmPollMs = millis(); if (!rmPollMs) rmPollMs = 1;
    if (!rmBootEpoch && clockValid()) rmBootEpoch = (long long)time(nullptr) - (long long)(millis() / 1000);
    WiFiClient* s = h.getStreamPtr(); uint32_t t0 = millis(); int lines = 0;
    while (s && (s->connected() || s->available()) && millis() - t0 < 4000 && lines < 40) {
      if (!s->available()) { vTaskDelay(10); continue; }
      String line = s->readStringUntil('\n'); lines++;
      if (line.length() > 4600) continue;
      String ev, id, msg;
      if (rmVal(line, "event", ev) != 1 || ev != "message") continue;
      if (rmVal(line, "id", id) == 1 && id.length() && id.length() <= 32) {
        bool same; xSemaphoreTake(rmMux, portMAX_DELAY); same = (topic == rmTopic); if (same) rmSince = id; xSemaphoreGive(rmMux);
        if (!same) break;                              // topic was reset meanwhile
      }
      if (rmVal(line, "message", msg, 4000) != 1) continue;
      { String tv; if (rmBootEpoch && rmVal(line, "time", tv) == 2 && rmIsInt(tv) && atoll(tv.c_str()) < rmBootEpoch - 2) continue; }   // published before this boot: never replayed
      RmCmd cmd; String gv; uint8_t r = rmCheck(msg, key, clockValid() ? (long long)time(nullptr) : 0, cmd, &gv);
      Serial.printf("[remote] cmd %s -> %u\n", msg.substring(0, 24).c_str(), r);
      if (r == 0 && cmd.c == 7) { rmLastCmdT = time(nullptr); if (rmApiPendN < 2) rmApiPend[rmApiPendN++] = gv; rmFastUntil = millis() + RM_FAST_FOR_MS; }
      else if (r == 0) { if (rmQ) xQueueSend(rmQ, &cmd, 0); }
      else if (r <= 3) rmRejKind = r;
    }
  }
  h.end();
}
// ================================================================ 2.9.9: api tunnel (all in the remote task, core 0)

struct RmSpool {                                   // the plaintext answer R: RAM up to 2600 B, then a LittleFS temp file
  String ram; File f; bool onFs = false, fail = false; size_t n = 0;
  static const size_t CAP = 140 * 1024;
  void add(const char* p, size_t k) {
    if (fail || !k) return;
    if (n + k > CAP) { fail = true; return; }
    if (!onFs) {
      if (n + k <= RM_INLINE_MAX) { ram.concat(p, k); n += k; return; }
      if (!fsOk || LittleFS.totalBytes() - LittleFS.usedBytes() < 32768) { fail = true; return; }
      f = LittleFS.open("/rmr.tmp", "w"); if (!f) { fail = true; return; }
      onFs = true; f.write((const uint8_t*)ram.c_str(), ram.length()); ram = "";
    }
    if (((n + k) >> 12) != (n >> 12) && LittleFS.totalBytes() - LittleFS.usedBytes() < 8192) { fail = true; return; }
    f.write((const uint8_t*)p, k); n += k;
  }
  void add(const String& s) { add(s.c_str(), s.length()); }
  void esc(const char* p, size_t k) { rmJEsc(p, k, [&](const char* q, size_t m) { add(q, m); }); }
  void esc(const String& s) { esc(s.c_str(), s.length()); }
  void close() { if (onFs && f) f.close(); }
  void drop() { close(); if (onFs) LittleFS.remove("/rmr.tmp"); onFs = false; }
};
bool rmBlockedCam = false;

// one answer item whose body is the text `body`
void rmItemText(RmSpool& sp, int status, const char* ct, const String& body, bool first) {
  if (!first) sp.add(",");
  sp.add("{\"s\":" + String(status) + ",\"ct\":\""); sp.esc(ct, strlen(ct)); sp.add("\",\"b\":\""); sp.esc(body); sp.add("\"}");
}
void rmItemErr(RmSpool& sp, int status, const char* he, bool home, bool first) {
  String b = String("{\"ok\":false,\"error\":\"") + he + "\"" + (home ? ",\"home\":true" : "") + "}";
  rmItemText(sp, status, "application/json", b, first);
}

// ---- a request to the feeder's own web server over 127.0.0.1 (the normal handlers answer it in loop(), like a phone at home)
// body source: either `body` (small) or an upload stream (multipart built by rmUpload)
bool rmReadLine(WiFiClient& c, String& line, uint32_t ms) {
  line = ""; uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    if (c.available()) { char ch = c.read(); if (ch == '\n') { line.trim(); return true; } if (line.length() < 300) line += ch; }
    else if (!c.connected()) return line.length() > 0;
    else vTaskDelay(2);
  }
  return false;
}
// reads status line + headers; returns the HTTP status (0 = failed). Fills ct, clen (-1 unknown), fname
int rmReadHead(WiFiClient& c, String& ct, long& clen, String& fname) {
  String l; if (!rmReadLine(c, l, 8000)) return 0;
  int sp1 = l.indexOf(' '); if (sp1 < 0) return 0; int st = l.substring(sp1 + 1, sp1 + 4).toInt(); if (st < 100) return 0;
  ct = "application/json"; clen = -1; fname = "";
  for (int k = 0; k < 24; k++) {
    if (!rmReadLine(c, l, 4000)) return 0;
    if (!l.length()) return st;
    String lo = l; lo.toLowerCase();
    if (lo.startsWith("content-type:")) { ct = l.substring(13); ct.trim(); if (ct.length() > 80) ct = ct.substring(0, 80); }
    else if (lo.startsWith("content-length:")) clen = l.substring(15).toInt();
    else if (lo.startsWith("content-disposition:")) { int q = lo.indexOf("filename="); if (q >= 0) { fname = l.substring(q + 9); fname.replace("\"", ""); fname.trim(); if (fname.length() > 40) fname = ""; } }
  }
  return st;
}
// streams the response body into the spool as a JSON string; returns false on timeout / cap
bool rmReadBodyText(WiFiClient& c, long clen, RmSpool& sp) {
  uint8_t b[256]; long got = 0; uint32_t t0 = millis();
  while ((c.connected() || c.available()) && (clen < 0 || got < clen) && millis() - t0 < 10000) {
    int av = c.available(); if (av <= 0) { vTaskDelay(2); continue; }
    int k = c.read(b, av > 256 ? 256 : av); if (k <= 0) continue;
    sp.esc((const char*)b, k); got += k; t0 = millis();
    if (sp.fail) return false;
  }
  return clen < 0 || got >= clen;
}
void rmItemLoop(RmSpool& sp, const String& m, const String& p, const String& body, const String& ctReq, bool first) {
  WiFiClient c; c.setTimeout(8);
  if (!c.connect(IPAddress(127, 0, 0, 1), 80, 2000)) { rmItemErr(sp, 502, "המתקן לא הצליח לענות", false, first); return; }
  String req = m + " " + p + " HTTP/1.0\r\nHost: localhost\r\nConnection: close\r\n";
  if (m == "POST") req += String("Content-Type: ") + (ctReq.length() ? ctReq : String("application/x-www-form-urlencoded")) + "\r\nContent-Length: " + String(body.length()) + "\r\n";
  req += "\r\n"; req += body; c.print(req);
  String ct, fn; long clen; int st = rmReadHead(c, ct, clen, fn);
  if (!st) { c.stop(); rmItemErr(sp, 502, "המתקן לא הצליח לענות", false, first); return; }
  if (clen > (long)(RmSpool::CAP - sp.n - 300)) { c.stop(); rmItemErr(sp, 413, "התשובה גדולה מדי", false, first); return; }
  size_t mark = sp.n;
  if (!first) sp.add(",");
  sp.add("{\"s\":" + String(st) + ",\"ct\":\""); sp.esc(ct); sp.add("\",\"b\":\"");
  bool ok = rmReadBodyText(c, clen, sp); c.stop();
  if (!ok || sp.fail) { sp.fail = true; return; }
  sp.add("\"");
  if (fn.length()) { sp.add(",\"name\":\""); sp.esc(fn); sp.add("\""); }
  sp.add("}"); (void)mark;
}

// ---- camera photo through the tunnel: GET http://<camHost>/jpg  -> {"s":200,"ct":"image/jpeg","b64":..,"name":"cam.jpg"}
void rmItemCam(RmSpool& sp, bool first) {
  String h = cfg.camHost; h.trim();
  if (!h.length()) { rmItemErr(sp, 404, "אין מצלמה בהגדרות", false, first); return; }
  if (motorBusy() || dispBusy() || mealBusy() || stagingNow || cState) { rmItemErr(sp, 502, "המתקן עסוק עכשיו, נסה שוב בעוד רגע", false, first); return; }
  String addr = h;
  if (h.endsWith(".local")) { IPAddress ip = MDNS.queryHost(h.substring(0, h.length() - 6), 1500); if (ip == IPAddress(0, 0, 0, 0)) { rmItemErr(sp, 502, "המצלמה לא ענתה", false, first); return; } addr = ip.toString(); }
  HTTPClient http; http.setTimeout(4000);
  if (!http.begin("http://" + addr + "/jpg") || http.GET() != 200) { http.end(); rmItemErr(sp, 502, "המצלמה לא ענתה", false, first); return; }
  int sz = http.getSize();
  if (sz <= 0 || sz > 96000) { http.end(); rmItemErr(sp, 502, sz > 96000 ? "התמונה גדולה מדי" : "המצלמה לא ענתה", false, first); return; }     // 96 KB photo -> 128 KB base64 < CAP
  if (!first) sp.add(",");
  sp.add("{\"s\":200,\"ct\":\"image/jpeg\",\"b64\":\"");
  RmB64Enc e; auto out = [&](const char* q, size_t k) { sp.add(q, k); };
  WiFiClient* s = http.getStreamPtr(); uint8_t b[240]; int got = 0; uint32_t t0 = millis();
  while (got < sz && millis() - t0 < 6000 && !sp.fail) { int av = s->available(); if (av <= 0) { if (!http.connected()) break; vTaskDelay(2); continue; }
    int k = s->readBytes(b, av > 240 ? 240 : av); if (k <= 0) continue; e.put(b, k, out); got += k; t0 = millis(); }
  e.flush(out); http.end();
  sp.add("\",\"name\":\"cam.jpg\"}");
  if (got < sz) sp.fail = true;
}

// ---- upload: ntfy file (C || tag) -> decrypt while posting multipart to our own POST /api/sound; tag checked before the closing boundary
void rmItemUpload(RmSpool& sp, const uint8_t* K, const String& id, const String& p, const String& itemJson, int us, int ue, bool first) {
  String url, ivh, name, field; long long len = 0; uint8_t iv[16];
  String U = itemJson.substring(us, ue);
  if (rmJGetStr(U, "url", url, 200) != 1 || rmJGetStr(U, "iv", ivh, 40) != 1 || rmJGetInt(U, "len", len) != 1) { rmItemErr(sp, 400, "בקשה לא תקינה", false, first); return; }
  if (rmJGetStr(U, "name", name, 40) != 1) name = "f.wav";
  if (rmJGetStr(U, "field", field, 12) != 1) field = "f";
  for (char ch : name) if (!(isalnum((uint8_t)ch) || ch == '.' || ch == '-' || ch == '_')) { rmItemErr(sp, 400, "בקשה לא תקינה", false, first); return; }
  for (char ch : field) if (!isalnum((uint8_t)ch)) { rmItemErr(sp, 400, "בקשה לא תקינה", false, first); return; }
  if (!url.startsWith("https://ntfy.sh/file/") || url.indexOf("..") >= 0 || url.length() < 25 || !rmUnhex(ivh, iv, 16)) { rmItemErr(sp, 400, "בקשה לא תקינה", false, first); return; }
  for (int i = 21; i < (int)url.length(); i++) if (!(isalnum((uint8_t)url[i]) || url[i] == '.' || url[i] == '-' || url[i] == '_')) { rmItemErr(sp, 400, "בקשה לא תקינה", false, first); return; }
  if (len < 44 || len > 400000) { rmItemErr(sp, 413, "הקובץ גדול מדי", false, first); return; }
  // download
  rmTokUse(); WiFiClientSecure d; d.setInsecure(); d.setTimeout(6);
  if (!d.connect("ntfy.sh", 443, 5000)) { rmItemErr(sp, 502, "ההורדה נכשלה", false, first); return; }
  d.print(String("GET ") + url.substring(14) + " HTTP/1.0\r\nHost: ntfy.sh\r\nConnection: close\r\n\r\n");
  String dct; long dcl; String dfn; int dst = rmReadHead(d, dct, dcl, dfn);
  if (dst != 200 || (dcl >= 0 && dcl != len + 32)) { d.stop(); rmItemErr(sp, 502, "ההורדה נכשלה", false, first); return; }
  // loopback multipart POST
  String q = p; String bnd = "----dtU9x7";
  String head = "--" + bnd + "\r\nContent-Disposition: form-data; name=\"" + field + "\"; filename=\"" + name + "\"\r\nContent-Type: audio/wav\r\n\r\n";
  String tail = "\r\n--" + bnd + "--\r\n";
  WiFiClient c; c.setTimeout(8);
  if (!c.connect(IPAddress(127, 0, 0, 1), 80, 2000)) { d.stop(); rmItemErr(sp, 502, "המתקן לא הצליח לענות", false, first); return; }
  c.print("POST " + q + " HTTP/1.0\r\nHost: localhost\r\nConnection: close\r\nContent-Type: multipart/form-data; boundary=" + bnd + "\r\nContent-Length: " + String((long)(head.length() + len + tail.length())) + "\r\n\r\n" + head);
  uint8_t ke[16]; rmKEnc(K, ke); RmCtr ctr; ctr.begin(ke, iv); RmHmac hm; rmTagBegin(hm, K, 'u', id, ivh);
  uint8_t b[512]; long left = len; uint32_t t0 = millis(); bool okRead = true;
  while (left > 0) {
    int av = d.available(); if (av <= 0) { if ((!d.connected()) || millis() - t0 > 12000) { okRead = false; break; } vTaskDelay(2); continue; }
    int k = d.read(b, (long)av > left ? (int)(left > 512 ? 512 : left) : (av > 512 ? 512 : av)); if (k <= 0) continue;
    hm.update(b, k); ctr.apply(b, k); c.write(b, k); left -= k; t0 = millis();
  }
  uint8_t tag[32], calc[32]; int tg = 0; t0 = millis();
  while (okRead && tg < 32 && millis() - t0 < 5000) { int av = d.available(); if (av <= 0) { if (!d.connected()) break; vTaskDelay(2); continue; } int k = d.read(tag + tg, 32 - tg); if (k > 0) tg += k; }
  hm.finish(calc); ctr.end(); d.stop();
  uint8_t diff = 0; for (int i = 0; i < 32; i++) diff |= calc[i] ^ tag[i];
  if (!okRead || tg < 32 || diff) { c.stop(); rmItemErr(sp, 422, "הקובץ הגיע פגום, לא נשמר", false, first); return; }   // no closing boundary -> the web handler aborts the upload, old sound stays
  c.print(tail);
  String ct, fn; long clen; int st = rmReadHead(c, ct, clen, fn);
  if (!st) { c.stop(); rmItemErr(sp, 502, "המתקן לא הצליח לענות", false, first); return; }
  if (!first) sp.add(",");
  sp.add("{\"s\":" + String(st) + ",\"ct\":\""); sp.esc(ct); sp.add("\",\"b\":\"");
  rmReadBodyText(c, clen, sp); c.stop(); sp.add("\"}");
}

// ---- publish
int rmPostTopic(const String& topic, const String& body) {
  rmTokUse(); WiFiClientSecure c; HTTPClient h; int code = -1;
  if (rmHttp(h, c, "https://ntfy.sh/" + topic)) { h.addHeader("Content-Type", "text/plain; charset=utf-8"); code = h.POST(body); h.end(); }
  return code;
}
// answer as an ntfy file: X-Message = header JSON, body = AES-CTR(R) || tag
bool rmPublishFile(const String& topic, const uint8_t* K, const String& id, RmSpool& sp, const uint8_t* iv) {
  rmTokUse(); String ivh = rmHex(iv, 16); size_t flen = sp.n + 32;
  String hm_ = rmFileMsg(K, id, ivh, flen);
  WiFiClientSecure c; c.setInsecure(); c.setTimeout(6);
  if (!c.connect("ntfy.sh", 443, 5000)) return false;
  c.print("PUT /" + topic + " HTTP/1.0\r\nHost: ntfy.sh\r\nX-Message: " + hm_ + "\r\nX-Filename: r.bin\r\nContent-Type: application/octet-stream\r\nContent-Length: " + String((long)flen) + "\r\nConnection: close\r\n\r\n");
  uint8_t ke[16]; rmKEnc(K, ke); RmCtr ctr; ctr.begin(ke, iv); RmHmac hm; rmTagBegin(hm, K, 'f', id, ivh);
  File f = LittleFS.open("/rmr.tmp", "r"); if (!f) { ctr.end(); c.stop(); return false; }
  uint8_t b[512]; bool ok = true;
  while (f.available()) { int k = f.read(b, 512); if (k <= 0) break; ctr.apply(b, k); hm.update(b, k); if (c.write(b, k) != (size_t)k) { ok = false; break; } }
  f.close(); uint8_t tag[32]; hm.finish(tag); ctr.end();
  if (ok) ok = c.write(tag, 32) == 32;
  String l; int st = 0; if (ok) { String ct, fn; long cl; st = rmReadHead(c, ct, cl, fn); }
  c.stop(); return ok && st == 200;
}

void rmApiRun(const String& g) {
  uint8_t key[16]; String topic; bool kok;
  xSemaphoreTake(rmMux, portMAX_DELAY); topic = rmTopic; kok = rmUnhex(rmKey, key, 16); xSemaphoreGive(rmMux);
  String Q; if (!kok || !rmOpenReq(key, g, Q)) return;
  String id; if (rmJGetStr(Q, "id", id, 16) != 1 || !rmIdOk(id)) return;
  int rs, re; if (rmJGet(Q.c_str(), Q.length(), 0, "r", rs, re) != 1 || Q[rs] != '[') return;
  // budget (local day)
  time_t nw = time(nullptr); struct tm tn; localtime_r(&nw, &tn);
  if (tn.tm_yday != rmApiDay) { rmApiDay = tn.tm_yday; rmApiToday = 0; }
  if (rmApiToday >= RM_API_DAY_MAX) return;                       // past the cap: no answer (stay under ntfy's 250/day)
  rmApiToday++; bool capped = rmApiToday >= RM_API_DAY_MAX;
  rmFastUntil = millis() + RM_FAST_FOR_MS; if (!rmFastUntil) rmFastUntil = 1; rmApiLastMs = millis();
  RmSpool sp; sp.add("{\"id\":\"" + id + "\",\"r\":[");
  int i = rmJWs(Q.c_str(), Q.length(), rs + 1); int nItems = 0;
  while (i < (int)Q.length() && Q[i] != ']' && nItems < RM_ITEMS_MAX) {
    int e = rmJSkip(Q.c_str(), Q.length(), i); if (e < 0) break;
    String item = Q.substring(i, e); bool first = nItems == 0; nItems++;
    i = rmJWs(Q.c_str(), Q.length(), e); if (i < (int)Q.length() && Q[i] == ',') i = rmJWs(Q.c_str(), Q.length(), i + 1);
    if (sp.fail) continue;
    String m, p, b, ct;
    if (rmJGetStr(item, "m", m, 6) != 1 || rmJGetStr(item, "p", p, 240) != 1) { rmItemErr(sp, 400, "בקשה לא תקינה", false, first); continue; }
    if (rmJGetStr(item, "b", b, 2700) < 0 || rmJGetStr(item, "ct", ct, 80) < 0) { rmItemErr(sp, 400, "בקשה לא תקינה", false, first); continue; }
    uint8_t cl = rmApiClass(m, p);
    if (capped) { rmItemErr(sp, 429, "הגעתי למכסת השליטה מרחוק להיום. מחר זה חוזר, ובבית הכול עובד", false, first); continue; }
    if (cl == 1) { rmItemErr(sp, 403, "זמין רק בבית", true, first); continue; }
    if (cl == 2) { rmItemErr(sp, 404, "לא קיים במתקן", false, first); continue; }
    if (cl == 3) { rmItemCam(sp, first); continue; }
    if (cl == 4) { int us, ue; if (rmJGet(item.c_str(), item.length(), 0, "u", us, ue) != 1 || item[us] != '{') { rmItemErr(sp, 400, "בקשה לא תקינה", false, first); continue; }
      rmItemUpload(sp, key, id, p, item, us, ue, first); continue; }
    if (ct.length() && ct != "application/x-www-form-urlencoded" && ct != "application/json" && ct != "text/plain") ct = "";
    rmItemLoop(sp, m, p, b, ct, first);
    vTaskDelay(1);
  }
  if (!sp.fail) sp.add("]}");
  if (sp.fail) {                                                   // too big / no room: answer every item with a short error
    sp.drop(); sp = RmSpool(); sp.add("{\"id\":\"" + id + "\",\"r\":[");
    for (int k = 0; k < (nItems ? nItems : 1); k++) rmItemErr(sp, 413, "התשובה גדולה מדי או שאין מקום בזיכרון המתקן", false, k == 0);
    sp.add("]}");
  }
  sp.close();
  uint8_t iv[16]; esp_fill_random(iv, 16);
  int code = -1;
  if (!sp.onFs) { String msg = rmSealInline(key, id, (const uint8_t*)sp.ram.c_str(), sp.ram.length(), iv); if (msg.length()) code = rmPostTopic(topic + "-r", msg); }
  else { code = rmPublishFile(topic + "-r", key, id, sp, iv) ? 200 : -2; sp.drop(); }
  rmPostCode = code;
  if (code == 429) rmSlowUntil = millis() + RM_SLOW_FOR_MS;
  Serial.printf("[remote] api %s items=%d bytes=%u -> %d\n", id.c_str(), nItems, (unsigned)sp.n, code);
}

void rmTask(void*) {
  uint32_t lastPoll = 0;
  for (;;) {
    bool on; xSemaphoreTake(rmMux, portMAX_DELAY); on = rmOn; xSemaphoreGive(rmMux);
    bool net = WiFi.status() == WL_CONNECTED && (WiFi.getMode() & WIFI_STA);
    if (on && net && ESP.getFreeHeap() > 60000 && !askBusy) {
      if (rmWake) { rmWake = false; rmPostStatusNow(); }
      uint32_t now = millis();
      rmTok += (now - (rmTokT ? rmTokT : now)) / 5000.0f; if (rmTok > 60) rmTok = 60; rmTokT = now;
      uint32_t every = ((int32_t)(rmSlowUntil - now) > 0) ? RM_SLOW_MS : ((int32_t)(rmFastUntil - now) > 0) ? (rmTok >= 15 ? RM_FAST_MS : 5000UL) : RM_POLL_MS;   // fast = 2 s while the budget lasts, then 5 s (= ntfy.sh refill)
      if (!lastPoll || now - lastPoll >= every) {
        lastPoll = now; rmPollNow();
        if (rmPollCode == 429) rmSlowUntil = millis() + RM_SLOW_FOR_MS;
        while (rmApiPendN) { String g = rmApiPend[0]; rmApiPend[0] = rmApiPend[1]; rmApiPend[1] = ""; rmApiPendN--; rmApiRun(g); lastPoll = millis(); }
      }
    }
    vTaskDelay(pdMS_TO_TICKS(rmWake ? 50 : 250));
  }
}

// ---- loop(): run accepted commands with the web buttons' own functions
void rmRun(const RmCmd& m) {
  bool ok = false; String msg; const char* name = RM_NAMES[m.c];
  rmLastCmdT = clockValid() ? time(nullptr) : 0; rmLastCmd = name; rmLastErr = "";
  switch (m.c) {
    case 1:                                          // same as POST /api/treat
      if (cfg.mode == 2) msg = "מצב רק מדידה: לא נותן חטיפים";
      else if (cleanOn) msg = "המתקן במצב ניקוי";
      else { rmFollowTreats = sum24(today.treats); ok = dispense(true, "manual");
        if (ok) { msg = "חטיף יוצא"; rmFollow = 1; } else msg = rmWhyHe(busyWhy()); }
      break;
    case 2: {                                        // same as POST /api/meal-now (grams: same clamp as /api/meal g=)
      uint16_t keep = cfg.mealG;
      if (m.g >= 0) cfg.mealG = constrain((int)m.g, 10, 600);
      ok = startMeal(0);
      cfg.mealG = keep;
      if (ok) { msg = "ארוחה התחילה"; rmFollow = 2; } else msg = rmWhyHe(busyWhy());
      break; }
    case 3: ok = true; msg = mealBusy() ? "ארוחה רצה עכשיו" : cleanOn ? "המתקן במצב ניקוי" : "המתקן מחובר"; break;
    case 4: ok = cleanStart(); msg = ok ? "מצב ניקוי התחיל" : "הניקוי כבר רץ"; break;   // same as POST /api/clean-start
    case 5: cleanExit(); ok = true; msg = "מצב ניקוי הסתיים"; break;                   // same as POST /api/clean-done
    case 6: ok = barkLabel(m.id, m.bark);                                               // same as POST /api/bark-label
      msg = ok ? (m.bark ? "תודה! נשמר כנביחה שלה" : "תודה! נשמר כ\"לא נביחה\"") : "הקול הזה כבר לא ברשימה"; break;
  }
  Serial.printf("[remote] run %s ok=%d\n", name, ok);
  rmQueueStatus(rmStatus(ok, name, msg));
}
void remoteTick() {
  if (!rmQ) return;
  RmCmd m;
  if (xQueueReceive(rmQ, &m, 0) == pdTRUE) { if (rmOn) rmRun(m); return; }
  uint8_t rj = rmRejKind;
  if (rj) { rmRejKind = 0; rmLastErr = rj == 1 ? "sig" : rj == 2 ? "time" : "replay";
    if (rmOn && (!rmLastRejMs || millis() - rmLastRejMs > RM_REJ_GAP_MS)) { rmLastRejMs = millis();
      rmQueueStatus(rmStatus(false, "reject", rj == 1 ? "פקודה עם קוד לא נכון. צמד שוב את האפליקציה" : rj == 2 ? "השעון בטלפון או במתקן לא מכוון" : "פקודה כפולה, לא בוצעה")); } }
  if (rmFollow == 1 && !dispBusy()) {
    rmFollow = 0; bool fell = sum24(today.treats) > rmFollowTreats;
    rmQueueStatus(rmStatus(fell, "treat", fell ? "החטיף נפל" : (outOfTreats ? "לא נפל חטיף. אולי נגמרו החטיפים" : "לא ראיתי חטיף נופל")));
  } else if (rmFollow == 2 && !mealBusy()) {
    rmFollow = 0; rmQueueStatus(rmStatus(!outOfFood, "meal", mLast.length() ? mLast.substring(0, 120) : String("הארוחה הסתיימה")));
  }
  if (rmOn && (!rmLastStatusMs || millis() - rmLastStatusMs >= RM_STATUS_MS)) rmQueueStatus(rmStatus(true, "", "עדכון"));
}

// ---- local endpoints (home network only — the feeder's own web server)
void rmSendState() {
  String j = "{\"on\":" + String(rmOn ? "true" : "false") + ",\"topic\":" + askJ(rmTopic) + ",\"key\":" + askJ(rmKey);
  j += ",\"pushTopic\":" + askJ(cfg.ntfyTopic) + ",\"pushOn\":" + String(cfg.pushOn ? "true" : "false");
  j += ",\"last\":" + String((long long)rmLastCmdT) + ",\"lastCmd\":" + askJ(rmLastCmd) + ",\"err\":" + askJ(rmLastErr);
  j += ",\"poll\":" + String((int)rmPollCode) + ",\"pollAgo\":" + String(rmPollMs ? (long)((millis() - rmPollMs) / 1000) : -1L);
  j += ",\"clock\":" + String(clockValid() ? "true" : "false") + ",\"api\":" + String((int)rmApiToday) + ",\"fast\":" + String((int32_t)(rmFastUntil - millis()) > 0 ? "true" : "false") + "}";
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", j);
}
void handleRemoteGet() { rmSendState(); }
void handleRemoteSet() {
  if (server.hasArg("on")) {
    bool on = server.arg("on") == "1";
    xSemaphoreTake(rmMux, portMAX_DELAY); rmOn = on; xSemaphoreGive(rmMux);
    rmSave(); rmLastStatusMs = 0;                      // on -> first status right away
  }
  rmSendState();
}
void handleRemoteReset() { rmReset(); rmLastStatusMs = 0; rmSendState(); }

void setupRemote() {
  rmMux = xSemaphoreCreateMutex();
  rmQ = xQueueCreate(4, sizeof(RmCmd));
  rmLoad();
  server.on("/api/remote", HTTP_GET, handleRemoteGet);
  server.on("/api/remote", HTTP_POST, handleRemoteSet);
  server.on("/api/remote-reset", HTTP_POST, handleRemoteReset);
  xTaskCreatePinnedToCore(rmTask, "remote", 16384, nullptr, 1, nullptr, 0);
}
#endif
