/*
 * DogTreat — smart calm-rewarding treat dispenser (ESP32 + INMP441 + 28BYJ-48)
 * מתקן חטיפים חכם שמתגמל שקט
 *
 * Board:  ESP32 Dev Module (ESP32-WROOM-32 DevKit), Arduino-ESP32 core 3.x
 * Libs:   WiFiManager (tzapu) — everything else ships with the ESP32 core
 *
 * TRAINING RULE THAT MATTERS MOST: never reward right after barking.
 * חוק הזהב: אף פעם לא לתת חטיף מיד אחרי נביחה.
 *
 * Modes:
 *   HOME  ("בית")  — outside noise detected, then the room stays quiet for N s -> treat.
 *                    A bark cancels everything and starts a cooldown of continuous quiet.
 *   ALONE ("לבד")  — random-interval treats while quiet; any bark restarts the quiet timer.
 *
 * v2 adds: IR drop sensor + jam/empty detection (exactly one treat), MAX98357A speaker
 *          (your recorded voice, built-in training sounds), noise-training mode ("אימון לרעשים"),
 *          measure-only mode ("רק מדידה"), 90-day progress file in LittleFS ("התקדמות"),
 *          weekly summary on Fridays 12:00 (ntfy + optional WhatsApp via CallMeBot).
 * v3 adds: bark RECOGNITION instead of loudness only (barkml.h): every loud burst is scored from
 *          band energies, bark-band ratio, spectral flatness, zero-crossing rate, onset sharpness,
 *          duration and repetition. "Learn my dog" (הקלט נביחה) + "זה לא היה נביחה" corrections,
 *          sensitivity קפדני / רגיל / רגיש, event log with verdict + confidence %.
 *          Uncertain bursts ("אולי נביחה") never earn a treat — the golden rule wins every tie.
 * Partition scheme: "Huge APP (3MB No OTA/1MB SPIFFS)" — LittleFS uses the 1 MB data part.
 *
 * v2.9.9 (Nov 10 2026, same folder): everything in the app works from outside home — remote.h command "api" = encrypted tunnel for the page API (rmapi.h, REMOTE_PROTOCOL.md rev 3)
 * v2.9.8 (Nov 10 2026, same folder): "שליטה מרחוק" (remote.h) — signed commands from the app via ntfy.sh, from anywhere (default OFF)
 * v2.9.7 (Nov 10 2026, same folder): "כשהוא לא בטוח" (ask.h) — a sound in the "not sure" zone gets no treat (as before)
 *   and the feeder asks: a card on the page + optional ntfy push with כן/לא buttons -> /api/bark-label.
 *   Bark classifier v4 (barkml.h from bark-ml2: v3 features + 7 extras -> tiny MLP 18-12-1, BM_TPL_W 0.6): catches more barks with
 *   about half the false alarms on the held-out test. Saved template kept; saved "זה לא היה נביחה" marks migrated by bmLoadNegs().
 * v2.9.6 (Nov 10 2026, DogFeedTreat296): training upgrades (train296.h), all code-only, everything else as v2.9.5:
 *   treat grams counted against the day's food (300 g) and taken off the NEXT meal (never below 50 % of a meal; NO daily
 *   treat cap any more) · automatic difficulty up/down per engine (alone, doorbell, noise/street, motion) with treat thinning
 *   (the quiet she must keep grows with her success) · per-trigger numbers · "פעמון = דבר טוב" mode (4) · weight log
 *   (/api/weight, target 25 kg) · STOP on every page (POST /api/stop) · FAST TREAT: the treat wheel waits pre-staged at 85 %
 *   of a pocket so the treat falls ~0.5 s after the click (calibration on /meal) · "give a treat by hand" alert when a click
 *   was not paid. The v2.9.5 "קרא לו" (recall) feature is REMOVED (NITAY, Nov 10). Fix: dropWaitMs is saved again.
 *   New look for the phone pages (white / ink / blue, IBM Plex Sans Hebrew when online, no emoji icons).
 * v2.9.5 (Nov 10 2026, DogFeedTreat295): CONNECTION SELF-TEST ("בדיקת חיבורים") at /check (selftest.h, selftest_page.h).
 *   Automatic where the board can really know (mic I2S data + a clap, outdoor node packets + its mic level, camera JPEG over
 *   WiFi, IR / PIR pin changes when you block / wave), guided where it can't (speaker, buzzer, LED colours, wheel movement).
 *   Adds a pull-down on the mic SD pin so a loose data wire reads 0. While the test page is open (120 s after the last call)
 *   test sounds/waves are not counted as barks or outside events. Everything else is v2.9.4, unchanged.
 * v2.9.4 (Nov 5 2026, DogFeedTreat294): CLEANING MODE ("מצב ניקוי"). App button on /meal (POST /api/clean-start) or hold the
 *   board's BOOT button 5 s: the TREAT wheel then the FOOD wheel slowly turn one full turn + 1 pocket each (the last food
 *   falls into the tray), then the motor is released so the wheel cartridge lifts out. LED double-blinks blue; no meals,
 *   no treats (manual / auto / camera / PIR / outdoor / training) until "סיימתי לנקות" (POST /api/clean-done) or a short
 *   press. Saved across power cuts. On exit both clutches are re-synced. Everything else is v2.9, unchanged.
 * v2.9 (Nov 4 2026, DogFeedTreat29, for the v2.9 printed feeder): ONE unit gives treats AND food, no wheel swapping.
 *   Two wheels on ONE shaft, one 28BYJ-48. Each wheel sits on a printed one-way clutch (2 pawls, 24 teeth -> a pawl
 *   engages every 7.5 deg = 96 half-steps) and a printed anti-backdrive tongue, so:
 *     motor direction A (+) turns ONLY the TREAT wheel (left), direction B (-) turns ONLY the FOOD wheel (right).
 *   The firmware tracks the motor, the shaft (gear backlash 'clutchSlack', default 48 half-steps) and each wheel's
 *   clutch phase step by step (wheel angle + pawl contact point), so a reversal takes up exactly the free play and each
 *   pocket is an exact half turn (2304 half-steps) of its own wheel. After every move the other wheel's pawl is parked
 *   half a tooth from a tooth face (never on the edge), so the next reversal is predictable. State is kept in flash;
 *   after a power cut in the middle of a move it re-syncs both clutches (each wheel may move up to 7.5 deg once).
 *   No backward moves of a wheel are possible any more: "agitate" and the anti-jam "jiggle" rock the motor only inside
 *   the other wheel's free play and hammer the jammed wheel forward again.
 *   Treat = 1 pocket of the TREAT wheel (~1.7 g); meal = FOOD wheel pockets (~1.8 g) until 150 g, chute-clear wait as v2.8.
 *   Separate calibration per wheel (/meal: "run 20 pockets" for each), separate jam/empty per wheel.
 *   LEDs unchanged: green treat, blue meal, red blink = jam/empty, white boot.
 *
 * v2.7.1 (Nov 3 2026, for the v2.7.1 3D-printed feeder):
 *   - BUZZER FIX: NITAY's active buzzer module is LOW-level trigger (beeps while the pin is LOW). The pin now idles HIGH and
 *     the click is two short LOW pulses (an active buzzer has its own tone, so tone() is not used). Power it from 3V3.
 *   - RGB: the KY-016 module (3 resistors on board, common "-") is driven on all 3 channels: R GPIO4, G GPIO13, B GPIO5.
 *     green = dispensing, blue = meal running (food version), red blink = jam / empty, white flash = boot.
 *     POST /api/led-test cycles R, G, B (1 s each) to check the wiring.
 *   - v2.8: TWO swappable wheels (setting 'wheel'): SMALL 3 pockets (1536 half-steps each, ~1.8 g) / BIG 2 pockets (2304, ~2.6 g);
 *     each has its own grams-per-pocket calibration. Treat = exactly one pocket of the wheel that is in.
 *   - FOOD VERSION (DogFeed): same hopper + 3-trough wheel serves two amounts:
 *       treat = 1 trough (1/3 wheel turn, ~4.6 ml ~ 2 g of kibble) -- the old "treat" button/auto-treats, unchanged
 *       meal  = 150 g (setting) served in small portions: one trough, wait until the IR at the chute mouth sees the
 *               chute clear, next trough ... until the grams are reached. Two meals a day at set times (07:30 / 18:30 default).
 *     grams per trough is a calibration number: POST /api/meal-cal?troughs=20 (cup under the chute, tray out),
 *     weigh, then POST /api/meal-cal?grams=G. Page: http://dogtreat.local/meal
 * NOT TESTED ON REAL HARDWARE. Calibrate before trusting it.
 */
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <Preferences.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <WiFiManager.h>      // tzapu/WiFiManager
#include <ESP_I2S.h>          // core 3.x I2S driver
#include <time.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <LittleFS.h>
#include <base64.h>
#include "webpage.h"
#include "font_suez.h"    // UI redesign: display font served from flash at /f.woff2 (look only)
#include "sounds.h"
#include "dayrec.h"
#include "barkml.h"     // v3: bark classifier (shared with DogTreatOutdoor)

// ---------------------------------------------------------------- motor choice / בחירת מנוע
// 0 = 28BYJ-48 stepper + ULN2003 (recommended)  ·  1 = SG90 servo (if you already have one)
#define USE_SERVO 0
#if USE_SERVO
#include <ESP32Servo.h>
static const int PIN_SERVO = 13;     // SG90 orange wire
Servo servo;
#endif

// ---------------------------------------------------------------- pins / פינים
static const int PIN_I2S_SCK = 26;   // INMP441 SCK
static const int PIN_I2S_WS  = 25;   // INMP441 WS
static const int PIN_I2S_SD  = 33;   // INMP441 SD (data in)
static const int PIN_STEP[4] = {19, 18, 17, 16};  // ULN2003 IN1..IN4
static const int PIN_BUZZER  = 23;   // v2.7.1: ACTIVE buzzer module, I/O pin (VCC -> 3V3). "click" / קליקר
#define BUZZER_ACTIVE_LOW 1          // v2.7.1: his module beeps while I/O is LOW -> idle HIGH. Set 0 for a HIGH-trigger module.
static const int PIN_LED     = 4;    // KY-016 R (red)   -- resistors are on the module
#if !USE_SERVO
static const int PIN_LED_G   = 13;   // v2.7.1: KY-016 G (green)
#else
static const int PIN_LED_G   = -1;   // GPIO13 is the servo -> red/blue only
#endif
static const int PIN_LED_B   = 5;    // v2.7.1: KY-016 B (blue). GPIO5 flickers for a moment at boot (harmless)
static const int PIN_BOARD_LED = 2;  // on-board blue LED
static const int PIN_CLEAN_BTN = 0;  // v2.9.4: cleaning button = the board's own BOOT button (GPIO0, pulled up on every DevKit).
                                     //   Hold 5 s = cleaning mode, short press = done. An outside push button may go GPIO0 -> GND. -1 = none.
static const int PIN_PIR     = 27;   // PIR motion sensor OUT (HC-SR501 / AM312) — optional
// v2: IR drop sensor in the chute (FC-51 obstacle module or a 3/5 mm break-beam pair). OUT -> GPIO32.
//     Both kinds pull OUT LOW when a treat is in the beam. חיישן אינפרא-אדום במגלשה
static const int PIN_IR      = 32;
// v2: MAX98357A I2S amplifier on the ESP32's SECOND I2S port (the mic keeps port 0).
//     Separate pins so mic and speaker never share a clock. רמקול
static const int PIN_SPK_BCLK = 14;  // MAX98357A BCLK
static const int PIN_SPK_LRC  = 21;  // MAX98357A LRC (word select)
static const int PIN_SPK_DIN  = 22;  // MAX98357A DIN (data out of the ESP32)

// ---------------------------------------------------------------- audio constants
static const uint32_t SAMPLE_RATE = 16000;
static const int      WINDOW_MS   = 50;                               // one level reading every 50 ms
static const int      WINDOW_SAMPLES = SAMPLE_RATE * WINDOW_MS / 1000; // 800
// INMP441: -26 dBFS at 94 dB SPL  ->  dB SPL ≈ dBFS + 120 (approximate, uncalibrated)
static const float    DBFS_TO_SPL = 120.0f;

I2SClass i2s;                 // port 0: INMP441 microphone (RX)
I2SClass spk;                 // port 1: MAX98357A speaker (TX)
WebServer server(80);
Preferences prefs;

// ---------------------------------------------------------------- settings (NVS)
struct Settings {
  bool    enabled        = true;
  uint8_t mode           = 0;      // 0 = home (בית), 1 = alone (לבד), 2 = measure-only (רק מדידה), 3 = noise training (אימון לרעשים), 4 = doorbell = good thing (v2.9.6)
  float   noiseDb        = 8.0f;   // dB above baseline that counts as a sound event
  float   barkDb         = 20.0f;  // dB above baseline that a bark reaches
  uint16_t barkMinMs     = 80;     // bark burst length window
  uint16_t barkMaxMs     = 700;    // v3: a bark-like burst longer than this = "loud & long" (not calm, not counted)
  uint8_t barkSens       = 1;      // v3: 0 קפדני · 1 רגיל · 2 רגיש
  float   quietAfterNoiseS = 2.5f; // HOME: quiet needed after an outside noise
  uint16_t barkCooldownS = 10;     // quiet needed after a bark before ANY auto treat
  uint16_t minGapS       = 30;     // min seconds between auto treats
  uint16_t postTreatIgnoreS = 15;  // ignore "noise" triggers while she eats (crunching)
  uint16_t aloneMinS     = 120;    // ALONE: random interval (level 1)
  uint16_t aloneMaxS     = 360;
  uint8_t  difficulty    = 1;      // 1..10, stretches the alone interval
  uint16_t dailyMax      = 40;
  bool    clicker        = true;   // beep before each treat
  uint16_t stepsPerTreat = 1536;   // v2.7.1-food: 1 trough = 1/3 of a wheel turn (4608 / 3) = one treat portion
  // ---- v2.7.1-food: meals (same hopper + 3-trough wheel). 150 g x 2 a day, served a little at a time
  bool    mealsOn        = true;
  uint16_t mealG         = 150;    // grams per meal (NITAY, Nov 3 2026)
  uint16_t meal1Min      = 7 * 60 + 30;   // 07:30 -- minutes after midnight (Israel time). GUESS: set yours on /meal
  uint16_t meal2Min      = 18 * 60 + 30;  // 18:30
  float   gPerTrough     = 1.7f;   // v2.9: TREAT wheel, grams one pocket gives. ESTIMATE (4.2 ml x 0.40 g/ml) -> calibrate on /meal
  // ---- v2.8: two swappable wheels (same housing, tool-free): 0 = SMALL (3 pockets, 1536 steps each), 1 = BIG (2 pockets, 2304 steps each)
  uint8_t  wheel         = 0;
  float   gPerBig        = 1.8f;   // v2.9: FOOD wheel, grams one pocket gives. ESTIMATE (4.5 ml x 0.40 g/ml) -> calibrate on /meal
  uint16_t clutchSlack   = 48;     // v2.9: gear + gearbox backlash, motor half-steps (the shaft does not move for this long after a reversal)
  uint16_t stepsPerRev   = 4608;   // half-steps per WHEEL turn = 4096 x 18/16 gears. Some 28BYJ-48 are 63.68:1 -> 4586
  uint16_t clearMs       = 1500;   // the chute mouth must look clear this long before the next trough
  uint8_t  portionGapS   = 2;      // and at least this long after the last trough fell (slower = calmer)
  uint8_t  noIrGapS      = 25;     // IR not fitted: fixed wait between troughs
  uint8_t  mealPauseMin  = 20;     // chute stays blocked this long (she stopped eating / sensor dirty) -> meal ends early
  uint16_t stepUs        = 1500;   // µs per half-step (lower = faster, weaker)
  bool    reverseDir     = false;
  String  ntfyTopic      = "";     // empty = no notifications
  uint8_t ntfyBarks      = 5;      // barks within 60 s that count as an "episode"
  // outside triggers: street motion (camera webhook / PIR) and the outdoor mic node
  bool    srcIndoor      = true;   // HOME mode: indoor-mic "outside noise" trigger
  bool    srcOutdoor     = true;   // outdoor mic node (ESP-NOW or /api/motion?src=mic)
  bool    srcMotion      = true;   // camera webhook + PIR
  float   eventQuietS    = 5.0f;   // after motion/outdoor sound: no bark for N s -> treat
  uint16_t motionCooldownS = 20;   // motion: ignore repeated triggers for N s
  float   outdoorMinDb   = 10.0f;  // outdoor mic: dB above the street baseline = event (sensitivity)
  uint16_t outdoorMinMs  = 300;    // outdoor mic: minimum sound length (wind clicks are shorter)
  uint16_t outdoorCooldownS = 30;  // outdoor mic: ignore repeated events (cars, wind)
  String  camHost        = "";     // ESP32-CAM address, e.g. dogcam.local or 192.168.1.60 (empty = no camera)
  bool    ntfyOnTreat    = false;  // also push (with a photo) on every treat
  bool    pushOn         = false;  // v2.9.7: master switch "התראות לטלפון" (old boards with a topic: on)
  bool    askPush        = true;   // v2.9.7: push a question when not sure a sound was a bark
  uint8_t askBand        = 20;     // v2.9.7: "לא בטוח" zone width below the bark threshold, % points (0 = never ask)
  uint8_t barkWindowMin  = 10;     // "barked / didn't bark in the last N minutes"
  String  token          = "";     // optional shared secret for /api/motion and the outdoor node
  // ---- v2: drop sensor / jams
  bool    irFitted       = true;   // IR sensor in the chute is connected (turn off if not fitted)
  // ---- v2.9.6
  uint16_t dailyFoodG    = 300;    // food per day, grams (meals + treats count against it)
  bool    treatFromMeal  = true;   // treat grams come off the next meal
  uint8_t  mealFloorPct  = 50;     // a meal is never cut below this % of its size
  bool    autoDiff       = true;   // difficulty moves by itself from her success rate
  uint8_t  lvl[3]        = {1, 1, 1};   // levels 1..10: doorbell, noise/street, motion (alone = difficulty)
  uint8_t  bellVol       = 8;      // "פעמון = דבר טוב": bell volume % now (starts very quiet)
  uint8_t  bellVolMax    = 40;     // ... never louder than this
  float   targetKg       = 25.0f;  // weight target
  bool    stageOn        = true;   // fast treat: wait with the treat wheel pre-staged
  uint8_t  stagePct      = 85;     // ... at this % of a pocket (calibrate on /meal)
  uint16_t dropWaitMs    = 1500;   // after the wheel turns: wait this long for the beam to break
  uint8_t retries        = 3;      // jiggle + retry this many times before declaring a jam
  uint8_t emptyAfter     = 3;      // N dispenses in a row with no drop -> "out of treats"
  uint16_t agitateSteps  = 160;    // agitator wiggle before each treat (half-steps each way)
  // ---- v2: speaker / voice
  bool    spkFitted      = true;   // MAX98357A + speaker connected (off = buzzer click only)
  uint8_t volume         = 70;     // 0..100 for your voice
  bool    voiceOnTreat   = true;   // play your recorded clip with every treat
  // ---- v2: noise training
  uint8_t trainSound     = 2;      // 0 doorbell, 1 dog bark, 2 alternate
  uint8_t trainVol       = 10;     // current training volume % (steps up over days)
  uint8_t trainStep      = 5;      // +% per day when she passes
  uint8_t trainVolMax    = 80;
  uint8_t trainPassPct   = 70;     // pass rate needed to step up the next day
  uint16_t trainGapMinS  = 60;     // random gap between trials
  uint16_t trainGapMaxS  = 180;
  float   trainQuietS    = 3.0f;   // quiet after the sound -> treat
  uint8_t trainMaxDay    = 20;     // trials per day
  // ---- v2: weekly summary
  bool    weekly         = true;   // Friday 12:00 summary to ntfy (+ WhatsApp if set)
  String  cmbPhone       = "";     // CallMeBot: your number, e.g. 972501234567
  String  cmbKey         = "";     // CallMeBot apikey
} cfg;

void loadSettings() {
  prefs.begin("dogtreat", true);
  cfg.enabled  = prefs.getBool("en", cfg.enabled);
  cfg.mode     = prefs.getUChar("mode", cfg.mode);
  cfg.noiseDb  = prefs.getFloat("nDb", cfg.noiseDb);
  cfg.barkDb   = prefs.getFloat("bDb", cfg.barkDb);
  cfg.barkMinMs= prefs.getUShort("bMin", cfg.barkMinMs);
  cfg.barkMaxMs= prefs.getUShort("bMax", cfg.barkMaxMs);
  cfg.barkSens = prefs.getUChar("bSens", cfg.barkSens);
  cfg.quietAfterNoiseS = prefs.getFloat("qAN", cfg.quietAfterNoiseS);
  cfg.barkCooldownS = prefs.getUShort("bCool", cfg.barkCooldownS);
  cfg.minGapS  = prefs.getUShort("gap", cfg.minGapS);
  cfg.postTreatIgnoreS = prefs.getUShort("pti", cfg.postTreatIgnoreS);
  cfg.aloneMinS= prefs.getUShort("aMin", cfg.aloneMinS);
  cfg.aloneMaxS= prefs.getUShort("aMax", cfg.aloneMaxS);
  cfg.difficulty = prefs.getUChar("diff", cfg.difficulty);
  cfg.dailyMax = prefs.getUShort("max", cfg.dailyMax);
  cfg.clicker  = prefs.getBool("clk", cfg.clicker);
  cfg.stepsPerTreat = prefs.getUShort("spt", cfg.stepsPerTreat);
  cfg.stepUs   = prefs.getUShort("sUs", cfg.stepUs);
  cfg.reverseDir = prefs.getBool("rev", cfg.reverseDir);
  cfg.ntfyTopic= prefs.getString("ntfy", cfg.ntfyTopic);
  cfg.ntfyBarks= prefs.getUChar("ntB", cfg.ntfyBarks);
  cfg.srcIndoor = prefs.getBool("sIn", cfg.srcIndoor);
  cfg.srcOutdoor= prefs.getBool("sOut", cfg.srcOutdoor);
  cfg.srcMotion = prefs.getBool("sMot", cfg.srcMotion);
  cfg.eventQuietS = prefs.getFloat("evQ", cfg.eventQuietS);
  cfg.motionCooldownS = prefs.getUShort("mCool", cfg.motionCooldownS);
  cfg.token     = prefs.getString("tok", cfg.token);
  cfg.camHost   = prefs.getString("cam", cfg.camHost);
  cfg.ntfyOnTreat = prefs.getBool("ntT", cfg.ntfyOnTreat);
  cfg.pushOn  = prefs.isKey("pOn") ? prefs.getBool("pOn", false) : (cfg.ntfyTopic.length() > 0);   // v2.9.7
  cfg.askPush = prefs.getBool("askP", cfg.askPush);
  cfg.askBand = min((int)prefs.getUChar("askB", cfg.askBand), 40);
  cfg.barkWindowMin = prefs.getUChar("bWin", cfg.barkWindowMin);
  cfg.outdoorMinDb = prefs.getFloat("oDb", cfg.outdoorMinDb);
  cfg.outdoorMinMs = prefs.getUShort("oMs", cfg.outdoorMinMs);
  cfg.outdoorCooldownS = prefs.getUShort("oCool", cfg.outdoorCooldownS);
  cfg.irFitted   = prefs.getBool("irF", cfg.irFitted);
  cfg.dailyFoodG = prefs.getUShort("food", cfg.dailyFoodG); cfg.treatFromMeal = prefs.getBool("tFM", cfg.treatFromMeal);   // v2.9.6
  cfg.mealFloorPct = prefs.getUChar("mFl", cfg.mealFloorPct); cfg.autoDiff = prefs.getBool("aDif", cfg.autoDiff);
  cfg.lvl[0] = prefs.getUChar("lvD", cfg.lvl[0]); cfg.lvl[1] = prefs.getUChar("lvN", cfg.lvl[1]); cfg.lvl[2] = prefs.getUChar("lvM", cfg.lvl[2]);
  cfg.bellVol = prefs.getUChar("bVol", cfg.bellVol); cfg.bellVolMax = prefs.getUChar("bVMx", cfg.bellVolMax);
  cfg.targetKg = prefs.getFloat("tKg", cfg.targetKg); cfg.stageOn = prefs.getBool("stOn", cfg.stageOn); cfg.stagePct = prefs.getUChar("stPc", cfg.stagePct);
  cfg.dropWaitMs = prefs.getUShort("dWait", cfg.dropWaitMs);
  cfg.retries    = prefs.getUChar("retr", cfg.retries);
  cfg.emptyAfter = prefs.getUChar("empN", cfg.emptyAfter);
  cfg.agitateSteps = prefs.getUShort("agit", cfg.agitateSteps);
  cfg.mealsOn    = prefs.getBool("mOn", cfg.mealsOn);     cfg.mealG = prefs.getUShort("mG", cfg.mealG);
  cfg.meal1Min   = prefs.getUShort("m1", cfg.meal1Min);   cfg.meal2Min = prefs.getUShort("m2", cfg.meal2Min);
  cfg.wheel = prefs.getUChar("whl", cfg.wheel); cfg.gPerBig = prefs.getFloat("gpb29", cfg.gPerBig); cfg.clutchSlack = prefs.getUShort("cs29", cfg.clutchSlack);
  cfg.gPerTrough = prefs.getFloat("gpt29", cfg.gPerTrough); cfg.stepsPerRev = prefs.getUShort("spr", cfg.stepsPerRev);
  cfg.clearMs    = prefs.getUShort("mClr", cfg.clearMs);  cfg.portionGapS = prefs.getUChar("mGap", cfg.portionGapS);
  cfg.noIrGapS   = prefs.getUChar("mNoIr", cfg.noIrGapS); cfg.mealPauseMin = prefs.getUChar("mPau", cfg.mealPauseMin);
  cfg.spkFitted  = prefs.getBool("spkF", cfg.spkFitted);
  cfg.volume     = prefs.getUChar("vol", cfg.volume);
  cfg.voiceOnTreat = prefs.getBool("vOT", cfg.voiceOnTreat);
  cfg.trainSound = prefs.getUChar("tSnd", cfg.trainSound);
  cfg.trainVol   = prefs.getUChar("tVol", cfg.trainVol);
  cfg.trainStep  = prefs.getUChar("tStep", cfg.trainStep);
  cfg.trainVolMax= prefs.getUChar("tVMax", cfg.trainVolMax);
  cfg.trainPassPct = prefs.getUChar("tPass", cfg.trainPassPct);
  cfg.trainGapMinS = prefs.getUShort("tGMin", cfg.trainGapMinS);
  cfg.trainGapMaxS = prefs.getUShort("tGMax", cfg.trainGapMaxS);
  cfg.trainQuietS  = prefs.getFloat("tQ", cfg.trainQuietS);
  cfg.trainMaxDay  = prefs.getUChar("tMax", cfg.trainMaxDay);
  cfg.weekly     = prefs.getBool("wk", cfg.weekly);
  cfg.cmbPhone   = prefs.getString("cmbP", cfg.cmbPhone);
  cfg.cmbKey     = prefs.getString("cmbK", cfg.cmbKey);
  if (cfg.mode > 4) cfg.mode = 0;
  prefs.end();
}

void saveSettings() {
  prefs.begin("dogtreat", false);
  prefs.putBool("en", cfg.enabled);       prefs.putUChar("mode", cfg.mode);
  prefs.putFloat("nDb", cfg.noiseDb);     prefs.putFloat("bDb", cfg.barkDb);
  prefs.putUShort("bMin", cfg.barkMinMs); prefs.putUShort("bMax", cfg.barkMaxMs); prefs.putUChar("bSens", cfg.barkSens);
  prefs.putFloat("qAN", cfg.quietAfterNoiseS);
  prefs.putUShort("bCool", cfg.barkCooldownS);
  prefs.putUShort("gap", cfg.minGapS);    prefs.putUShort("pti", cfg.postTreatIgnoreS);
  prefs.putUShort("aMin", cfg.aloneMinS); prefs.putUShort("aMax", cfg.aloneMaxS);
  prefs.putUChar("diff", cfg.difficulty); prefs.putUShort("max", cfg.dailyMax);
  prefs.putBool("clk", cfg.clicker);      prefs.putUShort("spt", cfg.stepsPerTreat);
  prefs.putUShort("sUs", cfg.stepUs);     prefs.putBool("rev", cfg.reverseDir);
  prefs.putString("ntfy", cfg.ntfyTopic); prefs.putUChar("ntB", cfg.ntfyBarks);
  prefs.putBool("sIn", cfg.srcIndoor);    prefs.putBool("sOut", cfg.srcOutdoor);
  prefs.putBool("sMot", cfg.srcMotion);   prefs.putFloat("evQ", cfg.eventQuietS);
  prefs.putUShort("mCool", cfg.motionCooldownS); prefs.putString("tok", cfg.token);
  prefs.putString("cam", cfg.camHost); prefs.putBool("ntT", cfg.ntfyOnTreat);
  prefs.putBool("pOn", cfg.pushOn); prefs.putBool("askP", cfg.askPush); prefs.putUChar("askB", cfg.askBand);   // v2.9.7
  prefs.putUChar("bWin", cfg.barkWindowMin);
  prefs.putFloat("oDb", cfg.outdoorMinDb); prefs.putUShort("oMs", cfg.outdoorMinMs);
  prefs.putUShort("oCool", cfg.outdoorCooldownS);
  prefs.putBool("irF", cfg.irFitted);     prefs.putUShort("dWait", cfg.dropWaitMs);   // v2.9.6: dWait was inside a comment in 2.9.5
  prefs.putUShort("food", cfg.dailyFoodG); prefs.putBool("tFM", cfg.treatFromMeal); prefs.putUChar("mFl", cfg.mealFloorPct);   // v2.9.6
  prefs.putBool("aDif", cfg.autoDiff); prefs.putUChar("lvD", cfg.lvl[0]); prefs.putUChar("lvN", cfg.lvl[1]); prefs.putUChar("lvM", cfg.lvl[2]);
  prefs.putUChar("bVol", cfg.bellVol); prefs.putUChar("bVMx", cfg.bellVolMax); prefs.putFloat("tKg", cfg.targetKg);
  prefs.putBool("stOn", cfg.stageOn); prefs.putUChar("stPc", cfg.stagePct);
  prefs.putUChar("retr", cfg.retries);    prefs.putUChar("empN", cfg.emptyAfter);
  prefs.putUShort("agit", cfg.agitateSteps);
  prefs.putBool("mOn", cfg.mealsOn);       prefs.putUShort("mG", cfg.mealG);
  prefs.putUShort("m1", cfg.meal1Min);     prefs.putUShort("m2", cfg.meal2Min);
  prefs.putUChar("whl", cfg.wheel); prefs.putFloat("gpb29", cfg.gPerBig); prefs.putUShort("cs29", cfg.clutchSlack);
  prefs.putFloat("gpt29", cfg.gPerTrough);   prefs.putUShort("spr", cfg.stepsPerRev);
  prefs.putUShort("mClr", cfg.clearMs);    prefs.putUChar("mGap", cfg.portionGapS);
  prefs.putUChar("mNoIr", cfg.noIrGapS);   prefs.putUChar("mPau", cfg.mealPauseMin);
  prefs.putBool("spkF", cfg.spkFitted);   prefs.putUChar("vol", cfg.volume);
  prefs.putBool("vOT", cfg.voiceOnTreat);
  prefs.putUChar("tSnd", cfg.trainSound); prefs.putUChar("tVol", cfg.trainVol);
  prefs.putUChar("tStep", cfg.trainStep); prefs.putUChar("tVMax", cfg.trainVolMax);
  prefs.putUChar("tPass", cfg.trainPassPct);
  prefs.putUShort("tGMin", cfg.trainGapMinS); prefs.putUShort("tGMax", cfg.trainGapMaxS);
  prefs.putFloat("tQ", cfg.trainQuietS);  prefs.putUChar("tMax", cfg.trainMaxDay);
  prefs.putBool("wk", cfg.weekly);
  prefs.putString("cmbP", cfg.cmbPhone);  prefs.putString("cmbK", cfg.cmbKey);
  prefs.end();
}

// ---------------------------------------------------------------- stats / סטטיסטיקה
struct DayStats {
  uint16_t barks[24];
  uint16_t treats[24];
  uint16_t noises[24];
  int32_t  dayKey;           // yyyymmdd (or -1 if clock unknown)
} today;

struct HistDay { int32_t dayKey; uint16_t barks; uint16_t treats; };
static const int HIST_DAYS = 14;
HistDay hist[HIST_DAYS];    // hist[0] = yesterday … older

struct LogEvent { uint32_t t; uint8_t type; float db; uint8_t conf; uint16_t bid; };   // v3: conf % (255 = n/a), bid = burst id (0 = none)
// type: 0 bark · 1 noise · 2 treat-auto · 3 treat-manual · 4 loud/long
//       5 camera motion · 6 PIR motion · 7 outdoor sound · 8 treat after outside event · 9 barked -> no treat · 10 skipped (cooldown/limit)
//  v2: 11 jam (תקיעה) · 12 out of treats · 13 double drop · 14 training sound played (db = volume %)
//      15 training: quiet -> treat · 16 training: barked -> no treat · 17 chute sensor blocked · 18 refilled
//  v3: 19 maybe a bark -> no treat (not counted) · 20 "learn my dog" recording saved · 21 marked "not a bark" · 22 marked "a bark"
static const int LOG_N = 40;
LogEvent evlog[LOG_N];
int evHead = 0, evCount = 0;

bool clockValid() { return time(nullptr) > 1700000000; }
int currentHour() {
  if (!clockValid()) return (millis() / 3600000UL) % 24;
  struct tm t; time_t now = time(nullptr); localtime_r(&now, &t); return t.tm_hour;
}
int32_t currentDayKey() {
  if (!clockValid()) return -1;
  struct tm t; time_t now = time(nullptr); localtime_r(&now, &t);
  return (t.tm_year + 1900) * 10000 + (t.tm_mon + 1) * 100 + t.tm_mday;
}
uint16_t sum24(const uint16_t* a) { uint16_t s = 0; for (int i = 0; i < 24; i++) s += a[i]; return s; }

void saveStats() {
  prefs.begin("dogstats", false);
  prefs.putBytes("today", &today, sizeof(today));
  prefs.putBytes("hist", hist, sizeof(hist));
  prefs.end();
}
void loadStats() {
  memset(&today, 0, sizeof(today)); today.dayKey = -1;
  memset(hist, 0, sizeof(hist));
  prefs.begin("dogstats", true);
  if (prefs.getBytesLength("today") == sizeof(today)) prefs.getBytes("today", &today, sizeof(today));
  if (prefs.getBytesLength("hist") == sizeof(hist))   prefs.getBytes("hist", hist, sizeof(hist));
  prefs.end();
}
// Called often: when the date changes, push today into history and start a new day.
void progressRoll(int32_t k);
void rollDayIfNeeded() {
  int32_t k = currentDayKey();
  if (k < 0) return;                       // no clock yet
  progressRoll(k);                         // v2: 90-day progress file
  if (today.dayKey == k) return;
  if (today.dayKey > 0) {                  // a real previous day -> history
    for (int i = HIST_DAYS - 1; i > 0; i--) hist[i] = hist[i - 1];
    hist[0] = { today.dayKey, sum24(today.barks), sum24(today.treats) };
    memset(today.barks, 0, sizeof(today.barks));
    memset(today.treats, 0, sizeof(today.treats));
    memset(today.noises, 0, sizeof(today.noises));
  }
  today.dayKey = k;                        // first sync after boot keeps counts gathered so far
  saveStats();
}
void logEvent(uint8_t type, float db, uint8_t conf = 255, uint16_t bid = 0) {
  evlog[evHead] = { (uint32_t)(clockValid() ? time(nullptr) : millis() / 1000), type, db, conf, bid };
  evHead = (evHead + 1) % LOG_N; if (evCount < LOG_N) evCount++;
}


// ---------------------------------------------------------------- v2: progress file (90 days, LittleFS)
// One fixed-size record per day in /days.bin, slot = day-number % 90, so it is a ring that
// survives reboots and never grows. מסך "התקדמות" קורא את הקובץ הזה.
// struct DayRec is in dayrec.h (Arduino needs types used in function signatures in a header)
static const int PROG_DAYS = 90;
static const char* PROG_FILE = "/days296.bin";   // v2.9.6: new name, the record changed (see dayrec.h)
DayRec day;                       // today, in RAM; saved every 10 min and at midnight
bool fsOk = false;
uint32_t lastProgSaveMs = 0;

int32_t dayNumber(int32_t key) {  // days since 1970-01-01 (civil calendar)
  int y = key / 10000, m = (key / 100) % 100, d = key % 100;
  y -= m <= 2; int era = (y >= 0 ? y : y - 399) / 400; int yoe = y - era * 400;
  int doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1; int doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return era * 146097 + doe - 719468;
}
void progEnsureFile() {
  if (!fsOk) return;
  File f = LittleFS.open(PROG_FILE, "r");
  size_t sz = f ? f.size() : 0; if (f) f.close();
  if (sz == sizeof(DayRec) * PROG_DAYS) return;
  f = LittleFS.open(PROG_FILE, "w"); DayRec z; memset(&z, 0, sizeof(z));
  for (int i = 0; i < PROG_DAYS; i++) f.write((uint8_t*)&z, sizeof(z));
  f.close();
}
bool progRead(int slot, DayRec& r) {
  memset(&r, 0, sizeof(r)); if (!fsOk) return false;
  File f = LittleFS.open(PROG_FILE, "r"); if (!f) return false;
  f.seek(slot * sizeof(DayRec)); bool ok = f.read((uint8_t*)&r, sizeof(r)) == sizeof(r); f.close(); return ok;
}
void progWrite(const DayRec& r) {
  if (!fsOk || r.dayKey <= 0) return;
  progEnsureFile();
  File f = LittleFS.open(PROG_FILE, "r+"); if (!f) return;
  f.seek((dayNumber(r.dayKey) % PROG_DAYS) * sizeof(DayRec)); f.write((const uint8_t*)&r, sizeof(r)); f.close();
}
void progSave() { lastProgSaveMs = millis(); if (day.dayKey > 0) progWrite(day); }
void addRec(DayRec& a, const DayRec& b) {   // a += b (counts gathered before the clock synced)
  a.barks += b.barks; a.episodes += b.episodes; a.triggers += b.triggers; a.reactions += b.reactions;
  a.treats += b.treats; a.jams += b.jams; a.doubles += b.doubles; a.trainTrials += b.trainTrials;
  a.trainPass += b.trainPass; a.calmN += b.calmN; a.calmSumS += b.calmSumS;
  a.quietMaxS = max(a.quietMaxS, b.quietMaxS); a.modeMask |= b.modeMask;
  a.treatDg += b.treatDg; a.mealG += b.mealG; a.bellTrials += b.bellTrials; a.bellPass += b.bellPass;   // v2.9.6
  a.aloneTry += b.aloneTry; a.alonePass += b.alonePass; a.spills += b.spills;
  for (int i = 0; i < 3; i++) { a.trigC[i] += b.trigC[i]; a.reactC[i] += b.reactC[i]; a.passC[i] += b.passC[i]; }
}
void trainDayRollover(const DayRec& y);
void trainOnBark();
void progressRoll(int32_t k) {
  if (day.dayKey == k) return;
  DayRec carry = day;                       // pre-sync counts (dayKey -1) or yesterday
  if (day.dayKey > 0) { progWrite(day); trainDayRollover(day); memset(&carry, 0, sizeof(carry)); }
  DayRec r; progRead(dayNumber(k) % PROG_DAYS, r);
  if (r.dayKey != k) { memset(&r, 0, sizeof(r)); r.dayKey = k; }   // a new day (old slot is overwritten)
  addRec(r, carry); r.dayKey = k;
  day = r; progSave();
}
// Read every stored day, oldest first. Returns the count.
int progAll(DayRec* out, int maxN) {
  int n = 0;
  File f = fsOk ? LittleFS.open(PROG_FILE, "r") : File();
  for (int i = 0; f && i < PROG_DAYS && n < maxN; i++) {
    DayRec r; if (f.read((uint8_t*)&r, sizeof(r)) != sizeof(r)) break;
    if (day.dayKey > 0 && r.dayKey == day.dayKey) r = day;        // today's live numbers
    if (r.dayKey > 0) out[n++] = r;
  }
  if (f) f.close();
  if (day.dayKey > 0) { bool have = false; for (int i = 0; i < n; i++) if (out[i].dayKey == day.dayKey) have = true;
    if (!have && n < maxN) out[n++] = day; }
  for (int i = 1; i < n; i++) { DayRec t = out[i]; int j = i - 1; while (j >= 0 && out[j].dayKey > t.dayKey) { out[j + 1] = out[j]; j--; } out[j + 1] = t; }
  return n;
}
// Verdict: last 7 full days vs first 7 full days (today is excluded: it is not over yet).
// returns -2 = not enough days, -1 better, 0 stable, 1 worse; pct = change in barks/day
int verdict(float& pct, int& fullDays, float& firstAvg, float& lastAvg) {
  static DayRec all[PROG_DAYS + 1];
  int n = progAll(all, PROG_DAYS + 1);
  if (n && all[n - 1].dayKey == day.dayKey) n--;               // drop today
  fullDays = n; pct = 0; firstAvg = lastAvg = 0;
  if (n < 7) return -2;
  for (int i = 0; i < 7; i++) { firstAvg += all[i].barks; lastAvg += all[n - 7 + i].barks; }
  firstAvg /= 7; lastAvg /= 7;
  if (firstAvg < 0.5f) { pct = 0; return lastAvg > 3 ? 1 : 0; }
  pct = (lastAvg - firstAvg) / firstAvg * 100.0f;
  if (pct <= -15) return -1; if (pct >= 15) return 1; return 0;
}

// --- live tracking of reactivity, episodes and quiet streaks
bool     trigOpen = false; uint32_t trigMs = 0;      // an outside trigger waiting 10 s for a bark
uint8_t  trigCat = 1;                                // v2.9.6: its kind (0 doorbell, 1 noise/street, 2 motion)
bool     epOpen = false;   uint32_t epStartMs = 0, epLastMs = 0;
uint32_t quietStreakStartMs = 0;                     // ALONE: current quiet streak
void noteTrigger(uint8_t cat) {                      // noise / motion / outdoor event / doorbell (v2.9.6: with its kind)
  uint32_t now = millis();
  if (trigOpen && now - trigMs < 10000) return;      // still inside the previous trigger's window
  trigOpen = true; trigMs = now; day.triggers++;
  trigCat = cat > 2 ? 1 : cat; day.trigC[trigCat]++;
}
void noteBarkForProgress() {
  uint32_t now = millis();
  day.barks++;
  if (trigOpen && now - trigMs <= 10000) { day.reactions++; day.reactC[trigCat]++; trigOpen = false; }
  if (!epOpen || now - epLastMs > 60000) {
    if (epOpen) { day.calmSumS += (epLastMs - epStartMs) / 1000; day.calmN++; }
    epOpen = true; epStartMs = now; day.episodes++;
  }
  epLastMs = now;
  quietStreakStartMs = now;
}
void progressTick() {
  uint32_t now = millis();
  if (trigOpen && now - trigMs > 10000) trigOpen = false;
  if (epOpen && now - epLastMs > 60000) { epOpen = false; day.calmSumS += (epLastMs - epStartMs) / 1000; day.calmN++; }
  day.modeMask |= (1 << cfg.mode);
  day.lvl[0] = cfg.difficulty; day.lvl[1] = cfg.lvl[0]; day.lvl[2] = cfg.lvl[1]; day.lvl[3] = cfg.lvl[2];   // v2.9.6
  if (cfg.mode == 1 && cfg.enabled) {
    if (!quietStreakStartMs) quietStreakStartMs = now;
    uint32_t s = (now - quietStreakStartMs) / 1000; if (s > day.quietMaxS) day.quietMaxS = s;
  } else quietStreakStartMs = 0;
  if (now - lastProgSaveMs > 600000UL) progSave();
}

// ---------------------------------------------------------------- v2.9.4: cleaning-mode flags (the logic sits after the meal clock)
bool    cleanOn = false;                      // cleaning mode: no meals, no treats of any kind until "סיימתי לנקות"
uint8_t cState  = 0;                          // 0 = not emptying (motor released), 1 = emptying TREAT wheel, 2 = emptying FOOD wheel
static const uint16_t CLEAN_STEP_US = 3000;   // µs per half-step while emptying: half the normal speed, gentler and stronger

// ---------------------------------------------------------------- stepper (non-blocking)
// 28BYJ-48 half-step sequence
static const uint8_t HALFSTEP[8][4] = {
  {1,0,0,0},{1,1,0,0},{0,1,0,0},{0,1,1,0},{0,0,1,0},{0,0,1,1},{0,0,0,1},{1,0,0,1}};
int      stepPhase = 0;
int32_t  stepsLeft = 0;         // signed: >0 forward, <0 backward
uint8_t  movePart = 0;          // 0 idle, 1 moving
uint32_t lastStepUs = 0;
uint32_t motorDoneMs = 0;
int32_t  moveQ[8]; uint8_t moveQN = 0, moveQI = 0;   // v2: a short list of moves (agitate / turn / jiggle)

void coilsOff() { for (int i = 0; i < 4; i++) digitalWrite(PIN_STEP[i], LOW); }  // saves power & heat
void stepOnce(int dir) {
  if (cfg.reverseDir) dir = -dir;
  stepPhase = (stepPhase + (dir > 0 ? 1 : 7)) % 8;
  for (int i = 0; i < 4; i++) digitalWrite(PIN_STEP[i], HALFSTEP[stepPhase][i]);
}
bool motorBusy() { return movePart != 0; }
// kind: 0 = agitate (rock inside the free play), 1 = turn one pocket of the active wheel, 2 = anti-jam (rock + hammer forward),
//       3 = turn one pocket (meal trough)  -- v2.9: every move belongs to the active wheel (0 = TREAT, +, 1 = FOOD, -)
int32_t customSteps = 0;
uint32_t troughSteps();
#if !USE_SERVO
// ---- v2.9 two-wheel clutch model (all positions in motor half-steps; 4608 = one wheel turn) ----
static const int32_t P_EFF = 96;            // one clutch engagement every 96 half-steps (24 teeth x 2 pawls half a tooth apart)
static const int32_t PHASE_MARGIN = 24;     // never stop with the idle wheel's pawl closer than this to a tooth edge
static const int8_t  WSIGN[2] = {+1, -1};   // TREAT wheel turns with motor +, FOOD wheel with motor -
uint8_t  activeWheel = 0;
int32_t  motPos = 0, shaftPos = 0;          // motor / shaft (shaft lags by up to clutchSlack/2 either way: gear backlash)
int32_t  uLock[2] = {0, 0};                 // per wheel, in its own drive sense: shaft position where its pawl touches a tooth
int32_t  wAng[2]  = {0, 0};                 // per wheel: how far it has turned (its drive sense), half-steps
bool     clutchValid = false;
void clutchUpdate() {                       // called after every half-step
  int32_t gb = cfg.clutchSlack / 2;
  if (motPos - shaftPos > gb) shaftPos = motPos - gb;
  else if (shaftPos - motPos > gb) shaftPos = motPos + gb;
  for (int w = 0; w < 2; w++) {
    int32_t u = WSIGN[w] * shaftPos;
    if (u >= uLock[w]) { wAng[w] += u - uLock[w]; uLock[w] = u; }               // pawl pushes: the wheel turns with the shaft
    else uLock[w] -= P_EFF * ((uLock[w] - u) / P_EFF);                          // pawl slips back over the teeth (wheel held by its tongue)
  }
}
int32_t otherGap(int w) { int o = 1 - w; return uLock[o] - WSIGN[o] * shaftPos; }   // 0..95: shaft travel before the idle wheel's pawl engages
void clutchSave() {
  prefs.begin("clutch29", false);
  prefs.putInt("m", motPos); prefs.putInt("s", shaftPos); prefs.putInt("l0", uLock[0]); prefs.putInt("l1", uLock[1]);
  prefs.putInt("a0", wAng[0]); prefs.putInt("a1", wAng[1]); prefs.putBool("ok", clutchValid); prefs.end();
}
void clutchLoad() {
  prefs.begin("clutch29", true);
  clutchValid = prefs.getBool("ok", false);
  motPos = prefs.getInt("m", 0); shaftPos = prefs.getInt("s", 0); uLock[0] = prefs.getInt("l0", 0); uLock[1] = prefs.getInt("l1", 0);
  wAng[0] = prefs.getInt("a0", 0); wAng[1] = prefs.getInt("a1", 0); prefs.end();
}
// motion = a short list of segments: SEG_REL (signed motor steps), SEG_DRIVE (step wheel w until wAng reaches a target),
// SEG_PARK (keep stepping wheel w until the idle wheel's pawl sits half a tooth from an edge)
enum { SEG_REL = 0, SEG_DRIVE = 1, SEG_PARK = 2, SEG_SYNC = 3 };
struct Seg { uint8_t type; uint8_t w; int32_t v; };
Seg segQ[16]; uint8_t segN = 0, segI = 0; bool segStarted = false;
uint32_t moveStepCount = 0;
void qSeg(uint8_t t, uint8_t w, int32_t v) { if (segN < 16) segQ[segN++] = {t, w, v}; }
int32_t pocketTarget(int w) {                // next pocket boundary of wheel w (exact share of a turn: 0, 2304, 4608, ...)
  int32_t r = cfg.stepsPerRev ? cfg.stepsPerRev : 4608, n = 2;
  int32_t k = (int32_t)floor((double)wAng[w] * n / r) + 1;
  return (int32_t)(((int64_t)k * r + n / 2) / n);
}
int32_t safeRock(int w) {                    // motor steps we may reverse without the idle wheel moving
  int32_t g = cfg.clutchSlack + otherGap(w) - PHASE_MARGIN;
  return max((int32_t)0, min((int32_t)cfg.agitateSteps, g));
}
void beginMotion() {
  segI = 0; segStarted = false; movePart = 1; lastStepUs = micros(); moveStepCount = 0;
  if (clutchValid) { clutchValid = false; clutchSave(); }      // a power cut mid-move -> re-sync next boot
}
void startClutchSync() {                     // after a fresh flash or a power cut mid-move: engage both pawls for sure
  segN = 0;                                  // (v2.9.6: a sync moves wAng, so a pre-staged wheel no longer counts as staged)
  qSeg(SEG_SYNC, 0, 0); qSeg(SEG_REL, 0, cfg.clutchSlack + P_EFF + 8);   // treat pawl now in contact for sure
  qSeg(SEG_SYNC, 1, 0); qSeg(SEG_REL, 1, -(int32_t)(2 * cfg.clutchSlack + P_EFF + 8)); // food pawl in contact for sure
  qSeg(SEG_SYNC, 2, 0); qSeg(SEG_PARK, 1, 0);
  beginMotion();
}
void startMotion(uint8_t kind) {
  int w = activeWheel, sg = WSIGN[w];
  segN = 0;
  if (kind == 0 || kind == 2) {               // rock: back inside the free play, forward again (x2), then drive on
    int32_t a = safeRock(w);
    if (kind == 2) a = max(a, (int32_t)8);
    if (a > 0) { qSeg(SEG_REL, w, -sg * a); qSeg(SEG_REL, w, sg * a); qSeg(SEG_REL, w, -sg * a / 2); qSeg(SEG_REL, w, sg * a / 2); }
    if (kind == 2) qSeg(SEG_DRIVE, w, wAng[w] + 40);                       // hammer the jammed wheel forward a little
  } else {
    qSeg(SEG_DRIVE, w, pocketTarget(w));      // exactly to the next pocket boundary of this wheel (free play taken up on the way)
    qSeg(SEG_PARK, w, 0);
  }
  if (segN == 0) qSeg(SEG_REL, w, 0);
  beginMotion();
}
void motorEnd() {
  movePart = 0; coilsOff(); motorDoneMs = millis();
  clutchValid = true; clutchSave();
}
void stepDir(int d) { stepOnce(d); motPos += d; clutchUpdate(); moveStepCount++; }
void motorTick() {
  if (!movePart) return;
  uint32_t now = micros();
  uint32_t su = cfg.stepUs; if (cState && su < CLEAN_STEP_US) su = CLEAN_STEP_US;   // v2.9.4: slow while emptying for cleaning
  if (now - lastStepUs < su) return;
  lastStepUs = now;
  while (segI < segN) {
    Seg &s = segQ[segI];
    if (s.type == SEG_SYNC) {                 // bookkeeping only (w = stage): 0 treat pawl unknown, 1 treat engaged + food unknown, 2 food engaged
      if (s.w == 0) { uLock[0] = WSIGN[0] * shaftPos + P_EFF; uLock[1] = WSIGN[1] * shaftPos + P_EFF; }
      if (s.w == 1) { uLock[0] = WSIGN[0] * shaftPos; uLock[1] = WSIGN[1] * shaftPos + P_EFF; }
      if (s.w == 2) { uLock[1] = WSIGN[1] * shaftPos; }
      segI++; segStarted = false; continue;
    }
    int sg = WSIGN[s.w > 1 ? 1 : s.w];
    if (s.type == SEG_REL) {
      if (!segStarted) { segStarted = true; }
      if (s.v == 0) { segI++; segStarted = false; continue; }
      int d = s.v > 0 ? 1 : -1; s.v -= d; stepDir(d); return;
    }
    if (s.type == SEG_DRIVE) {
      if (wAng[s.w] >= s.v) { segI++; segStarted = false; continue; }
      if (moveStepCount > 12000) { segI = segN; break; }                 // safety: never more than ~2.6 turns in one move
      stepDir(sg); return;
    }
    if (s.type == SEG_PARK) {
      int32_t g = otherGap(s.w);
      bool edge = g < PHASE_MARGIN || g > P_EFF - PHASE_MARGIN;
      if (!segStarted) { segStarted = true; s.v = edge ? 1 : 0; }
      if (s.v && (g < P_EFF / 2 - 6 || g > P_EFF / 2 + 6) && moveStepCount < 12000) { stepDir(sg); return; }   // <= 7.5 deg extra, counted in wAng
      segI++; segStarted = false; continue;
    }
    segI++;
  }
  motorEnd();
}
#else
// SG90: the disc swings 0° -> 180° (pocket over the exit hole), waits, and swings back.
uint32_t servoT0 = 0; uint8_t servoKind = 1;
void startMotion(uint8_t kind) { servo.attach(PIN_SERVO, 500, 2400); servoKind = kind; movePart = 1; servoT0 = millis(); }
void motorTick() {
  if (!movePart) return;
  uint32_t t = millis() - servoT0;
  int a0 = cfg.reverseDir ? 180 : 0, a1 = 180 - a0, w = cfg.reverseDir ? -20 : 20;
  if (servoKind != 1) {                               // wiggle: small swings around the rest position
    int reps = servoKind == 0 ? 2 : 4;
    if (t < (uint32_t)reps * 300) servo.write(a0 + (((t / 150) % 2) ? w : 0));
    else { servo.write(a0); servo.detach(); movePart = 0; motorDoneMs = millis(); }
    delay(5); return;
  }
  if (t < 700)        servo.write(a0 + (a1 - a0) * (int)t / 700);         // slow swing out
  else if (t < 1100)  servo.write(a1);                                    // treat drops
  else if (t < 1800)  servo.write(a1 + (a0 - a1) * (int)(t - 1100) / 700); // swing back (refills)
  else if (t < 2100)  servo.write(a0);
  else { servo.detach(); movePart = 0; motorDoneMs = millis(); } // detach = no buzzing
  delay(5);
}
#endif

// ---------------------------------------------------------------- v2: IR drop sensor
// The beam is LOW while a treat passes. A new drop is counted only after the beam was clear
// for 40 ms, so one tumbling treat is not counted twice.
volatile uint16_t irDrops = 0;
volatile uint32_t irClearUs = 0;
volatile bool     irBlocked = false;
volatile uint32_t irSeenTotal = 0;   // v2.9.6 help: beam breaks since power on (read-only diagnostics)
void IRAM_ATTR irISR() {
  bool blocked = digitalRead(PIN_IR) == LOW;
  uint32_t now = micros();
  if (blocked && !irBlocked) { if (now - irClearUs > 40000) { irDrops++; irSeenTotal++; } }
  else if (!blocked && irBlocked) irClearUs = now;
  irBlocked = blocked;
}

// ---------------------------------------------------------------- buzzer "click" (v2.7.1: active buzzer, LOW = beep)
inline void buzzerOn()  { digitalWrite(PIN_BUZZER, BUZZER_ACTIVE_LOW ? LOW : HIGH); }
inline void buzzerOff() { digitalWrite(PIN_BUZZER, BUZZER_ACTIVE_LOW ? HIGH : LOW); }
void clickSound() {   // two short beeps ≈ a clicker. Blocks ~100 ms only. Always ends OFF (pin HIGH).
  buzzerOn(); delay(25); buzzerOff(); delay(25);
  buzzerOn(); delay(25); buzzerOff(); delay(25);
}
// ---------------------------------------------------------------- v2.7.1: KY-016 RGB (all 3 channels, on/off)
void setRgb(bool r, bool g, bool b) {
  digitalWrite(PIN_LED, r ? HIGH : LOW);
  if (PIN_LED_G >= 0) digitalWrite(PIN_LED_G, g ? HIGH : LOW);
  digitalWrite(PIN_LED_B, b ? HIGH : LOW);
}

// ---------------------------------------------------------------- v2: speaker (MAX98357A on I2S port 1)
// Sounds play in their own FreeRTOS task so the mic, motor and web page keep running.
// Slots: "voice" = your recorded clip, "bell" / "bark" = training sounds (built-in unless you upload your own).
struct PlayReq { char slot[8]; uint8_t vol; };
QueueHandle_t playQ = nullptr;
volatile bool     playAbort = false;   // v2.9.6: STOP cuts a clip short
volatile bool     playing = false;
volatile uint32_t playEndMs = 0;
bool spkOk = false;

String slotPath(const char* slot) { return String("/snd/") + slot + ".wav"; }
bool slotHasFile(const char* slot) { return fsOk && LittleFS.exists(slotPath(slot)); }
bool soundAvailable(const char* slot) {          // voice needs a recording; bell/bark are built in
  if (slotHasFile(slot)) return true;
  return strcmp(slot, "bell") == 0 || strcmp(slot, "bark") == 0 || strcmp(slot, "click") == 0;
}
// perceived loudness is logarithmic: 50% slider ~ -12 dB, 10% ~ -40 dB
static inline int32_t volGain(uint8_t v) { return (int32_t)v * v * 65536 / 10000; }   // Q16

void writeScaled(int16_t* b, size_t n, int32_t g) {
  for (size_t i = 0; i < n; i++) b[i] = (int16_t)(((int32_t)b[i] * g) >> 16);
  spk.write((uint8_t*)b, n * 2);
}
void playMem(const int16_t* pcm, uint32_t n, int32_t g) {
  int16_t buf[256];
  for (uint32_t i = 0; i < n && !playAbort; i += 256) {
    uint32_t c = min((uint32_t)256, n - i);
    memcpy_P(buf, pcm + i, c * 2);
    writeScaled(buf, c, g);
  }
}
void playFile(const String& path, int32_t g) {
  File f = LittleFS.open(path, "r"); if (!f) return;
  uint8_t h[12]; if (f.read(h, 12) != 12 || memcmp(h, "RIFF", 4) || memcmp(h + 8, "WAVE", 4)) { f.close(); return; }
  uint32_t rate = 16000; uint16_t ch = 1, bits = 16;
  while (f.available() >= 8) {                       // walk the chunks to "data"
    uint8_t c[8]; f.read(c, 8); uint32_t len = c[4] | (c[5] << 8) | (c[6] << 16) | ((uint32_t)c[7] << 24);
    if (!memcmp(c, "fmt ", 4)) {
      uint8_t fm[16]; f.read(fm, 16); ch = fm[2] | (fm[3] << 8); rate = fm[4] | (fm[5] << 8) | (fm[6] << 16) | ((uint32_t)fm[7] << 24); bits = fm[14] | (fm[15] << 8);
      if (len > 16) f.seek(f.position() + len - 16);
    } else if (!memcmp(c, "data", 4)) {
      if (ch != 1 || bits != 16) break;               // the web page always uploads 16-bit mono
      if (rate != 16000) spk.configureTX(rate, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO);
      int16_t buf[256]; uint32_t left = len;
      while (left >= 2 && !playAbort) { size_t want = min((uint32_t)sizeof(buf), left); size_t got = f.read((uint8_t*)buf, want); if (!got) break; writeScaled(buf, got / 2, g); left -= got; }
      if (rate != 16000) spk.configureTX(16000, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO);
      break;
    } else f.seek(f.position() + len + (len & 1));
  }
  f.close();
}
void playTask(void*) {
  PlayReq r; int16_t z[256] = {0};
  for (;;) {
    if (xQueueReceive(playQ, &r, portMAX_DELAY) != pdTRUE) continue;
    if (playAbort) { playing = false; playEndMs = millis(); continue; }
    playing = true;
    int32_t g = volGain(r.vol);
    if (strcmp(r.slot, "click") == 0) {               // clicker through the speaker: two short chirps
      int16_t b[256];
      for (int k = 0; k < 2; k++) { float f = k ? 4000 : 3200;
        for (int i = 0; i < 400; i += 256) { int c = min(256, 400 - i); for (int j = 0; j < c; j++) b[j] = (int16_t)(20000 * sinf(6.2832f * f * (i + j) / 16000.0f)); writeScaled(b, c, g); }
        spk.write((uint8_t*)z, 320 * 2 / 2); }
    } else if (slotHasFile(r.slot)) playFile(slotPath(r.slot), g);
    else if (!strcmp(r.slot, "bell")) playMem(SND_BELL, SND_BELL_N, g);
    else if (!strcmp(r.slot, "bark")) playMem(SND_BARK, SND_BARK_N, g);
    for (int i = 0; i < 4; i++) spk.write((uint8_t*)z, sizeof(z));   // flush silence so the DMA tail is quiet
    playEndMs = millis(); playing = false;
  }
}
// Returns false if nothing will play (speaker off / no recording) — callers fall back to the buzzer.
bool playSound(const char* slot, uint8_t vol) {
  if (!cfg.spkFitted || !spkOk || !playQ || !soundAvailable(slot)) return false;
  PlayReq r; strncpy(r.slot, slot, sizeof(r.slot) - 1); r.slot[sizeof(r.slot) - 1] = 0; r.vol = vol;
  playAbort = false;
  playing = true;                                     // mark at once so the mic ignores it
  if (xQueueSend(playQ, &r, 0) == pdTRUE) return true;
  playing = false; return false;
}
void markerSound() {                                  // "click" before a treat
  if (!cfg.clicker) return;
  clickSound();                                       // the buzzer is the fallback and always fitted
}
void setupSpeaker() {
  spk.setPins(PIN_SPK_BCLK, PIN_SPK_LRC, PIN_SPK_DIN);
  spkOk = spk.begin(I2S_MODE_STD, 16000, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO);
  if (!spkOk) Serial.println("[spk] I2S TX init failed");
  playQ = xQueueCreate(4, sizeof(PlayReq));
  xTaskCreatePinnedToCore(playTask, "play", 4096, nullptr, 2, nullptr, 0);
}

// ---------------------------------------------------------------- audio state
float levelDb = 0;          // current window level (approx dB SPL)
float baseDb = 45;          // adaptive baseline (room noise)
float aboveDb = 0;
bool  burstActive = false;
uint32_t burstStartMs = 0, burstLastLoudMs = 0;
float burstPeak = 0;
uint32_t lastBarkMs = 0;            // last bark (or loud event) — 0 = never
uint32_t lastSoundMs = 0;           // last time level was above the noise threshold
uint32_t calibrateUntil = 0; double calibSum = 0; int calibN = 0;
int32_t  i2sBuf[WINDOW_SAMPLES];
float hpPrevIn = 0, hpPrevOut = 0;  // DC-blocking high-pass filter

// ---------------------------------------------------------------- training state
bool     pendingNoise = false;      // HOME: an outside noise is waiting for quiet
uint32_t pendingSinceMs = 0;
uint32_t lastTreatMs = 0;           // last treat of any kind
uint32_t lastAutoTreatMs = 0;
uint32_t aloneQuietStartMs = 0;     // ALONE: quiet timer start
uint32_t aloneTargetMs = 0;         // ALONE: current random interval
static const int RB_N = 64;
uint32_t recentBarkTimes[RB_N]; int rbIdx = 0;   // last 64 barks (millis), for "barked in the last N min"
int barksWithin(uint32_t ms) { uint32_t now = millis(); int n = 0; for (int i = 0; i < RB_N; i++) if (recentBarkTimes[i] && now - recentBarkTimes[i] < ms) n++; return n; }
bool     notifyTreatPending = false;
uint32_t lastNtfyMs = 0;
uint32_t lastStatsSaveMs = 0;
String   lastReason = "";           // shown in the UI
// outside events (camera / PIR / outdoor mic): "event -> no bark for N s -> treat"
bool     pendingExt = false;
uint8_t  extSrc = 0;                // log type of the source (5/6/7)
uint32_t extSinceMs = 0;
uint32_t lastMotionAcceptMs = 0, lastOutdoorAcceptMs = 0;
uint32_t lastOutdoorSeenMs = 0;     // outdoor node heartbeat
// v2.9.5 self-test counters (selftest.h): mic windows since reset, outdoor packets since reset
bool micInitOk = true;              // v2.9.6 help: I2S mic init result (read-only diagnostics)
uint32_t dgTreatOk = 0, dgTreatMiss = 0;   // v2.9.6 help: treats that fell / did not fall since power on
uint32_t stMicWin = 0, stMicZeroWin = 0, stMicSameWin = 0; float stMicMinDb = 999, stMicMaxDb = -999, stMicSumDb = 0;
uint32_t stOutPkts = 0, stOutBadTok = 0, stOutPir = 0, outPirTotal = 0; float stOutLvlMin = 999, stOutLvlMax = -999;   // outPirTotal: v2.9.5 recall
bool stActive();
// v2.9.6 state (logic in train296.h)
float    treatDebtG = 0;            // treat grams not yet taken off a meal (saved in NVS)
float    mealCutG = 0;              // grams the running / last meal gave up for treats
bool     staged = false, stagingNow = false;   // fast treat: the treat wheel waits pre-staged
int32_t  stagedAng = 0;
uint32_t stageDueMs = 0;            // re-stage at this time (0 = not due)
uint16_t stageDrops0 = 0, idleIrSeen = 0; bool stageIrHit = false, dStageIr = false;
uint32_t lastLatencyMs = 0;         // click -> IR saw the treat, last treat
uint32_t stopUntilMs = 0;           // STOP: automatic actions paused until then
bool     payByHand = false;         // a click was not paid by the feeder
bool     aloneFailMarked = false; uint32_t aloneFailMs = 0;   // ALONE: this interval already counted as "barked"
bool stopActive(); bool stageReady(); void addTreatGrams(float g); float mealTargetWithTreats();
void diffOutcome(uint8_t e, bool pass); void clickUnpaid(const char* why); uint8_t catOf(uint8_t src);
float quietMult(uint8_t L); void bellGoodTick();
float treatGToday(); float gramsLeftToday(); float nextMealG(); uint8_t ringPass(uint8_t e);
struct DiffRing { uint16_t bits; uint8_t n; }; extern DiffRing dRing[4]; extern String diffMsg; extern uint8_t bgState; extern uint32_t bgNextMs;
float    outdoorLevel = 0, outdoorBase = 0;
uint32_t lastOutdoorSeq = 0xFFFFFFFF;
volatile uint8_t espNowEvent = 0;   // set in the ESP-NOW callback (7 sound / 6 motion), handled in loop()
volatile float espNowDb = 0;
volatile uint16_t espNowMs = 0;
volatile uint8_t espNowBark = 255;  // v3: outdoor node bark score (255 = v2 node / not classified)
bool     pirPrev = false;

void pickAloneInterval() {
  float mult = 1.0f + (cfg.difficulty - 1) * 0.5f;          // level 10 = ×5.5
  uint32_t lo = cfg.aloneMinS, hi = max(cfg.aloneMaxS, cfg.aloneMinS);
  uint32_t s = lo + (hi > lo ? esp_random() % (hi - lo + 1) : 0);
  aloneTargetMs = (uint32_t)(s * mult * 1000.0f);
  aloneQuietStartMs = millis();
  aloneFailMarked = false;            // v2.9.6: a new interval = a new trial for the auto difficulty
}

bool inBarkCooldown() {
  if (!lastBarkMs) return false;
  return millis() - lastBarkMs < (uint32_t)cfg.barkCooldownS * 1000UL;
}

void sendNtfy(const String& msg, const char* title = nullptr, bool photo = true);

// ---------------------------------------------------------------- v2.7.1-food: meal state (logic after dispenseTick)
enum MealState : uint8_t { M_IDLE, M_AGITATE, M_TURN, M_DROP, M_JIGGLE, M_CLEAR };
MealState mState = M_IDLE;
bool     mCal = false;              // calibration run: N troughs into a cup, no gram cap, no clear-wait
uint16_t mCalTarget = 0, mCalDone = 0; bool calWaiting = false;
float    mServedG = 0, mTargetG = 0;
uint16_t mTroughs = 0;
uint32_t troughIdx = 0;             // which third of the wheel comes next (exact steps even if stepsPerRev % 3 != 0)
uint8_t  mAttempt = 0, mNoDrop = 0, mSlot = 0;
uint32_t mStartMs = 0, mWaitMs = 0, mDropMs = 0, mClearSinceMs = 0;
String   mLast = "";                // last meal result, shown on /meal
float    mealGToday = 0;
bool mealBusy() { return mState != M_IDLE; }
String jsonEsc(const String& s);

// ---------------------------------------------------------------- v2: one treat, no jams
// Each dispense:  agitator wiggle -> turn one pocket -> wait up to 1.5 s for the IR beam ->
//                 no drop? jiggle back & forth and turn again (up to 3 retries) -> still nothing: jam alert.
//                 N jams in a row -> "out of treats" alert and auto-treats pause until you press "מילאתי".
enum DispState : uint8_t { D_IDLE, D_AGITATE, D_TURN, D_WAIT, D_JIGGLE, D_AFTER };
DispState dState = D_IDLE;
uint8_t  dAttempt = 0;
uint32_t dWaitStartMs = 0, dFirstDropMs = 0;
bool     dManual = false; uint8_t dLogType = 2; float dLogDb = 0;
bool     dStaged = false, dClicked = false, dEmptyAtClick = false; uint32_t dClickMs = 0;   // v2.9.6 fast treat
uint8_t  noDropStreak = 0;          // dispenses in a row with no treat seen
bool     outOfTreats = false;
bool     outOfFood = false;                            // v2.9: the FOOD side has its own empty/jam flag
uint16_t jamsToday = 0;
bool dispBusy() { return dState != D_IDLE; }

// Returns true if a dispense was started.
bool dispense(bool manual, const char* reason, uint8_t logType = 255) {
  if (dispBusy() || (motorBusy() && !stagingNow)) return false;
  if (cleanOn) { lastReason = "cleaning mode"; return false; }      // v2.9.4: nothing dispenses while cleaning (manual included)
  if (mealBusy()) { lastReason = "meal running"; return false; }   // v2.7.1-food: no treats in the middle of a meal
  rollDayIfNeeded();
  if (cfg.mode == 2) { lastReason = "measure-only"; return false; }   // רק מדידה: never dispenses
  if (!manual) {
    if (!cfg.enabled) return false;
    if (outOfTreats) { lastReason = "out of treats"; return false; }
    if (stopActive()) { lastReason = "STOP"; return false; }      // v2.9.6: no daily cap any more (grams count instead)
  }
  if (stagingNow) { motorStopNow(); stagingNow = false; }         // v2.9.6: a staging move in progress ends here
  markerSound();                                     // click = "yes, that!" at the moment of calm
  dClicked = cfg.clicker; dClickMs = millis(); dEmptyAtClick = false;
  setRgb(false, true, false);                        // v2.7.1: green while a treat is dispensed
  dManual = manual; dLogType = logType != 255 ? logType : (manual ? 3 : 2);
  dLogDb = logType != 255 ? (float)extSrc : aboveDb;
  dAttempt = 0; dFirstDropMs = 0;
  if (cfg.irFitted && digitalRead(PIN_IR) == LOW) { logEvent(17, 0); sendNtfy("⚠️ החיישן במגלשה חסום (חטיף תקוע מולו או לכלוך). כדאי לנקות."); }
  noInterrupts(); irDrops = 0; interrupts();
  activeWheel = 0;                                   // v2.9: treats come from the TREAT wheel (motor direction A)
  dStaged = stageReady(); dStageIr = stageIrHit; staged = false; stageDueMs = 0;
  if (dStaged) { dState = D_TURN; startMotion(1); }  // v2.9.6 FAST: only the last ~15 % of the pocket is left to turn
  else { dState = D_AGITATE; startMotion(0); }
  lastTreatMs = millis();
  if (!manual) lastAutoTreatMs = lastTreatMs;
  lastReason = reason;
  pendingNoise = false;
  pickAloneInterval();                 // alone mode: next interval starts now
  Serial.printf("[treat] %s (%s)\n", manual ? "manual" : "auto", reason);
  return true;
}

void dispenseSucceeded(uint16_t drops) {
  uint16_t n = drops ? min(drops, (uint16_t)3) : 1;
  today.treats[currentHour()] += n; day.treats += n;
  addTreatGrams(n * cfg.gPerTrough);                       // v2.9.6: grams against the day's food / next meal
  if (dFirstDropMs && dClickMs) lastLatencyMs = dFirstDropMs - dClickMs;
  if (dEmptyAtClick) {                                     // v2.9.6: staged pocket was empty, the next one gave
    day.spills++;
    if (dStageIr) {                                        // ...and the beam broke while it waited -> it fell early
      addTreatGrams(cfg.gPerTrough);                       // she probably ate the early one too
      if (cfg.stagePct > 40) { cfg.stagePct = max(40, (int)cfg.stagePct - 3); saveSettings(); }
    }
    logEvent(28, cfg.stagePct, dStageIr ? 1 : 0);
  }
  logEvent(dLogType, dLogDb);
  if (drops >= 2) { logEvent(13, drops); day.doubles++; Serial.println("[treat] double drop"); }
  if (outOfTreats || noDropStreak) { outOfTreats = false; }
  noDropStreak = 0;
  if (drops) dgTreatOk++;                                  // v2.9.6 help (diagnostics only)
  if (cfg.voiceOnTreat) playSound("voice", cfg.volume);   // "כלבה טובה" in your voice
  if (cfg.ntfyOnTreat) notifyTreatPending = true;          // sent from loop()
}
void dispenseJammed() {
  logEvent(11, cfg.retries); day.jams++; jamsToday++; dgTreatMiss++;
  if (dClicked) clickUnpaid("החטיף לא נפל");               // v2.9.6: a click must always pay
  noDropStreak++;
  if (noDropStreak >= cfg.emptyAfter && !outOfTreats) {
    outOfTreats = true; logEvent(12, noDropStreak);
    sendNtfy(String("🦴 נגמרו החטיפים? ") + noDropStreak + " ניסיונות ברצף בלי שנפל חטיף. מלא את המיכל ולחץ \"מילאתי\" במסך.", "Out of treats");
  } else {
    sendNtfy(String("⚠️ תקיעה: החטיף לא נפל אחרי ") + (cfg.retries + 1) + " ניסיונות. כדאי לבדוק את הגלגל.", "Jam");
  }
}
// Called from loop() (and between motor moves). Advances the sequence.
void dispenseTick() {
  if (dState == D_IDLE || motorBusy()) return;
  uint32_t now = millis();
  uint16_t drops; noInterrupts(); drops = irDrops; interrupts();
  if (drops && !dFirstDropMs) dFirstDropMs = now;
  switch (dState) {
    case D_AGITATE: activeWheel = 0; dState = D_TURN; startMotion(1); break;
    case D_JIGGLE:  activeWheel = 0; dState = D_TURN; startMotion(1); break;
    case D_TURN:    dState = D_WAIT; dWaitStartMs = now; break;
    case D_WAIT:
      if (!cfg.irFitted) { dispenseSucceeded(0); dState = D_AFTER; break; }
      // a drop seen: wait 400 ms more so a second treat right behind it is counted too
      if (drops && now - dFirstDropMs >= 400) { dispenseSucceeded(drops); dState = D_AFTER; break; }
      if (!drops && now - dWaitStartMs >= cfg.dropWaitMs) {
        if (dAttempt == 0 && dStaged) dEmptyAtClick = true;   // v2.9.6: the pre-staged pocket gave nothing
        if (dAttempt == 0 && dStaged) { dAttempt++; activeWheel = 0; dState = D_TURN; startMotion(1); break; }   // next pocket at once, no jiggle
        if (dAttempt < cfg.retries) { dAttempt++; Serial.printf("[treat] no drop, retry %d\n", dAttempt); activeWheel = 0; dState = D_JIGGLE; startMotion(2); }
        else { dispenseJammed(); dState = D_AFTER; }
      }
      break;
    case D_AFTER: setRgb(false, false, false); motorDoneMs = now; dState = D_IDLE;
      if (cfg.stageOn) stageDueMs = now + 2000;             // v2.9.6: pre-stage the next treat
      break;
    default: dState = D_IDLE;
  }
}


// ---------------------------------------------------------------- v2.7.1-food: MEALS, a little at a time
// NITAY (Nov 3 2026): 150 g per meal, 2 meals a day, "bring her a bit each time so she is less scared and eats slower".
// One meal:  click -> agitate -> [turn ONE trough -> IR sees it fall (no fall: jiggle + retry, like treats)
//            -> wait until the chute mouth has looked clear for clearMs (she ate it) -> next trough] ... until mealG grams.
// The tray only holds ~4-8 g, so kibble never piles up: if she stops eating, the pile reaches the IR and the feeder waits.
// Blocked for mealPauseMin minutes -> the meal ends early (grams served are logged + notified). Without the IR: fixed gap.
uint8_t pocketsPerRev() { return 2; }                          // v2.9: both wheels 2 pockets (2304 half-steps each)
uint8_t mCalWheel = 1;                                          // v2.9: which wheel a calibration run turns (0 treat, 1 food)
float   gPerWheel(int w)  { return w == 0 ? cfg.gPerTrough : cfg.gPerBig; }
float   gPerPocket()    { return gPerWheel(1); }                // meals = FOOD wheel
uint32_t troughSteps() {
  uint32_t r = cfg.stepsPerRev ? cfg.stepsPerRev : 4608, n = pocketsPerRev();
  if (troughIdx >= n) troughIdx = 0;
  uint32_t a = (troughIdx * r + 1) / n, b = ((troughIdx + 1) * r + 1) / n;   // exact share of a turn, no drift (4608/3 = 1536, 4608/2 = 2304)
  troughIdx = (troughIdx + 1) % n;
  return b - a;
}
void mealTurnTrough() {
  noInterrupts(); irDrops = 0; interrupts();
  activeWheel = mCal ? mCalWheel : 1;
  mDropMs = 0; startMotion(3); mState = M_TURN;
}
time_t rmLastMealT = 0;   // v2.9.8 remote: when the last meal finished (this boot), for the status "lastMeal"
void mealEnd(const String& why, bool notify) {
  mState = M_IDLE; setRgb(false, false, false); motorDoneMs = millis();
  if (mCal) {
    mCal = false; mCalDone = mTroughs; calWaiting = true;
    mLast = String("כיול: ") + mTroughs + " שקעים. שקול את הכוס והקלד גרמים.";
    Serial.printf("[meal] calibration run done: %u troughs\n", mTroughs);
    return;
  }
  mealGToday += mServedG; day.mealG += (uint16_t)lroundf(mServedG);   // v2.9.6: kept in the day record
  if (clockValid()) rmLastMealT = time(nullptr);                     // v2.9.8 remote status
  uint32_t mins = (millis() - mStartMs + 30000UL) / 60000UL;
  mLast = String("ארוחה ") + (mSlot ? String(mSlot) : String("ידנית")) + ": " + String(mServedG, 0) + " גרם" + (mealCutG > 0.5f ? String(" (") + String(mealCutG, 0) + " ג׳ פחות בגלל חטיפים)" : String("")) + ", " + mTroughs + " מנות, " + mins + " דק׳ · " + why;
  logEvent(23, mServedG);
  Serial.printf("[meal] %s\n", mLast.c_str());
  if (notify) sendNtfy(String("🍽️ ") + mLast, "Meal", false);
}
bool startMeal(uint8_t slot, uint16_t calTroughs = 0) {
  if (stagingNow && !dispBusy()) { motorStopNow(); stagingNow = false; staged = false; }   // v2.9.6
  if (mealBusy() || dispBusy() || motorBusy()) return false;
  if (cleanOn) return false;                     // v2.9.4: no meals (and no calibration runs) while cleaning
  rollDayIfNeeded();
  mCal = calTroughs > 0; mCalTarget = calTroughs; calWaiting = false;
  mSlot = slot; mServedG = 0; mTroughs = 0; mAttempt = 0; mNoDrop = 0;
  mTargetG = cfg.mealG; mealCutG = 0;
  if (!mCal) mTargetG = mealTargetWithTreats();          // v2.9.6: today's treats come off this meal (floor 50 %)
  mStartMs = millis();
  if (!mCal) markerSound();                      // one click: "dinner"
  setRgb(false, false, true);                    // blue while a meal runs
  if (cfg.irFitted && digitalRead(PIN_IR) == LOW && !mCal) { logEvent(17, 0); }
  activeWheel = mCal ? mCalWheel : 1;
  mState = M_AGITATE; startMotion(0);
  Serial.printf("[meal] start slot %u target %.0f g (%.2f g/trough)%s\n", slot, mTargetG, cfg.gPerTrough, mCal ? " CAL" : "");
  return true;
}
void mealServed() {
  mTroughs++; mAttempt = 0; mNoDrop = 0;
  if (mCal ? mCalWheel == 1 : true) outOfFood = false; else { outOfTreats = false; noDropStreak = 0; }
  if (!mCal) mServedG += gPerPocket();
  bool done = mCal ? (mTroughs >= mCalTarget) : (mServedG + gPerPocket() > mTargetG);   // v2.8: never over the cap (150 g)
  if (done) { mealEnd("הושלמה", true); return; }
  mState = M_CLEAR; mWaitMs = millis(); mClearSinceMs = 0;
}
void mealTick() {
  if (mState == M_IDLE || motorBusy()) return;
  uint32_t now = millis();
  uint16_t drops; noInterrupts(); drops = irDrops; interrupts();
  if (drops && !mDropMs) mDropMs = now;
  switch (mState) {
    case M_AGITATE: mealTurnTrough(); break;
    case M_JIGGLE:  mealTurnTrough(); break;
    case M_TURN:    mState = M_DROP; mWaitMs = now; break;
    case M_DROP:
      if (!cfg.irFitted) { mealServed(); break; }
      if (drops && now - mDropMs >= 400) { mealServed(); break; }
      if (!drops && now - mWaitMs >= cfg.dropWaitMs) {
        if (mAttempt < cfg.retries) { mAttempt++; Serial.printf("[meal] no drop, jiggle %d\n", mAttempt); activeWheel = mCal ? mCalWheel : 1; mState = M_JIGGLE; startMotion(2); }
        else {
          mAttempt = 0; mNoDrop++; day.jams++; jamsToday++;
          if (mNoDrop >= cfg.emptyAfter) {
            if (mCal && mCalWheel == 0) outOfTreats = true; else outOfFood = true;
            logEvent(12, mNoDrop);
            mealEnd(String("נעצרה: ") + mNoDrop + " מנות ברצף לא נפלו (" + ((mCal && mCalWheel == 0) ? "צד החטיפים" : "צד האוכל") + " ריק או תקוע)", true);
          } else { logEvent(11, cfg.retries); mealTurnTrough(); }
        }
      }
      break;
    case M_CLEAR: {
      if (mCal) { if (now - mWaitMs >= 1000) mealTurnTrough(); break; }
      if (!cfg.irFitted) { if (now - mWaitMs >= (uint32_t)cfg.noIrGapS * 1000UL) mealTurnTrough(); break; }
      bool blocked = digitalRead(PIN_IR) == LOW;          // kibble still at the chute mouth (or her nose)
      if (blocked) {
        mClearSinceMs = 0;
        if (now - mWaitMs >= (uint32_t)cfg.mealPauseMin * 60000UL) mealEnd(String("הפסיקה לאכול (") + cfg.mealPauseMin + " דק׳ המגש מלא)", true);
      } else {
        if (!mClearSinceMs) mClearSinceMs = now;
        if (now - mClearSinceMs >= cfg.clearMs && now - mWaitMs >= (uint32_t)cfg.portionGapS * 1000UL) mealTurnTrough();
      }
      break;
    }
    default: mState = M_IDLE;
  }
}
// meal clock: each slot starts once a day, inside a 30-min window after its time (a power blip at 07:29 still feeds her)
int32_t mealDone[2] = {-1, -1};
void mealScheduleTick() {
  static uint32_t lastChk = 0;
  if (millis() - lastChk < 10000) return;
  lastChk = millis();
  if (!clockValid()) return;
  struct tm t; time_t nw = time(nullptr); localtime_r(&nw, &t);
  int32_t dk = (t.tm_year + 1900) * 1000 + t.tm_yday;
  static int32_t gDay = -1;
  if (gDay != dk) { if (gDay != -1) mealGToday = 0; gDay = dk; }   // grams-today counter restarts at midnight
  if (!cfg.mealsOn || mealBusy() || cleanOn || stopActive()) return;   // v2.9.6: STOP pauses meal starts too · v2.9.4: cleaning mode skips the meal clock (a meal still in its 30-min window runs after "done")
  int nowMin = t.tm_hour * 60 + t.tm_min;
  uint16_t at[2] = {cfg.meal1Min, cfg.meal2Min};
  for (int i = 0; i < 2; i++) {
    if (mealDone[i] == dk) continue;
    if (nowMin >= at[i] && nowMin < at[i] + 30) {
      if (dispBusy() || (motorBusy() && !stagingNow)) return;   // a treat is falling: try again in 10 s
      if (stagingNow) { motorStopNow(); stagingNow = false; staged = false; }
      if (startMeal(i + 1)) { mealDone[i] = dk; prefs.begin("dogtreat", false); prefs.putInt(i ? "md2" : "md1", dk); prefs.end(); }
      return;
    }
  }
}
void mealLoadDone() { prefs.begin("dogtreat", true); mealDone[0] = prefs.getInt("md1", -1); mealDone[1] = prefs.getInt("md2", -1); prefs.end(); }

// ---------------------------------------------------------------- v2.9.4 (NITAY Nov 5 2026): CLEANING MODE ("מצב ניקוי")
// Start: app "🧽 התחל ניקוי" (POST /api/clean-start) or hold the BOOT button 5 s.
//   1. TREAT wheel (motor +, direction A) slowly turns one full turn + 1 pocket -> the last treats fall into the tray
//   2. FOOD  wheel (motor -, direction B) slowly turns one full turn + 1 pocket -> the last kibble falls into the tray
//      (fixed turns: runs the same with an empty hopper; the IR sensor is not needed)
//   3. coils OFF (motor released) -> lift the wheel cartridge straight out (drop-in spur-gear pair, nothing to unscrew).
// While on: the LED double-blinks blue; meals, treats (manual, auto, camera/PIR/outdoor, training) and calibration are off.
// The mode is saved, so a power cut while the wheels are out does NOT bring feeding back.
// Done: app "✅ סיימתי לנקות" (POST /api/clean-done) or a short press. The wheels were out, so both clutches are re-synced
// (the same few degrees as after a power cut mid-move), then everything runs as before.
uint32_t cleanReleasedMs = 0;
void cleanSave() { prefs.begin("dogtreat", false); prefs.putBool("clean", cleanOn); prefs.end(); }
void cleanDrive(uint8_t w) {                         // one full turn + 1 pocket of wheel w, ending exactly on a pocket boundary
  int32_t r = cfg.stepsPerRev ? cfg.stepsPerRev : 4608;
  activeWheel = w; segN = 0;
  qSeg(SEG_DRIVE, w, pocketTarget(w) + r);           // 6912 half-steps from a boundary: under the 12000-step safety cap
  beginMotion();
}
void motorStopNow() { if (motorBusy()) { segI = segN; while (motorBusy()) { motorTick(); yield(); } } }   // ends via motorEnd(): coils off
bool cleanStart() {
  if (cState) return false;                          // already emptying
  motorStopNow();                                    // a sync / treat / meal in progress stops here
  if (mealBusy()) mealEnd("נעצרה: מצב ניקוי", false);
  if (dState != D_IDLE) { dState = D_IDLE; setRgb(false, false, false); }
  pendingNoise = false; pendingExt = false;
  cleanOn = true; cleanSave(); staged = false; stagingNow = false; stageDueMs = 0;   // v2.9.6
  cState = 1; cleanDrive(0);                         // treat wheel first; cleanTick() starts the food wheel after it
  lastReason = "cleaning mode";
  Serial.println("[clean] start: emptying treat wheel, then food wheel");
  return true;
}
void cleanTick() {                                   // called from loop() and right after each motor move
  if (cState == 0 || motorBusy()) return;
  if (cState == 1) { cState = 2; cleanDrive(1); Serial.println("[clean] emptying food wheel"); return; }
  cState = 0; coilsOff(); cleanReleasedMs = millis();  // motorEnd() already released the coils; again for certainty
  clutchValid = false; clutchSave();                 // the wheels are coming out -> pawl positions unknown until re-sync
  Serial.println("[clean] wheels emptied, motor released: lift the cartridge out");
  sendNtfy("🧽 מצב ניקוי: הגלגלים רוקנו והמנוע משוחרר. אפשר להרים את מחסנית הגלגלים החוצה ולשטוף. בסוף לחץ \"סיימתי לנקות\".", "Cleaning", false);
}
bool cleanExit() {
  if (!cleanOn) return true;
  if (cState) { cState = 0; motorStopNow(); clutchValid = false; clutchSave(); }   // stopped mid-emptying
  cleanOn = false; cleanSave();
  setRgb(false, false, false); motorDoneMs = millis();
  if (!clutchValid) startClutchSync();               // wheels were out: engage both pawls again, then park
  if (cfg.stageOn) stageDueMs = millis() + 8000;     // v2.9.6: then pre-stage the treat wheel
  lastReason = "cleaning done";
  Serial.println("[clean] done: feeding back on");
  return true;
}
void cleanButtonTick() {                             // hold 5 s = cleaning mode (again = empty once more) · short press while cleaning = done
  if (PIN_CLEAN_BTN < 0) return;
  static bool down = false, fired = false; static uint32_t t0 = 0;
  bool p = digitalRead(PIN_CLEAN_BTN) == LOW;
  uint32_t now = millis();
  if (p && !down) { down = true; fired = false; t0 = now; }
  else if (p && !fired && now - t0 >= 5000) { fired = true; clickSound(); cleanStart(); }
  else if (!p && down) {
    down = false;
    uint32_t held = now - t0;
    if (!fired && held >= 50 && held < 1500 && cleanOn) { clickSound(); cleanExit(); }   // < 50 ms = contact bounce
  }
}
void cleanLoad() { prefs.begin("dogtreat", true); cleanOn = prefs.getBool("clean", false); prefs.end(); }
// v2.9.6 help: one word saying WHY an action was refused (the page turns it into Hebrew). Read-only.
const char* busyWhy() {
  if (cleanOn) return cState ? "emptying" : "cleaning";
  if (mealBusy()) return mCal ? "cal" : "meal";
  if (dispBusy()) return "treat";
  if (motorBusy()) return "motor";
  return "busy";
}
void handleCleanStart() { bool ok = cleanStart(); server.send(ok ? 200 : 409, "application/json", String("{\"ok\":") + (ok ? "true" : "false") + ",\"cleaning\":true" + (ok ? "" : ",\"why\":\"emptying\"") + "}"); }
void handleCleanDone()  { cleanExit(); server.send(200, "application/json", "{\"ok\":true,\"cleaning\":false}"); }

// /meal page + API
String hhmm(uint16_t m) { char b[6]; snprintf(b, sizeof(b), "%02u:%02u", m / 60, m % 60); return String(b); }
uint16_t parseHHMM(const String& s, uint16_t def) {
  int c = s.indexOf(':'); if (c < 1) return def;
  int h = s.substring(0, c).toInt(), mi = s.substring(c + 1).toInt();
  if (h < 0 || h > 23 || mi < 0 || mi > 59) return def; return h * 60 + mi;
}
void handleMealGet() {
  String j = "{";
  j += "\"on\":" + String(cfg.mealsOn ? "true" : "false");
  j += ",\"g\":" + String(cfg.mealG);
  j += ",\"t1\":\"" + hhmm(cfg.meal1Min) + "\",\"t2\":\"" + hhmm(cfg.meal2Min) + "\"";
  j += ",\"gpt\":" + String(cfg.gPerTrough, 2) + ",\"gpb\":" + String(cfg.gPerBig, 2) + ",\"cs\":" + String(cfg.clutchSlack) + ",\"calWheel\":" + String(mCalWheel);
  j += ",\"emptyT\":" + String(outOfTreats ? "true" : "false") + ",\"emptyF\":" + String(outOfFood ? "true" : "false");
  j += ",\"clutch\":\"" + String(clutchValid ? "ok" : "sync") + " T" + String(wAng[0] % (cfg.stepsPerRev ? cfg.stepsPerRev : 4608)) + " F" + String(wAng[1] % (cfg.stepsPerRev ? cfg.stepsPerRev : 4608)) + "\"";
  j += ",\"troughs\":" + String((int)floorf(cfg.mealG / max(gPerPocket(), 0.1f)));
  j += ",\"spr\":" + String(cfg.stepsPerRev);
  j += ",\"busy\":" + String(mealBusy() ? "true" : "false");
  j += ",\"cal\":" + String(mCal ? "true" : "false");
  j += ",\"calWaiting\":" + String(calWaiting ? "true" : "false") + ",\"calDone\":" + String(mCalDone);
  j += ",\"served\":" + String(mServedG, 0) + ",\"done\":" + String(mTroughs);
  j += ",\"today\":" + String(day.mealG + (mealBusy() && !mCal ? mServedG : 0), 0);
  j += ",\"treatG\":" + String(treatGToday(), 1) + ",\"foodG\":" + String(cfg.dailyFoodG) + ",\"nextMeal\":" + String(nextMealG(), 0) + ",\"cut\":" + String(mealCutG, 0) + ",\"target\":" + String(mTargetG, 0) + ",\"floor\":" + String(cfg.mealFloorPct);
  j += ",\"stop\":" + String(stopActive() ? (int32_t)((stopUntilMs - millis()) / 1000) : 0);
  j += ",\"ir\":" + String(digitalRead(PIN_IR) == LOW ? "true" : "false");
  j += ",\"empty\":" + String(outOfFood ? "true" : "false");
  j += ",\"clean\":" + String(cleanOn ? "true" : "false") + ",\"cleanSt\":" + String(cState);   // v2.9.4
  j += ",\"last\":\"" + jsonEsc(mLast) + "\"}";
  server.send(200, "application/json", j);
}
void handleMealSet() {                                   // POST /api/meal?on=1&g=150&t1=07:30&t2=18:30&gpt=1.8&spr=4608
  if (server.hasArg("on"))  cfg.mealsOn = server.arg("on") == "1" || server.arg("on") == "true";
  if (server.hasArg("g"))   cfg.mealG = constrain(server.arg("g").toInt(), 10, 600);
  if (server.hasArg("t1"))  cfg.meal1Min = parseHHMM(server.arg("t1"), cfg.meal1Min);
  if (server.hasArg("t2"))  cfg.meal2Min = parseHHMM(server.arg("t2"), cfg.meal2Min);
  if (server.hasArg("gpt")) { float g = server.arg("gpt").toFloat(); if (g >= 0.2f && g <= 20.0f) cfg.gPerTrough = g; }
  if (server.hasArg("spr")) cfg.stepsPerRev = constrain(server.arg("spr").toInt(), 3000, 6000);
  if (server.hasArg("gpb")) { float g = server.arg("gpb").toFloat(); if (g >= 0.2f && g <= 30.0f) cfg.gPerBig = g; }
  if (server.hasArg("cs"))  cfg.clutchSlack = constrain(server.arg("cs").toInt(), 0, 90);   // v2.9: < 96 (one engagement)
  cfg.stepsPerTreat = cfg.stepsPerRev / pocketsPerRev();
  saveSettings(); handleMealGet();
}
void handleMealNow()  { bool ok = startMeal(0); server.send(200, "application/json", String("{\"ok\":") + (ok ? "true" : ("false,\"why\":\"" + String(busyWhy()) + "\"")) + "}"); }
void handleMealStop() { if (mealBusy()) { if (motorBusy()) { segI = segN; } mealEnd("נעצרה ידנית", false); } server.send(200, "application/json", "{\"ok\":true}"); }
void handleMealCal() {                                   // POST /api/meal-cal?troughs=20  ->  later  POST /api/meal-cal?grams=37
  if (server.hasArg("grams")) {
    float g = server.arg("grams").toFloat();
    if (!calWaiting || mCalDone == 0 || g <= 0) { server.send(400, "application/json", "{\"ok\":false,\"error\":\"run the calibration first\"}"); return; }
    if (mCalWheel == 1) cfg.gPerBig = g / mCalDone; else cfg.gPerTrough = g / mCalDone;   // v2.9: the wheel that just ran gets calibrated
    calWaiting = false; saveSettings();
    mLast = String("כויל (גלגל ") + (mCalWheel ? "אוכל" : "חטיפים") + "): " + String(gPerWheel(mCalWheel), 2) + " גרם לשקע" + (mCalWheel ? String(" → ארוחה = ") + (int)floorf(cfg.mealG / gPerPocket()) + " מנות" : String(""));
    handleMealGet(); return;
  }
  uint16_t n = server.hasArg("troughs") ? constrain(server.arg("troughs").toInt(), 3, 60) : 20;
  mCalWheel = (server.hasArg("wheel") && server.arg("wheel") == "0") ? 0 : 1;    // v2.9: wheel=0 treat, wheel=1 food
  bool ok = startMeal(0, n);
  server.send(200, "application/json", String("{\"ok\":") + (ok ? "true" : ("false,\"why\":\"" + String(busyWhy()) + "\"")) + ",\"troughs\":" + n + "}");
}
#include "meal_page.h"   // v2.9.6: page moved to its own file (Arduino's prototype scanner read the JS as C)

// Resolve "dogcam.local" with mDNS (the ESP32's normal DNS doesn't know .local names)
String camAddress() {
  String h = cfg.camHost; h.trim();
  if (h.endsWith(".local")) {
    IPAddress ip = MDNS.queryHost(h.substring(0, h.length() - 6), 1500);
    if (ip != IPAddress(0, 0, 0, 0)) return ip.toString();
  }
  return h;
}

// Grab one JPEG from the ESP32-CAM. Returns a malloc'd buffer (free it!) or nullptr.
uint8_t* grabSnapshot(size_t& len) {
  len = 0;
  if (cfg.camHost.length() == 0) return nullptr;
  HTTPClient http; http.setTimeout(3000);
  if (!http.begin("http://" + camAddress() + "/jpg")) return nullptr;
  uint8_t* buf = nullptr;
  if (http.GET() == 200) {
    int size = http.getSize();
    if (size > 0 && size < 120000) {
      buf = (uint8_t*)malloc(size);
      if (buf) {
        WiFiClient* s = http.getStreamPtr(); size_t got = 0; uint32_t t0 = millis();
        while (got < (size_t)size && millis() - t0 < 3000) { int a = s->available(); if (a > 0) got += s->readBytes(buf + got, min((size_t)a, size - got)); else delay(2); }
        if (got == (size_t)size) len = got; else { free(buf); buf = nullptr; }
      }
    }
  }
  http.end();
  return buf;
}

// Push to the ntfy app. With a camera configured, the photo is attached (ntfy PUT + Filename header).
// Hebrew in HTTP headers must be RFC 2047 encoded ("=?UTF-8?B?...?="), which ntfy understands.
String hdrUtf8(const String& s) {
  bool ascii = true; for (char c : s) if ((uint8_t)c > 127 || c == '\n') ascii = false;
  if (ascii) return s;
  String b = base64::encode(s); b.replace("\n", "");
  return "=?UTF-8?B?" + b + "?=";
}
void sendNtfy(const String& msg, const char* title, bool photo) {
  if (!cfg.pushOn || cfg.ntfyTopic.length() == 0 || WiFi.status() != WL_CONNECTED) return;   // v2.9.7: master switch
  size_t jpgLen = 0; uint8_t* jpg = photo ? grabSnapshot(jpgLen) : nullptr;
  WiFiClientSecure client; client.setInsecure();   // simple; ntfy.sh public topic
  HTTPClient http;
  if (http.begin(client, "https://ntfy.sh/" + cfg.ntfyTopic)) {
    http.addHeader("Title", title ? title : "DogTreat");
    http.addHeader("Tags", "dog");
    int code;
    if (jpg) { http.addHeader("Filename", "dog.jpg"); http.addHeader("Message", hdrUtf8(msg)); code = http.sendRequest("PUT", jpg, jpgLen); }
    else { http.addHeader("Content-Type", "text/plain; charset=utf-8"); code = http.POST(msg); }
    Serial.printf("[ntfy] %d (photo %u bytes)\n", code, (unsigned)jpgLen);
    http.end();
  }
  if (jpg) free(jpg);
}

// ---------------------------------------------------------------- v2: WhatsApp via CallMeBot (free, optional)
// Setup (once): add the bot number shown on callmebot.com/blog/free-api-whatsapp-messages to your contacts,
// send it "I allow callmebot to send me messages" on WhatsApp, and it answers with your apikey.
// Put your number (972…) and the key in the settings.
String urlEncode(const String& s) {
  String o; const char* hex = "0123456789ABCDEF";
  for (uint8_t c : s) {
    if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o += (char)c;
    else { o += '%'; o += hex[c >> 4]; o += hex[c & 15]; }
  }
  return o;
}
int sendWhatsApp(const String& msg) {
  if (!cfg.cmbPhone.length() || !cfg.cmbKey.length() || WiFi.status() != WL_CONNECTED) return 0;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http; http.setTimeout(10000);
  String url = "https://api.callmebot.com/whatsapp.php?phone=" + urlEncode("+" + cfg.cmbPhone) + "&text=" + urlEncode(msg) + "&apikey=" + urlEncode(cfg.cmbKey);
  int code = 0;
  if (http.begin(client, url)) { code = http.GET(); http.end(); }
  Serial.printf("[whatsapp] %d\n", code);
  return code;
}


// ---------------------------------------------------------------- v3: bark recognition state / זיהוי נביחות
// Each classified burst is kept (last 20) with its features, so the phone can show it and you can correct it.
// struct BurstRec lives in barkml.h (the Arduino prototype generator needs it before any function)
// verdict: 0 bark · 1 noise · 2 maybe (no treat) · 3 loud & long bark-like (no treat) · 4 recorded while learning
static const int BR_N = 20;
BurstRec brLog[BR_N]; int brHead = 0, brCount = 0; uint16_t brNextId = 1;
BmTemplate bmTpl;                    // "learn my dog" template (sums)
BarkFeat   bmNeg[BM_MAXNEG]; uint8_t bmNegN = 0, bmNegHead = 0;   // "זה לא היה נביחה"
BmRep      bmRep;
BmBurst    bacc;                     // the burst being accumulated
BmWin      bwin;
float      yBuf[WINDOW_SAMPLES]; int yN = 0;   // filtered samples of the current window
float      prevFrameDb = 0, curFrameDb = 0;
// learning session
uint32_t   learnUntilMs = 0; uint8_t learnN = 0; BarkFeat learnBuf[BM_MAXLEARN]; String learnMsg = "";

#include "ask.h"   // v2.9.7: "כשהוא לא בטוח" — ask the owner (web card + ntfy push), outside barkml.h

void bmSave() {
  prefs.begin("barkml", false);
  prefs.putBytes("tpl", &bmTpl, sizeof(bmTpl));
  prefs.putBytes("neg", bmNeg, sizeof(BarkFeat) * BM_MAXNEG);
  prefs.putUChar("negN", bmNegN); prefs.putUChar("negH", bmNegHead);
  prefs.end();
}
void bmLoad() {
  memset(&bmTpl, 0, sizeof(bmTpl)); memset(bmNeg, 0, sizeof(bmNeg)); bmNegN = 0; bmNegHead = 0;
  prefs.begin("barkml", true);
  if (prefs.getBytesLength("tpl") == sizeof(bmTpl)) prefs.getBytes("tpl", &bmTpl, sizeof(bmTpl));
  {                                   // v2.9.7 (bark v4): bmLoadNegs() accepts the old v3 blob (24x40 B) and the new one (24x68 B),
    size_t L = prefs.getBytesLength("neg");   // so the saved "זה לא היה נביחה" marks are kept, not reset
    uint8_t* tmp = (L > 0 && L <= sizeof(BarkFeat) * BM_MAXNEG) ? (uint8_t*)malloc(L) : nullptr;
    if (tmp) {
      prefs.getBytes("neg", tmp, L);
      if (bmLoadNegs(tmp, L, bmNeg)) { bmNegN = min((int)prefs.getUChar("negN", 0), BM_MAXNEG); bmNegHead = prefs.getUChar("negH", 0) % BM_MAXNEG; }
      free(tmp);
    }
  }
  prefs.end();
}
void bmAddNeg(const BarkFeat& x) { bmNeg[bmNegHead] = x; bmNegHead = (bmNegHead + 1) % BM_MAXNEG; if (bmNegN < BM_MAXNEG) bmNegN++; }
BurstRec* brFind(uint16_t id) { for (int k = 0; k < brCount; k++) { int i = (brHead - 1 - k + BR_N) % BR_N; if (brLog[i].id == id) return &brLog[i]; } return nullptr; }
uint16_t brAdd(uint8_t verdict, float p, int rep, float peak, uint32_t durMs, const BarkFeat& x) {
  BurstRec& r = brLog[brHead];
  r.id = brNextId++; if (!brNextId) brNextId = 1;
  r.t = clockValid() ? (uint32_t)time(nullptr) : millis() / 1000;
  r.verdict = verdict; r.pct = (uint8_t)lroundf(p * 100); r.rep = rep; r.fixed = 0; r.peak = peak;
  r.durMs = (uint16_t)min(durMs, (uint32_t)65000); r.x = x;
  brHead = (brHead + 1) % BR_N; if (brCount < BR_N) brCount++;
  return r.id;
}
// verdict confidence for the UI: bark p, noise 1-p
uint8_t verdictPct(uint8_t verdict, float p) { return (uint8_t)lroundf((verdict == 1 ? 1.0f - p : p) * 100); }
void learnFinish() {
  learnUntilMs = 0;
  if (learnN >= BM_TPL_MIN) {
    memset(&bmTpl, 0, sizeof(bmTpl));                       // a new recording replaces the old template
    for (int i = 0; i < learnN; i++) bmTplAdd(bmTpl, learnBuf[i]);
    bmSave(); learnMsg = "saved"; logEvent(20, learnN);
  } else learnMsg = "few";
  Serial.printf("[learn] %d bursts -> %s\n", learnN, learnMsg.c_str());
}

void onBark(float peak, uint8_t conf = 255, uint16_t bid = 0) {
  uint32_t now = millis();
  lastBarkMs = now;
  if (pendingNoise && cfg.mode == 0) diffOutcome(2, false);                  // v2.9.6: barked at a noise -> harder for now
  if (pendingExt) diffOutcome(catOf(extSrc) + 1, false);
  if (cfg.mode == 1 && cfg.enabled && !cleanOn && !stopActive() && (!aloneFailMarked || now - aloneFailMs > 120000UL)) {
    aloneFailMarked = true; aloneFailMs = now; day.aloneTry++; diffOutcome(0, false);   // v2.9.6: ALONE interval barked
  }
  pendingNoise = false;                // never reward a noise she barked at
  if (pendingExt) { pendingExt = false; logEvent(9, extSrc); }   // barked at the street -> no treat
  aloneQuietStartMs = now;             // ALONE: quiet timer restarts
  today.barks[currentHour()]++;
  noteBarkForProgress();
  trainOnBark();
  logEvent(0, peak, conf, bid);
  recentBarkTimes[rbIdx] = now; rbIdx = (rbIdx + 1) % RB_N;
  // barking episode -> phone notification (max one per 10 min), with a camera photo if there is one
  int n = barksWithin(60000UL);
  if (n >= cfg.ntfyBarks && (lastNtfyMs == 0 || now - lastNtfyMs > 600000UL)) {
    lastNtfyMs = now;
    sendNtfy(String("🔴 התקף נביחות: ") + n + " נביחות בדקה האחרונה. היום: " +
             sum24(today.barks) + " נביחות, " + sum24(today.treats) + " חטיפים.", "Barking");
  }
}

void onNoise(float peak, uint8_t conf = 255, uint16_t bid = 0) {
  today.noises[currentHour()]++;
  logEvent(1, peak, conf, bid);
  uint32_t now = millis();
  // ignore her own eating noises right after a treat, and the motor itself
  if (lastTreatMs && now - lastTreatMs < (uint32_t)cfg.postTreatIgnoreS * 1000UL) return;
  if (cfg.srcIndoor) noteTrigger(1);    // progress: a sound she could react to (v2.9.6: kind = noise/street)
  if (cfg.mode != 0) return;
  pendingNoise = true; pendingSinceMs = now;
}

// "Not calm" without counting a bark: no reward, cooldown restarts (חוק הזהב).
void notCalm(uint8_t logType, float peak, uint8_t conf, uint16_t bid) {
  lastBarkMs = millis();
  pendingNoise = false;
  if (pendingExt) { pendingExt = false; logEvent(9, extSrc); }
  logEvent(logType, peak, conf, bid);
  trainOnBark();
  aloneQuietStartMs = millis();
  quietStreakStartMs = millis();
}

// v3: classify a finished burst by its SOUND, not only its loudness.
// בדיקה: האם זה נשמע כמו נביחה (תדרים, חדות, אורך, חזרתיות) — ולא רק "חזק".
void classifyBurst(uint32_t durMs, float peak) {
  BarkFeat x; bmBurstFinish(bacc, durMs, x);
  uint32_t startMs = burstStartMs;
  float p0 = bmDefaultScore(x);
  int rep = bmRepCount(bmRep, startMs);
  float p = bmScore(x, p0, &bmTpl, bmNeg, bmNegN, rep);
  bmRepPush(bmRep, startMs, p0);

  // "Learn my dog": every burst while recording is your dog's bark (and of course no treat for it)
  if (learnUntilMs) {
    if (learnN < BM_MAXLEARN && durMs <= 3000) learnBuf[learnN++] = x;
    uint16_t id = brAdd(4, p, rep, peak, durMs, x);
    onBark(peak, verdictPct(0, p), id);
    if (learnN >= BM_MAXLEARN) learnFinish();
    return;
  }
  float thr = bmThreshold(cfg.barkSens);
  float gate = max(cfg.noiseDb, cfg.barkDb + bmGateOffsetDb(cfg.barkSens));
  if (p >= thr && peak >= gate) {
    if (durMs <= cfg.barkMaxMs) { uint16_t id = brAdd(0, p, rep, peak, durMs, x); onBark(peak, verdictPct(0, p), id); }
    else { uint16_t id = brAdd(3, p, rep, peak, durMs, x); notCalm(4, peak, verdictPct(0, p), id); }   // continuous barking
  } else if (p >= thr - askBandF() && peak >= gate - 4.0f) {      // v2.9.7: zone width from settings (default 0.20 = BM_MAYBE_BAND)
    uint16_t id = brAdd(2, p, rep, peak, durMs, x); notCalm(19, peak, verdictPct(2, p), id);          // unsure -> no treat
    askNote(id, p);                                                   // v2.9.7: ask the owner (web card + optional push)
  } else {
    uint16_t id = brAdd(1, p, rep, peak, durMs, x); onNoise(peak, verdictPct(1, p), id);
  }
  Serial.printf("[burst] %ums +%.0fdB p0=%.2f p=%.2f rep=%d\n", (unsigned)durMs, peak, p0, p, rep);
}

void processWindow(float db) {
  uint32_t now = millis();
  levelDb = db;
  // Ignore the microphone while the motor runs + 1.5 s after (motor & treat drop noise)
  bool selfNoise = motorBusy() || dispBusy() || (motorDoneMs && now - motorDoneMs < 1500)
                 || playing || (playEndMs && now - playEndMs < 400);   // v2: our own speaker

  if (calibrateUntil) {                                  // calibration: average quiet room level
    calibSum += db; calibN++;
    if ((int32_t)(now - calibrateUntil) >= 0) {
      baseDb = calibSum / max(1, calibN); calibrateUntil = 0;
      lastReason = "calibrated";
      Serial.printf("[cal] baseline %.1f dB\n", baseDb);
    }
    prevFrameDb = curFrameDb;
    return;
  }
  aboveDb = db - baseDb;

  // adaptive baseline: follows quiet levels quickly down, slowly up (~30 s)
  if (!burstActive && !selfNoise) {
    if (db < baseDb) baseDb += (db - baseDb) * 0.05f;
    else if (aboveDb < cfg.noiseDb) baseDb += (db - baseDb) * 0.0015f;
  }
  if (selfNoise) { burstActive = false; prevFrameDb = curFrameDb; return; }   // our own motor/speaker: never analysed

  bool loud = aboveDb >= cfg.noiseDb;
  if (loud) {
    lastSoundMs = now;
    if (!burstActive) { burstActive = true; burstStartMs = now; burstPeak = aboveDb; bmBurstStart(bacc, prevFrameDb); }
    burstLastLoudMs = now;
    if (aboveDb > burstPeak) burstPeak = aboveDb;
    if (yN >= 768) { bmAnalyze(yBuf, yN, bwin); bmBurstAdd(bacc, bwin); }   // v3: spectrum of this loud window
    // a burst that stays loud for > 3 s: classify now (truck, vacuum, howling…)
    if (now - burstStartMs > 3000) { classifyBurst(now - burstStartMs, burstPeak); burstStartMs = now; burstPeak = aboveDb; bmBurstStart(bacc, curFrameDb, true); }
  } else if (burstActive && now - burstLastLoudMs >= 100) {   // 100 ms of quiet ends the burst
    burstActive = false;
    classifyBurst(burstLastLoudMs - burstStartMs + WINDOW_MS, burstPeak);
  }
  prevFrameDb = curFrameDb;
  if (learnUntilMs && (int32_t)(now - learnUntilMs) >= 0 && !burstActive) learnFinish();
}

void readAudio() {
  size_t got = i2s.readBytes((char*)i2sBuf, sizeof(i2sBuf));
  int n = got / 4;
  if (n < WINDOW_SAMPLES / 2) return;
  double acc = 0;
  for (int i = 0; i < n; i++) {
    float x = (float)(i2sBuf[i] >> 8);                 // INMP441: 24-bit data in the top bits
    float y = 0.995f * (hpPrevOut + x - hpPrevIn);     // DC blocker / high-pass
    hpPrevIn = x; hpPrevOut = y;
    acc += (double)y * y;
    yBuf[i] = y;                                       // v3: kept for the bark features
  }
  yN = n;
  curFrameDb = (n >= 768) ? bmFrameDb(yBuf + 512) : curFrameDb;   // level of the window's last 16 ms (onset reference)
  float rms = sqrt(acc / n);
  float dbfs = 20.0f * log10f(max(rms, 1.0f) / 8388608.0f);
  {                                                    // v2.9.5 self-test: is the mic really sending data?
    int32_t rmin = i2sBuf[0], rmax = i2sBuf[0]; bool allZero = true;
    for (int i = 0; i < n; i++) { int32_t v = i2sBuf[i]; if (v) allZero = false; if (v < rmin) rmin = v; if (v > rmax) rmax = v; }
    float spl = dbfs + DBFS_TO_SPL;
    stMicWin++; if (allZero) stMicZeroWin++; else if (rmin == rmax) stMicSameWin++;
    if (stMicWin > 2) { if (spl < stMicMinDb) stMicMinDb = spl; if (spl > stMicMaxDb) stMicMaxDb = spl; }
    stMicSumDb += spl;
    if (stActive()) { levelDb = spl; return; }          // test claps / beeps are not barks
  }
  processWindow(dbfs + DBFS_TO_SPL);
}

// ---------------------------------------------------------------- outside events
// src: 5 camera webhook · 6 PIR · 7 outdoor mic. Returns a short status word.
const char* outsideEvent(uint8_t src, float db, uint8_t barkPct = 255) {   // v3: barkPct from a v3 outdoor node
  uint32_t now = millis();
  bool allowed = (src == 33) ? true : (src == 7) ? cfg.srcOutdoor : cfg.srcMotion;   // 33 = doorbell you tapped (v2.9.6)
  if (!allowed) return "source off";
  if (cleanOn) return "cleaning";                     // v2.9.4: camera / PIR / outdoor events earn nothing while cleaning
  uint32_t& last = (src == 7) ? lastOutdoorAcceptMs : lastMotionAcceptMs;
  uint32_t cool = (src == 7) ? cfg.outdoorCooldownS : cfg.motionCooldownS;
  if (last && now - last < cool * 1000UL) return "cooldown";
  last = now;
  logEvent(src, db, barkPct);
  noteTrigger(catOf(src));
  if (cfg.mode == 2) return "measure-only";
  if (cfg.mode >= 3) return "training mode";
  if (stopActive()) return "stopped";
  if (!cfg.enabled) return "dispenser off";
  if (pendingExt) return "already waiting";
  pendingExt = true; extSrc = src; extSinceMs = now;
  return "waiting for quiet";
}

// ---------------------------------------------------------------- v2: noise training ("אימון לרעשים")
// Plays a doorbell / dog-bark sound quietly. If she stays quiet for 3 s after it ends -> treat.
// Any bark -> no treat + the normal bark cooldown. The volume steps up a little each day she passes.
enum TrainState : uint8_t { T_IDLE, T_PLAYING, T_LISTEN };
TrainState tState = T_IDLE;
uint32_t tNextMs = 0, tListenFromMs = 0;
uint8_t  tLastSound = 1;
uint8_t  tCat = 1;                   // v2.9.6: kind of the sound played (0 doorbell, 1 dog bark -> noise/street)
const char* trainSlot() {
  if (cfg.trainSound == 0) return "bell";
  if (cfg.trainSound == 1) return "bark";
  tLastSound ^= 1; return tLastSound ? "bark" : "bell";
}
void trainScheduleNext(float mult = 1.0f) {
  uint32_t lo = cfg.trainGapMinS, hi = max(cfg.trainGapMaxS, cfg.trainGapMinS);
  uint32_t s = lo + (hi > lo ? esp_random() % (hi - lo + 1) : 0);
  tNextMs = millis() + (uint32_t)(s * mult * 1000.0f);
}
void trainOnBark() {
  if (tState == T_IDLE) return;
  day.trainTrials++; logEvent(16, cfg.trainVol);
  tState = T_IDLE; trainScheduleNext(2.0f);          // barked: no treat, longer pause before the next try
}
// At midnight: adjust the volume from yesterday's pass rate (at least 5 trials).
void trainDayRollover(const DayRec& y) {
  if (y.trainTrials < 5) return;
  int pass = y.trainPass * 100 / y.trainTrials;
  int v = cfg.trainVol;
  if (pass >= cfg.trainPassPct) v = min((int)cfg.trainVolMax, v + cfg.trainStep);   // she's ready: a bit louder
  else if (pass < 40) v = max(5, v - cfg.trainStep);                                 // too hard: back off
  if (v != cfg.trainVol) { cfg.trainVol = v; saveSettings(); }
  Serial.printf("[train] yesterday %d%% pass -> volume %d%%\n", pass, cfg.trainVol);
}
void trainingModeTick() {
  uint32_t now = millis();
  day.trainVol = cfg.trainVol;
  switch (tState) {
    case T_IDLE: {
      if (!tNextMs) trainScheduleNext(0.5f);
      if ((int32_t)(now - tNextMs) < 0) return;
      if (inBarkCooldown() || burstActive || now - lastSoundMs < 3000 || dispBusy() || playing) return;  // wait for a calm moment
      if (day.trainTrials >= cfg.trainMaxDay) { trainScheduleNext(); return; }      // v2.9.6: no treat cap, trials per day only
      { const char* sl = trainSlot(); tCat = strcmp(sl, "bell") == 0 ? 0 : 1;
        if (!playSound(sl, cfg.trainVol)) { lastReason = "training: no speaker"; trainScheduleNext(); return; } }
      logEvent(14, cfg.trainVol); tState = T_PLAYING; noteTrigger(tCat);
      break; }
    case T_PLAYING:
      if (!playing) { tState = T_LISTEN; tListenFromMs = now; }
      break;
    case T_LISTEN:
      // a burst still going on = she's making noise: wait for it to be classified (bark -> trainOnBark)
      if (burstActive) return;
      if (now - tListenFromMs >= (uint32_t)(cfg.trainQuietS * 1000) + 400) {   // +400 ms echo guard
        if (inBarkCooldown()) { trainOnBark(); return; }                       // חוק הזהב, double-checked
        tState = T_IDLE; day.trainTrials++; day.trainPass++; day.passC[tCat]++;
        dispense(false, "training: calm after sound", 15);
        trainScheduleNext();
      }
      break;
  }
}

// ---------------------------------------------------------------- v2: weekly summary (Fridays 12:00)
String weeklyText() {
  static DayRec all[PROG_DAYS + 1];
  int n = progAll(all, PROG_DAYS + 1);
  if (n && all[n - 1].dayKey == day.dayKey) n--;          // full days only
  int a = max(0, n - 7);
  uint32_t b = 0, t = 0, tr = 0, re = 0, cs = 0, cn = 0, qm = 0, jam = 0, pb = 0; int pd = 0;
  for (int i = a; i < n; i++) { b += all[i].barks; t += all[i].treats; tr += all[i].triggers; re += all[i].reactions; cs += all[i].calmSumS; cn += all[i].calmN; qm = max(qm, all[i].quietMaxS); jam += all[i].jams; }
  for (int i = max(0, a - 7); i < a; i++) { pb += all[i].barks; pd++; }
  int days = n - a;
  String s = "🐶 סיכום שבועי מהמתקן\n";
  if (!days) return s + "עוד אין ימים מלאים במעקב.";
  s += String("נביחות: ") + b + " (" + String((float)b / days, 1) + " ליום)\n";
  if (pd) { float prev = (float)pb / pd, cur = (float)b / days;
    if (prev > 0.5f) { int p = (int)roundf((cur - prev) / prev * 100); s += String("מול השבוע הקודם: ") + (p <= 0 ? "↓" : "↑") + abs(p) + "%\n"; } }
  { uint32_t tg = 0; for (int i = a; i < n; i++) tg += all[i].treatDg; s += String("חטיפים: ") + t + " (" + String(tg / 10.0f / days, 0) + " ג׳ ליום)\n"; }
  if (tr) s += String("תגובה לרעשים בחוץ: ") + (re * 100 / tr) + "% (" + re + " מתוך " + tr + ")\n";
  if (cn) s += String("זמן הרגעה ממוצע: ") + (cs / cn) + " שנ׳\n";
  if (qm) s += String("הרצף השקט הארוך ביותר לבד: ") + (qm / 60) + " דק׳\n";
  if (jam) s += String("תקיעות: ") + jam + "\n";
  float pct, fa, la; int fd; int v = verdict(pct, fd, fa, la);
  if (v == -2) s += String("מגמה: צריך עוד ימים (") + fd + "/7)";
  else if (v == -1) s += String("מגמה: משתפרת ↓") + (int)roundf(-pct) + "% נביחות מול השבוע הראשון 🎉";
  else if (v == 1) s += String("מגמה: מחמירה ↑") + (int)roundf(pct) + "% נביחות מול השבוע הראשון";
  else s += "מגמה: יציבה";
  return s;
}
void sendWeekly() {
  String s = weeklyText();
  sendNtfy(s, "Weekly summary", false);
  sendWhatsApp(s);
}
void weeklyTick() {
  if (!cfg.weekly || !clockValid()) return;
  struct tm t; time_t now = time(nullptr); localtime_r(&now, &t);
  if (t.tm_wday != 5 || t.tm_hour != 12) return;          // Friday, 12:00–12:59 Israel time
  int32_t k = currentDayKey();
  prefs.begin("dogstats", true); int32_t last = prefs.getInt("wkSent", 0); prefs.end();
  if (last == k) return;
  prefs.begin("dogstats", false); prefs.putInt("wkSent", k); prefs.end();
  progSave();
  sendWeekly();
}

// ---------------------------------------------------------------- training logic, every window
void trainingTick() {
  if (cleanOn) { pendingNoise = false; pendingExt = false; return; }        // v2.9.4: no auto / training treats while cleaning
  if (stopActive()) { pendingNoise = false; pendingExt = false; return; }   // v2.9.6: STOP pauses everything automatic
  if (!cfg.enabled || motorBusy() || dispBusy() || calibrateUntil) return;
  if (cfg.mode == 2) { pendingNoise = false; pendingExt = false; return; }   // רק מדידה: log only
  if (cfg.mode == 3) { trainingModeTick(); return; }                        // אימון לרעשים
  if (cfg.mode == 4) { bellGoodTick(); return; }                            // v2.9.6: פעמון = דבר טוב
  uint32_t now = millis();
  bool quietNow = !burstActive;

  // outside event: N s passed with no bark (onBark() cancels it) -> treat
  if (pendingExt) {
    uint8_t cat = catOf(extSrc);
    uint32_t waited = now - extSinceMs, need = (uint32_t)(cfg.eventQuietS * quietMult(cfg.lvl[cat]) * 1000);   // v2.9.6: thinning
    if (waited >= need && quietNow) {
      pendingExt = false;
      bool gapOk = !lastAutoTreatMs || now - lastAutoTreatMs >= (uint32_t)cfg.minGapS * 1000UL;
      if (inBarkCooldown() || !gapOk || !dispense(false, "outside event + quiet", 8)) logEvent(10, extSrc);
      else { day.passC[cat]++; diffOutcome(cat + 1, true); }
      return;
    }
    if (waited > need + 5000) { pendingExt = false; logEvent(10, extSrc); }   // never got quiet
  }
  if (inBarkCooldown()) return;                                       // חוק הזהב
  if (lastAutoTreatMs && now - lastAutoTreatMs < (uint32_t)cfg.minGapS * 1000UL) return;

  if (cfg.mode == 0) {                                                // HOME / בית
    if (!pendingNoise || !cfg.srcIndoor) return;
    if (now - pendingSinceMs > 15000) { pendingNoise = false; return; }   // stale
    if (quietNow && now - lastSoundMs >= (uint32_t)(cfg.quietAfterNoiseS * quietMult(cfg.lvl[1]) * 1000))   // v2.9.6: thinning
      if (dispense(false, "noise + quiet")) { day.passC[1]++; diffOutcome(2, true); }
  } else {                                                            // ALONE / לבד
    if (aloneTargetMs == 0) pickAloneInterval();
    if (lastBarkMs && lastBarkMs > aloneQuietStartMs) aloneQuietStartMs = lastBarkMs;
    if (quietNow && now - lastSoundMs > 3000 && now - aloneQuietStartMs >= aloneTargetMs) {
      bool clean = !aloneFailMarked;
      if (dispense(false, "quiet interval") && clean) { day.alonePass++; diffOutcome(0, true); }   // v2.9.6
    }
  }
}

// ---------------------------------------------------------------- web API
String jsonEsc(const String& s) { String o; for (char c : s) { if (c == '"' || c == '\\') o += '\\'; o += c; } return o; }

void handleStatus() {
  uint32_t now = millis();
  int32_t cool = inBarkCooldown() ? (int32_t)(cfg.barkCooldownS * 1000UL - (now - lastBarkMs)) / 1000 : 0;
  int32_t nextAlone = -1;
  if (cfg.mode == 1 && aloneTargetMs) nextAlone = ((int32_t)aloneTargetMs - (int32_t)(now - aloneQuietStartMs)) / 1000;
  String j = "{";
  j += "\"level\":" + String(levelDb, 1);
  j += ",\"base\":" + String(baseDb, 1);
  j += ",\"above\":" + String(aboveDb, 1);
  j += ",\"burst\":" + String(burstActive ? "true" : "false");
  j += ",\"enabled\":" + String(cfg.enabled ? "true" : "false");
  j += ",\"mode\":" + String(cfg.mode);
  j += ",\"treats\":" + String(sum24(today.treats));
  j += ",\"barks\":" + String(sum24(today.barks));
  j += ",\"cooldown\":" + String(max(cool, (int32_t)0));
  j += ",\"nextAlone\":" + String(nextAlone);
  j += ",\"pending\":" + String(pendingNoise ? "true" : "false");
  j += ",\"sinceBark\":" + String(lastBarkMs ? (int32_t)((now - lastBarkMs) / 1000) : -1);
  j += ",\"calibrating\":" + String(calibrateUntil ? "true" : "false");
  j += ",\"clock\":" + String(clockValid() ? "true" : "false");
  j += ",\"reason\":\"" + jsonEsc(lastReason) + "\"";
  j += ",\"ip\":\"" + WiFi.localIP().toString() + "\"";
  j += ",\"uptime\":" + String(now / 1000);
  j += ",\"barkWin\":" + String(barksWithin((uint32_t)cfg.barkWindowMin * 60000UL));
  j += ",\"barkWinMin\":" + String(cfg.barkWindowMin);
  j += ",\"ext\":" + String(pendingExt ? (int)extSrc : 0);
  j += ",\"extLeft\":" + String(pendingExt ? max(0, (int)((cfg.eventQuietS * 1000 - (now - extSinceMs)) / 1000)) : 0);
  j += ",\"outdoorAge\":" + String(lastOutdoorSeenMs ? (int32_t)((now - lastOutdoorSeenMs) / 1000) : -1);
  j += ",\"outdoorLevel\":" + String(outdoorLevel, 1);
  j += ",\"outdoorBase\":" + String(outdoorBase, 1);
  j += ",\"pir\":" + String(digitalRead(PIN_PIR) ? "true" : "false");
  // v2
  j += ",\"ir\":" + String(digitalRead(PIN_IR) == LOW ? "true" : "false");
  j += ",\"disp\":" + String((int)dState);
  j += ",\"outOfTreats\":" + String(outOfTreats ? "true" : "false");
  j += ",\"noDrop\":" + String(noDropStreak);
  j += ",\"jams\":" + String(day.jams);
  j += ",\"cleaning\":" + String(cleanOn ? "true" : "false") + ",\"cleanSt\":" + String(cState);   // v2.9.4
  j += ",\"meal\":" + String(mealBusy() ? "true" : "false") + ",\"mealServed\":" + String(mServedG, 0) + ",\"mealToday\":" + String(mealGToday, 0);
  j += ",\"playing\":" + String(playing ? "true" : "false");
  j += ",\"spkOk\":" + String(spkOk ? "true" : "false");
  j += ",\"fs\":" + String(fsOk ? "true" : "false");
  j += ",\"hasVoice\":" + String(slotHasFile("voice") ? "true" : "false");
  // v2.9.6
  j += ",\"treatG\":" + String(treatGToday(), 1) + ",\"mealG\":" + String(day.mealG) + ",\"foodG\":" + String(cfg.dailyFoodG);
  j += ",\"leftG\":" + String(gramsLeftToday(), 0) + ",\"debt\":" + String(treatDebtG, 1) + ",\"nextMeal\":" + String(nextMealG(), 0) + ",\"mealSize\":" + String(cfg.mealG);
  j += ",\"auto\":" + String(cfg.autoDiff ? "true" : "false") + ",\"lv\":[" + String(cfg.difficulty) + "," + cfg.lvl[0] + "," + cfg.lvl[1] + "," + cfg.lvl[2] + "]";
  j += ",\"ring\":["; for (int e = 0; e < 4; e++) { if (e) j += ","; j += "[" + String(ringPass(e)) + "," + dRing[e].n + "]"; } j += "]";
  j += ",\"diffMsg\":\"" + jsonEsc(diffMsg) + "\"";
  j += ",\"qHome\":" + String(cfg.quietAfterNoiseS * quietMult(cfg.lvl[1]), 1) + ",\"qExt\":" + String(cfg.eventQuietS * quietMult(pendingExt ? cfg.lvl[catOf(extSrc)] : cfg.lvl[2]), 1);
  j += ",\"stop\":" + String(stopActive() ? (int32_t)((stopUntilMs - now) / 1000) : 0) + ",\"payHand\":" + String(payByHand ? "true" : "false");
  j += ",\"staged\":" + String(stageReady() ? "true" : "false") + ",\"lat\":" + String(lastLatencyMs);
  j += ",\"bgState\":" + String(bgState) + ",\"bellVol\":" + String(cfg.bellVol) + ",\"bgNext\":" + String(bgNextMs && cfg.mode == 4 ? max((int32_t)0, (int32_t)(bgNextMs - now) / 1000) : -1);
  j += ",\"bellT\":" + String(day.bellTrials) + ",\"bellP\":" + String(day.bellPass);
  j += ",\"customBell\":" + String(slotHasFile("bell") ? "true" : "false");
  j += ",\"customBark\":" + String(slotHasFile("bark") ? "true" : "false");
  j += ",\"tState\":" + String((int)tState);
  j += ",\"tNext\":" + String(tNextMs && cfg.mode == 3 ? max((int32_t)0, (int32_t)(tNextMs - now) / 1000) : -1);
  j += ",\"tTrials\":" + String(day.trainTrials);
  j += ",\"tPass\":" + String(day.trainPass);
  j += ",\"trainVol\":" + String(cfg.trainVol);
  j += ",\"reason\":\"" + jsonEsc(lastReason) + "\"";
  j += "}";
  server.send(200, "application/json", j);
}

void handleStats() {
  rollDayIfNeeded();
  String j = "{\"day\":" + String(today.dayKey) + ",\"barks\":[";
  for (int i = 0; i < 24; i++) { if (i) j += ","; j += today.barks[i]; }
  j += "],\"treats\":[";
  for (int i = 0; i < 24; i++) { if (i) j += ","; j += today.treats[i]; }
  j += "],\"noises\":[";
  for (int i = 0; i < 24; i++) { if (i) j += ","; j += today.noises[i]; }
  j += "],\"hist\":[";
  bool first = true;
  for (int i = 0; i < HIST_DAYS; i++) {
    if (hist[i].dayKey <= 0) continue;
    if (!first) j += ","; first = false;
    j += "[" + String(hist[i].dayKey) + "," + hist[i].barks + "," + hist[i].treats + "]";
  }
  j += "],\"log\":[";
  for (int k = 0; k < evCount; k++) {
    int i = (evHead - 1 - k + LOG_N) % LOG_N;
    if (k) j += ",";
    j += "[" + String(evlog[i].t) + "," + evlog[i].type + "," + String(evlog[i].db, 1) + "," + evlog[i].conf + "," + evlog[i].bid + "]";
  }
  j += "],\"clock\":" + String(clockValid() ? "true" : "false") + "}";
  server.send(200, "application/json", j);
}


// ---------------------------------------------------------------- v3: bark-recognition endpoints
String featJson(const BarkFeat& x) {
  String j = "["; for (int i = 0; i < BM_NF; i++) { if (i) j += ","; j += String(x.f[i], 3); } return j + "]";
}
void handleBursts() {               // GET /api/bursts — model state + last 20 classified sounds with features
  uint32_t now = millis();
  String j = "{\"sens\":" + String(cfg.barkSens) + ",\"thr\":" + String(bmThreshold(cfg.barkSens), 2) + ",\"band\":" + String(askBandF(), 2);
  j += ",\"tplN\":" + String(bmTpl.n) + ",\"tplMin\":" + String(BM_TPL_MIN) + ",\"negN\":" + String(bmNegN);
  j += ",\"learn\":" + String(learnUntilMs ? (int32_t)max(0L, (long)(learnUntilMs - now) / 1000) : -1);
  j += ",\"learnN\":" + String(learnN) + ",\"learnMsg\":\"" + learnMsg + "\"";
  j += ",\"clock\":" + String(clockValid() ? "true" : "false");
  j += ",\"names\":["; for (int i = 0; i < BM_NF; i++) { if (i) j += ","; j += "\"" + String(BM_NAMES[i]) + "\""; } j += "]";
  j += ",\"list\":[";
  for (int k = 0; k < brCount; k++) {
    int i = (brHead - 1 - k + BR_N) % BR_N; const BurstRec& r = brLog[i];
    if (k) j += ",";
    j += "{\"id\":" + String(r.id) + ",\"t\":" + String(r.t) + ",\"v\":" + r.verdict + ",\"p\":" + r.pct +
         ",\"rep\":" + r.rep + ",\"fixed\":" + r.fixed + ",\"db\":" + String(r.peak, 1) + ",\"ms\":" + r.durMs + ",\"f\":" + featJson(r.x) + "}";
  }
  j += "]}";
  server.send(200, "application/json", j);
}
// POST /api/bark-learn  action=start|stop|cancel|reset-template|reset-neg|reset-all
void handleBarkLearn() {
  String a = server.arg("action");
  if (a == "start") { learnN = 0; learnMsg = "recording"; learnUntilMs = millis() + 30000UL; if (!learnUntilMs) learnUntilMs = 1; }
  else if (a == "stop") { if (learnUntilMs) learnFinish(); }
  else if (a == "cancel") { learnUntilMs = 0; learnN = 0; learnMsg = "cancelled"; }
  else if (a == "reset-template") { memset(&bmTpl, 0, sizeof(bmTpl)); bmSave(); learnMsg = ""; }
  else if (a == "reset-neg") { memset(bmNeg, 0, sizeof(bmNeg)); bmNegN = 0; bmNegHead = 0; bmSave(); }
  else if (a == "reset-all") { memset(&bmTpl, 0, sizeof(bmTpl)); memset(bmNeg, 0, sizeof(bmNeg)); bmNegN = 0; bmNegHead = 0; bmSave(); learnMsg = ""; }
  else { server.send(400, "application/json", "{\"ok\":false}"); return; }
  handleBursts();
}
// POST /api/bark-label  id=N&bark=0  ("זה לא היה נביחה")  |  bark=1  ("זו כן נביחה")
// v2.9.8: the labelling itself is a function so the remote "label" command runs the very same path
bool barkLabel(uint16_t id, bool bark) {
  BurstRec* r = brFind(id);
  if (!r) return false;
  if (bark) { bmTplAdd(bmTpl, r->x); r->fixed = 2; logEvent(22, r->peak, 255, r->id); }
  else { bmAddNeg(r->x); r->fixed = 1; logEvent(21, r->peak, 255, r->id); }
  bmSave();
  return true;
}
void handleBarkLabel() {
  if (!barkLabel((uint16_t)server.arg("id").toInt(), server.arg("bark") == "1")) { server.send(404, "application/json", "{\"ok\":false,\"err\":\"gone\"}"); return; }
  handleBursts();
}

void handleGetSettings() {
  String j = "{";
  j += "\"enabled\":" + String(cfg.enabled ? 1 : 0);
  j += ",\"mode\":" + String(cfg.mode);
  j += ",\"noiseDb\":" + String(cfg.noiseDb, 1);
  j += ",\"barkDb\":" + String(cfg.barkDb, 1);
  j += ",\"barkMinMs\":" + String(cfg.barkMinMs);
  j += ",\"barkSens\":" + String(cfg.barkSens);
  j += ",\"barkMaxMs\":" + String(cfg.barkMaxMs);
  j += ",\"quietAfterNoiseS\":" + String(cfg.quietAfterNoiseS, 1);
  j += ",\"barkCooldownS\":" + String(cfg.barkCooldownS);
  j += ",\"minGapS\":" + String(cfg.minGapS);
  j += ",\"postTreatIgnoreS\":" + String(cfg.postTreatIgnoreS);
  j += ",\"aloneMinS\":" + String(cfg.aloneMinS);
  j += ",\"aloneMaxS\":" + String(cfg.aloneMaxS);
  j += ",\"difficulty\":" + String(cfg.difficulty);
  j += ",\"clicker\":" + String(cfg.clicker ? 1 : 0);
  j += ",\"stepsPerTreat\":" + String(cfg.stepsPerTreat);
  j += ",\"stepUs\":" + String(cfg.stepUs);
  j += ",\"reverseDir\":" + String(cfg.reverseDir ? 1 : 0);
  j += ",\"ntfyTopic\":\"" + jsonEsc(cfg.ntfyTopic) + "\"";
  j += ",\"ntfyBarks\":" + String(cfg.ntfyBarks);
  j += ",\"srcIndoor\":" + String(cfg.srcIndoor ? 1 : 0);
  j += ",\"srcOutdoor\":" + String(cfg.srcOutdoor ? 1 : 0);
  j += ",\"srcMotion\":" + String(cfg.srcMotion ? 1 : 0);
  j += ",\"eventQuietS\":" + String(cfg.eventQuietS, 1);
  j += ",\"motionCooldownS\":" + String(cfg.motionCooldownS);
  j += ",\"token\":\"" + jsonEsc(cfg.token) + "\"";
  j += ",\"camHost\":\"" + jsonEsc(cfg.camHost) + "\"";
  j += ",\"ntfyOnTreat\":" + String(cfg.ntfyOnTreat ? 1 : 0);
  j += ",\"pushOn\":" + String(cfg.pushOn ? 1 : 0) + ",\"askPush\":" + String(cfg.askPush ? 1 : 0) + ",\"askBand\":" + String(cfg.askBand);   // v2.9.7
  j += ",\"barkWindowMin\":" + String(cfg.barkWindowMin);
  j += ",\"outdoorMinDb\":" + String(cfg.outdoorMinDb, 1);
  j += ",\"outdoorMinMs\":" + String(cfg.outdoorMinMs);
  j += ",\"outdoorCooldownS\":" + String(cfg.outdoorCooldownS);
  j += ",\"irFitted\":" + String(cfg.irFitted ? 1 : 0);
  j += ",\"dailyFoodG\":" + String(cfg.dailyFoodG) + ",\"treatFromMeal\":" + String(cfg.treatFromMeal ? 1 : 0) + ",\"mealFloorPct\":" + String(cfg.mealFloorPct);   // v2.9.6
  j += ",\"autoDiff\":" + String(cfg.autoDiff ? 1 : 0) + ",\"lvlDoor\":" + String(cfg.lvl[0]) + ",\"lvlNoise\":" + String(cfg.lvl[1]) + ",\"lvlMotion\":" + String(cfg.lvl[2]);
  j += ",\"bellVol\":" + String(cfg.bellVol) + ",\"bellVolMax\":" + String(cfg.bellVolMax) + ",\"targetKg\":" + String(cfg.targetKg, 1);
  j += ",\"stageOn\":" + String(cfg.stageOn ? 1 : 0) + ",\"stagePct\":" + String(cfg.stagePct) + ",\"mealG\":" + String(cfg.mealG);
  j += ",\"dropWaitMs\":" + String(cfg.dropWaitMs);
  j += ",\"retries\":" + String(cfg.retries);
  j += ",\"emptyAfter\":" + String(cfg.emptyAfter);
  j += ",\"agitateSteps\":" + String(cfg.agitateSteps);
  j += ",\"spkFitted\":" + String(cfg.spkFitted ? 1 : 0);
  j += ",\"volume\":" + String(cfg.volume);
  j += ",\"voiceOnTreat\":" + String(cfg.voiceOnTreat ? 1 : 0);
  j += ",\"trainSound\":" + String(cfg.trainSound);
  j += ",\"trainVol\":" + String(cfg.trainVol);
  j += ",\"trainStep\":" + String(cfg.trainStep);
  j += ",\"trainVolMax\":" + String(cfg.trainVolMax);
  j += ",\"trainPassPct\":" + String(cfg.trainPassPct);
  j += ",\"trainGapMinS\":" + String(cfg.trainGapMinS);
  j += ",\"trainGapMaxS\":" + String(cfg.trainGapMaxS);
  j += ",\"trainQuietS\":" + String(cfg.trainQuietS, 1);
  j += ",\"trainMaxDay\":" + String(cfg.trainMaxDay);
  j += ",\"weekly\":" + String(cfg.weekly ? 1 : 0);
  j += ",\"cmbPhone\":\"" + jsonEsc(cfg.cmbPhone) + "\"";
  j += ",\"cmbKey\":\"" + jsonEsc(cfg.cmbKey) + "\"";
  j += "}";
  server.send(200, "application/json", j);
}

// POST /api/settings with form fields; only the fields sent are changed.
void handlePostSettings() {
  auto has = [](const char* k) { return server.hasArg(k); };
  auto f = [](const char* k) { return server.arg(k).toFloat(); };
  auto u = [](const char* k) { return (long)server.arg(k).toInt(); };
  uint8_t oldMode = cfg.mode;
  if (has("enabled"))  cfg.enabled = u("enabled") != 0;
  if (has("mode"))     cfg.mode = constrain(u("mode"), 0, 4);
  if (has("noiseDb"))  cfg.noiseDb = constrain(f("noiseDb"), 2.0f, 40.0f);
  if (has("barkDb"))   cfg.barkDb = constrain(f("barkDb"), 4.0f, 60.0f);
  if (has("barkMinMs"))cfg.barkMinMs = constrain(u("barkMinMs"), 30, 2000);
  if (has("barkSens")) cfg.barkSens = constrain(u("barkSens"), 0, 2);
  if (has("barkMaxMs"))cfg.barkMaxMs = constrain(u("barkMaxMs"), 100, 3000);
  if (has("quietAfterNoiseS")) cfg.quietAfterNoiseS = constrain(f("quietAfterNoiseS"), 0.5f, 30.0f);
  if (has("barkCooldownS"))    cfg.barkCooldownS = constrain(u("barkCooldownS"), 2, 600);
  if (has("minGapS"))          cfg.minGapS = constrain(u("minGapS"), 5, 3600);
  if (has("postTreatIgnoreS")) cfg.postTreatIgnoreS = constrain(u("postTreatIgnoreS"), 0, 120);
  if (has("aloneMinS")) cfg.aloneMinS = constrain(u("aloneMinS"), 10, 7200);
  if (has("aloneMaxS")) cfg.aloneMaxS = constrain(u("aloneMaxS"), 10, 14400);
  if (has("difficulty"))cfg.difficulty = constrain(u("difficulty"), 1, 10);
  if (has("clicker"))   cfg.clicker = u("clicker") != 0;
  if (has("stepsPerTreat")) cfg.stepsPerTreat = constrain(u("stepsPerTreat"), 50, 8192);
  if (has("stepUs"))    cfg.stepUs = constrain(u("stepUs"), 900, 10000);
  if (has("reverseDir"))cfg.reverseDir = u("reverseDir") != 0;
  if (has("ntfyTopic")) { cfg.ntfyTopic = askCleanTopic(server.arg("ntfyTopic")); }   // v2.9.7: valid ntfy name, never empty
  if (has("pushOn"))  cfg.pushOn = u("pushOn") != 0;
  if (has("askPush")) cfg.askPush = u("askPush") != 0;
  if (has("askBand")) cfg.askBand = (uint8_t)constrain(u("askBand"), 0, 40);
  if (has("ntfyBarks")) cfg.ntfyBarks = constrain(u("ntfyBarks"), 1, 16);
  if (has("srcIndoor"))  cfg.srcIndoor = u("srcIndoor") != 0;
  if (has("srcOutdoor")) cfg.srcOutdoor = u("srcOutdoor") != 0;
  if (has("srcMotion"))  cfg.srcMotion = u("srcMotion") != 0;
  if (has("eventQuietS")) cfg.eventQuietS = constrain(f("eventQuietS"), 1.0f, 60.0f);
  if (has("motionCooldownS")) cfg.motionCooldownS = constrain(u("motionCooldownS"), 0, 3600);
  if (has("camHost")) { cfg.camHost = server.arg("camHost"); cfg.camHost.trim(); cfg.camHost.replace("http://", ""); if (cfg.camHost.endsWith("/")) cfg.camHost.remove(cfg.camHost.length() - 1); }
  if (has("ntfyOnTreat")) cfg.ntfyOnTreat = u("ntfyOnTreat") != 0;
  if (has("barkWindowMin")) cfg.barkWindowMin = constrain(u("barkWindowMin"), 1, 120);
  if (has("outdoorMinDb")) cfg.outdoorMinDb = constrain(f("outdoorMinDb"), 3.0f, 50.0f);
  if (has("outdoorMinMs")) cfg.outdoorMinMs = constrain(u("outdoorMinMs"), 50, 5000);
  if (has("outdoorCooldownS")) cfg.outdoorCooldownS = constrain(u("outdoorCooldownS"), 0, 3600);
  if (has("token")) { cfg.token = server.arg("token"); cfg.token.trim(); if (cfg.token.length() > 15) cfg.token = cfg.token.substring(0, 15); }
  if (has("irFitted"))   cfg.irFitted = u("irFitted") != 0;
  if (has("dailyFoodG"))  cfg.dailyFoodG = constrain(u("dailyFoodG"), 50, 2000);   // v2.9.6
  if (has("treatFromMeal")) cfg.treatFromMeal = u("treatFromMeal") != 0;
  if (has("mealFloorPct")) cfg.mealFloorPct = constrain(u("mealFloorPct"), 50, 100);   // never below half a meal
  if (has("autoDiff"))   cfg.autoDiff = u("autoDiff") != 0;
  if (has("lvlDoor"))    cfg.lvl[0] = constrain(u("lvlDoor"), 1, 10);
  if (has("lvlNoise"))   cfg.lvl[1] = constrain(u("lvlNoise"), 1, 10);
  if (has("lvlMotion"))  cfg.lvl[2] = constrain(u("lvlMotion"), 1, 10);
  if (has("bellVolMax")) cfg.bellVolMax = constrain(u("bellVolMax"), 3, 60);
  if (has("bellVol"))    cfg.bellVol = constrain(u("bellVol"), 1, 60);
  if (cfg.bellVol > cfg.bellVolMax) cfg.bellVol = cfg.bellVolMax;
  if (has("targetKg"))   { float t = f("targetKg"); if (t >= 2 && t <= 120) cfg.targetKg = t; }
  if (has("stageOn"))    { cfg.stageOn = u("stageOn") != 0; staged = false; if (cfg.stageOn) stageDueMs = millis() + 500; }
  if (has("stagePct"))   { cfg.stagePct = constrain(u("stagePct"), 40, 95); staged = false; if (cfg.stageOn) stageDueMs = millis() + 500; }
  if (has("difficulty") || has("lvlDoor") || has("lvlNoise") || has("lvlMotion")) { for (int e = 0; e < 4; e++) { dRing[e].n = 0; dRing[e].bits = 0; } diffMsg = ""; }  if (has("dropWaitMs")) cfg.dropWaitMs = constrain(u("dropWaitMs"), 300, 5000);
  if (has("retries"))    cfg.retries = constrain(u("retries"), 0, 6);
  if (has("emptyAfter")) cfg.emptyAfter = constrain(u("emptyAfter"), 1, 20);
  if (has("agitateSteps")) cfg.agitateSteps = constrain(u("agitateSteps"), 0, 1000);
  if (has("spkFitted"))  cfg.spkFitted = u("spkFitted") != 0;
  if (has("volume"))     cfg.volume = constrain(u("volume"), 0, 100);
  if (has("voiceOnTreat")) cfg.voiceOnTreat = u("voiceOnTreat") != 0;
  if (has("trainSound")) cfg.trainSound = constrain(u("trainSound"), 0, 2);
  if (has("trainVol"))   cfg.trainVol = constrain(u("trainVol"), 1, 100);
  if (has("trainStep"))  cfg.trainStep = constrain(u("trainStep"), 0, 30);
  if (has("trainVolMax"))cfg.trainVolMax = constrain(u("trainVolMax"), 5, 100);
  if (has("trainPassPct")) cfg.trainPassPct = constrain(u("trainPassPct"), 30, 100);
  if (has("trainGapMinS")) cfg.trainGapMinS = constrain(u("trainGapMinS"), 15, 3600);
  if (has("trainGapMaxS")) cfg.trainGapMaxS = constrain(u("trainGapMaxS"), 15, 7200);
  if (has("trainQuietS"))  cfg.trainQuietS = constrain(f("trainQuietS"), 1.0f, 30.0f);
  if (has("trainMaxDay"))  cfg.trainMaxDay = constrain(u("trainMaxDay"), 1, 100);
  if (has("weekly"))     cfg.weekly = u("weekly") != 0;
  if (has("cmbPhone"))   { cfg.cmbPhone = server.arg("cmbPhone"); cfg.cmbPhone.trim(); cfg.cmbPhone.replace("+", ""); cfg.cmbPhone.replace(" ", ""); cfg.cmbPhone.replace("-", ""); }
  if (has("cmbKey"))     { cfg.cmbKey = server.arg("cmbKey"); cfg.cmbKey.trim(); }
  if (cfg.trainVol > cfg.trainVolMax) cfg.trainVol = cfg.trainVolMax;
  if (cfg.barkDb < cfg.noiseDb + 2) cfg.barkDb = cfg.noiseDb + 2;
  if (cfg.mode != oldMode) { pendingNoise = false; pendingExt = false; pickAloneInterval(); tState = T_IDLE; tNextMs = 0; quietStreakStartMs = 0; bgState = 0; bgNextMs = 0; }
  saveSettings();
  handleGetSettings();
}

// GET/POST /api/motion?src=cam|pir|mic&token=XXXX&db=NN  — for cameras, Home Assistant, MacroDroid…
void handleMotion() {
  if (cfg.token.length() && server.arg("token") != cfg.token) { server.send(403, "application/json", "{\"ok\":false,\"error\":\"bad token\"}"); return; }
  String s = server.arg("src");
  uint8_t src = (s == "mic") ? 7 : (s == "pir") ? 6 : 5;
  if (src == 7) { lastOutdoorSeenMs = millis(); }
  const char* r = outsideEvent(src, server.hasArg("db") ? server.arg("db").toFloat() : 0);
  server.send(200, "application/json", String("{\"ok\":true,\"status\":\"") + r + "\"}");
}

// ESP-NOW packet from the outdoor mic node (see DogTreatOutdoor). Levels/events only, never audio.
struct __attribute__((packed)) OutdoorPacket {
  char magic[4];      // "DTO1"
  uint8_t type;       // 0 = heartbeat, 1 = sound event, 2 = PIR motion
  uint32_t seq;
  float levelDb, baseDb, eventDb;   // eventDb = dB above the outdoor baseline
  uint16_t eventMs;                 // sound length
  uint8_t battPct;                  // 255 = unknown / USB
  char token[16];
  uint8_t barkPct;                  // v3 node only: bark score of the sound 0-100 (255 = not classified)
};
static const int OUTDOOR_V2_LEN = sizeof(OutdoorPacket) - 1;   // v2 nodes send the packet without barkPct
void onEspNowRecv(const esp_now_recv_info_t* info, const uint8_t* data, int len) {
  if (len != (int)sizeof(OutdoorPacket) && len != OUTDOOR_V2_LEN) return;
  OutdoorPacket p; memset(&p, 0, sizeof(p)); memcpy(&p, data, len);
  if (len == OUTDOOR_V2_LEN) p.barkPct = 255;
  if (memcmp(p.magic, "DTO1", 4) != 0) return;
  p.token[15] = 0;
  if (cfg.token.length() && cfg.token != String(p.token)) { stOutBadTok++; return; }
  lastOutdoorSeenMs = millis(); outdoorLevel = p.levelDb; outdoorBase = p.baseDb;
  stOutPkts++; if (p.levelDb < stOutLvlMin) stOutLvlMin = p.levelDb; if (p.levelDb > stOutLvlMax) stOutLvlMax = p.levelDb;   // v2.9.5
  if (p.type == 2 && p.seq != lastOutdoorSeq) { stOutPir++; outPirTotal++; }
  if (p.type != 0 && p.seq != lastOutdoorSeq) {     // the node sends each packet on every channel -> de-duplicate
    lastOutdoorSeq = p.seq;
    if (p.type == 1 && (p.eventDb < cfg.outdoorMinDb || p.eventMs < cfg.outdoorMinMs)) return;  // below the UI sensitivity
    espNowDb = p.eventDb; espNowMs = p.eventMs; espNowBark = p.barkPct; espNowEvent = (p.type == 2) ? 6 : 7;
  }
}
void setupEspNow() {
  if (esp_now_init() != ESP_OK) { Serial.println("[espnow] init failed"); return; }
  esp_now_register_recv_cb(onEspNowRecv);
  uint8_t ch; wifi_second_chan_t sc; esp_wifi_get_channel(&ch, &sc);
  Serial.printf("[espnow] listening on channel %d, MAC %s\n", ch, WiFi.macAddress().c_str());
}

void handleTreat() {
  if (cfg.mode == 2) { server.send(409, "application/json", "{\"ok\":false,\"measure\":true}"); return; }
  if (cleanOn) { server.send(409, "application/json", "{\"ok\":false,\"cleaning\":true}"); return; }   // v2.9.4
  bool ok = dispense(true, "manual");
  server.send(ok ? 200 : 409, "application/json", ok ? String("{\"ok\":true}") : String("{\"ok\":false,\"busy\":true,\"why\":\"") + busyWhy() + "\"}");
}
// ---- v2 handlers
void handleDays() {                                   // all stored days, oldest first
  static DayRec all[PROG_DAYS + 1];
  rollDayIfNeeded();
  int n = progAll(all, PROG_DAYS + 1);
  String j = "{\"today\":" + String(day.dayKey) + ",\"days\":[";
  for (int i = 0; i < n; i++) { const DayRec& r = all[i]; if (i) j += ",";
    j += "[" + String(r.dayKey) + "," + r.barks + "," + r.episodes + "," + r.triggers + "," + r.reactions + "," + r.treats + "," +
         r.calmSumS + "," + r.calmN + "," + r.quietMaxS + "," + r.jams + "," + r.doubles + "," + r.trainTrials + "," + r.trainPass + "," + r.modeMask + "," + r.trainVol + "," + r.treatDg + "," + r.mealG +
         "," + r.trigC[0] + "," + r.reactC[0] + "," + r.passC[0] + "," + r.trigC[1] + "," + r.reactC[1] + "," + r.passC[1] + "," + r.trigC[2] + "," + r.reactC[2] + "," + r.passC[2] +
         "," + r.bellTrials + "," + r.bellPass + "," + r.aloneTry + "," + r.alonePass + "," + r.lvl[0] + "," + r.lvl[1] + "," + r.lvl[2] + "," + r.lvl[3] + "," + r.spills + "]"; }   // v2.9.6
  j += "]}";
  server.send(200, "application/json", j);
}
void handleDaysCsv() {
  static DayRec all[PROG_DAYS + 1];
  int n = progAll(all, PROG_DAYS + 1);
  String c = "\xEF\xBB\xBF" "date,barks,bark_episodes,outside_triggers,reactions,reactivity_pct,avg_time_to_calm_s,longest_quiet_alone_min,treats,jams,double_drops,training_trials,training_pass,modes,treat_g,meal_g,"
                    "doorbell_triggers,doorbell_barked,doorbell_earned,noise_street_triggers,noise_street_barked,noise_street_earned,motion_triggers,motion_barked,motion_earned,"
                    "doorbell_good_trials,doorbell_good_calm,alone_barked_intervals,alone_calm_intervals,level_alone,level_doorbell,level_noise,level_motion,fast_treat_empty_at_click\n";
  for (int i = 0; i < n; i++) { const DayRec& r = all[i]; char d[12]; snprintf(d, sizeof(d), "%04ld-%02ld-%02ld", (long)(r.dayKey / 10000), (long)(r.dayKey / 100 % 100), (long)(r.dayKey % 100));
    String m; if (r.modeMask & 1) m += "home "; if (r.modeMask & 2) m += "alone "; if (r.modeMask & 4) m += "measure "; if (r.modeMask & 8) m += "training "; if (r.modeMask & 16) m += "doorbell_good "; m.trim();
    c += String(d) + "," + r.barks + "," + r.episodes + "," + r.triggers + "," + r.reactions + "," + (r.triggers ? String(r.reactions * 100.0f / r.triggers, 1) : String("")) + "," +
         (r.calmN ? String((float)r.calmSumS / r.calmN, 1) : String("")) + "," + String(r.quietMaxS / 60.0f, 1) + "," + r.treats + "," + r.jams + "," + r.doubles + "," + r.trainTrials + "," + r.trainPass + "," + m + "," + String(r.treatDg / 10.0f, 1) + "," + r.mealG +
         "," + r.trigC[0] + "," + r.reactC[0] + "," + r.passC[0] + "," + r.trigC[1] + "," + r.reactC[1] + "," + r.passC[1] + "," + r.trigC[2] + "," + r.reactC[2] + "," + r.passC[2] +
         "," + r.bellTrials + "," + r.bellPass + "," + r.aloneTry + "," + r.alonePass + "," + r.lvl[0] + "," + r.lvl[1] + "," + r.lvl[2] + "," + r.lvl[3] + "," + r.spills + "\n"; }
  server.sendHeader("Content-Disposition", "attachment; filename=dog-progress.csv");
  server.send(200, "text/csv; charset=utf-8", c);
}
bool validSlot(const String& s) { return s == "voice" || s == "bell" || s == "bark"; }   // v2.9.6: "come" (recall) removed
File upFile; String upSlot; bool upOk = false;
void handleSoundUpload() {                            // multipart upload from the web page (16-bit mono WAV)
  HTTPUpload& up = server.upload();
  if (up.status == UPLOAD_FILE_START) {
    upSlot = server.arg("slot"); upOk = fsOk && validSlot(upSlot);
    if (upOk) { LittleFS.mkdir("/snd"); upFile = LittleFS.open("/snd/up.tmp", "w"); upOk = (bool)upFile; }
  } else if (up.status == UPLOAD_FILE_WRITE) {
    if (upOk && upFile.size() + up.currentSize > 400000) { upOk = false; upFile.close(); }   // max ~12 s
    if (upOk) upFile.write(up.buf, up.currentSize);
  } else if (up.status == UPLOAD_FILE_END || up.status == UPLOAD_FILE_ABORTED) {
    if (upFile) upFile.close();
    if (upOk && up.status == UPLOAD_FILE_END) { LittleFS.remove(slotPath(upSlot.c_str())); LittleFS.rename("/snd/up.tmp", slotPath(upSlot.c_str())); }
    else { LittleFS.remove("/snd/up.tmp"); upOk = false; }
  }
}
void handleSoundDone() {
  server.send(upOk ? 200 : 400, "application/json", upOk ? "{\"ok\":true}" : "{\"ok\":false,\"error\":\"upload failed (too big or bad slot)\"}");
}
void handlePlay() {                                    // POST /api/play?slot=voice|bell|bark&vol=NN
  String s = server.arg("slot"); if (!validSlot(s) && s != "click") s = "voice";
  uint8_t v = server.hasArg("vol") ? constrain(server.arg("vol").toInt(), 0, 100) : (s == "voice" ? cfg.volume : cfg.trainVol);
  bool ok = playSound(s.c_str(), v);
  if (!ok) clickSound();                               // no speaker / no recording -> buzzer click
  server.send(200, "application/json", String("{\"ok\":true,\"speaker\":") + (ok ? "true" : "false") + "}");
}
void handleSoundDel() {
  String s = server.arg("slot");
  if (fsOk && validSlot(s)) LittleFS.remove(slotPath(s.c_str()));
  server.send(200, "application/json", "{\"ok\":true}");
}
#include "selftest.h"   // v2.9.5: connection self-test (/check)
#include "train296.h"   // v2.9.6: grams, auto difficulty, per-trigger, doorbell = good thing, weight, STOP, fast treat
void handleLedTest() {                                 // v2.7.1: R, G, B one second each, then off
  setRgb(true, false, false); delay(1000); setRgb(false, true, false); delay(1000);
  setRgb(false, false, true); delay(1000); setRgb(false, false, false);
  server.send(200, "application/json", String("{\"ok\":true,\"green\":") + (PIN_LED_G >= 0 ? "true" : "false") + "}");
}
void ledTick() {                                       // v2.7.1: red blink while out of treats/food (not while dispensing)
  static bool was = false;
  if (stLedBusy()) return;                             // v2.9.5: the self-test owns the LED for a few seconds
  if (cleanOn) {                                       // v2.9.4: slow double-blink, blue, the whole time in cleaning mode
    uint32_t t = millis() % 2500; setRgb(false, false, t < 150 || (t >= 350 && t < 500)); was = true; return;
  }
  bool alert = (outOfTreats || outOfFood) && !dispBusy() && !mealBusy();
  if (alert) { bool on = (millis() % 2000) < 200; setRgb(on, false, false); was = true; }
  else if (was) { was = false; if (!dispBusy()) setRgb(false, false, false); }
}
void handleRefilled() { outOfTreats = false; outOfFood = false; noDropStreak = 0; payByHand = false; logEvent(18, 0); server.send(200, "application/json", "{\"ok\":true}"); }
void handleWeeklyNow() { progSave(); String s = weeklyText(); sendNtfy(s, "Weekly summary", false); int w = sendWhatsApp(s);
  server.send(200, "application/json", String("{\"ok\":true,\"whatsapp\":") + w + "}"); }
void handleTrainNow() { tNextMs = millis(); server.send(200, "application/json", "{\"ok\":true}"); }
void handleCalibrate() {
  calibSum = 0; calibN = 0; calibrateUntil = millis() + 5000;
  server.send(200, "application/json", "{\"ok\":true,\"seconds\":5}");
}
void handleTestNtfy() {
  sendNtfy("✅ DogTreat test notification");
  server.send(200, "application/json", "{\"ok\":true}");
}
void handleResetStats() {
  { int32_t k = day.dayKey; memset(&day, 0, sizeof(day)); day.dayKey = k; progSave(); }   // today only
  memset(today.barks, 0, sizeof(today.barks)); memset(today.treats, 0, sizeof(today.treats));
  memset(today.noises, 0, sizeof(today.noises)); evCount = 0; evHead = 0; saveStats();
  server.send(200, "application/json", "{\"ok\":true}");
}
void handleResetWifi() {
  server.send(200, "application/json", "{\"ok\":true}");
  delay(300);
  WiFiManager wm; wm.resetSettings();
  ESP.restart();
}

#include "diag.h"   // v2.9.6 help: /api/diag read-only diagnostics for the "מה לא עובד" page
#include "remote.h" // v2.9.8: "שליטה מרחוק" — signed commands via ntfy.sh (protocol: REMOTE_PROTOCOL.md)

// ---------------------------------------------------------------- setup / loop
void setupI2S() {
  i2s.setPins(PIN_I2S_SCK, PIN_I2S_WS, -1, PIN_I2S_SD);
  // INMP441 with L/R tied to GND -> left slot, 32-bit frames
  if (!i2s.begin(I2S_MODE_STD, SAMPLE_RATE, I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_MONO, I2S_STD_SLOT_LEFT)) {
    micInitOk = false;
    Serial.println("[i2s] init FAILED — check mic wiring");
  }
  i2s.setTimeout(200);
}

void setup() {
  pinMode(PIN_BUZZER, OUTPUT); buzzerOff();          // v2.7.1: FIRST thing -- active-LOW buzzer must idle HIGH (silent)
  Serial.begin(115200);
  pinMode(PIN_LED, OUTPUT); pinMode(PIN_BOARD_LED, OUTPUT);
  if (PIN_LED_G >= 0) pinMode(PIN_LED_G, OUTPUT);
  pinMode(PIN_LED_B, OUTPUT);
  setRgb(true, true, true); delay(150); setRgb(false, false, false);   // white flash = all 3 colours wired
  pinMode(PIN_PIR, INPUT_PULLDOWN);    // nothing connected = no motion
  pinMode(PIN_IR, INPUT_PULLUP);       // IR module OUT is LOW when a treat is in the beam
  attachInterrupt(digitalPinToInterrupt(PIN_IR), irISR, CHANGE);
  for (int i = 0; i < 4; i++) { pinMode(PIN_STEP[i], OUTPUT); }
  coilsOff();
  if (PIN_CLEAN_BTN >= 0) pinMode(PIN_CLEAN_BTN, INPUT_PULLUP);   // v2.9.4
  cleanLoad();                                         // v2.9.4: still in cleaning mode after a power cut? stay there, motor released
  clutchLoad(); if (!clutchValid && !cleanOn) startClutchSync();   // v2.9: both clutches synced after a fresh flash / power cut mid-move (v2.9.4: after cleaning)
  loadSettings();
  loadStats();
  mealLoadDone();
  bmLoad(); bmInit();                   // v3: your dog's bark template + "not a bark" examples
  fsOk = LittleFS.begin(true);          // formats the 1 MB data partition on first boot
  if (fsOk) { LittleFS.remove("/days295.bin"); LittleFS.remove("/days.bin"); LittleFS.remove("/snd/come.wav"); }   // v2.9.6: old formats / recall clip
  if (!fsOk) Serial.println("[fs] LittleFS mount FAILED — progress and recordings disabled");
  else { LittleFS.mkdir("/snd"); progEnsureFile(); }
  memset(&day, 0, sizeof(day)); day.dayKey = -1;
  setupI2S();
  setupSpeaker();

  // Wi-Fi: first boot opens the hotspot "DogTreat-Setup" -> choose your home Wi-Fi from the phone
  WiFi.mode(WIFI_STA);
  WiFiManager wm;
  wm.setConfigPortalTimeout(180);        // after 3 min keep working offline
  wm.setHostname("dogtreat");
  digitalWrite(PIN_BOARD_LED, HIGH);
  bool ok = wm.autoConnect("DogTreat-Setup");
  digitalWrite(PIN_BOARD_LED, LOW);
  if (ok) {
    Serial.print("[wifi] IP: "); Serial.println(WiFi.localIP());
    configTzTime("IST-2IDT,M3.4.4/26,M10.5.0", "pool.ntp.org", "time.google.com");  // Israel time
    if (MDNS.begin("dogtreat")) MDNS.addService("http", "tcp", 80);
  } else {
    Serial.println("[wifi] not connected — running offline (no web page)");
  }
  askEnsureTopic();                      // v2.9.7: random ntfy topic, made once and saved

  server.on("/", HTTP_GET, []() { server.send_P(200, "text/html; charset=utf-8", INDEX_HTML); });
  server.on("/f.woff2", HTTP_GET, []() { server.sendHeader("Cache-Control", "public, max-age=31536000"); server.send_P(200, "font/woff2", (const char*)SUEZ_WOFF2, SUEZ_WOFF2_LEN); });  // UI font (look only)
  server.on("/api/status", HTTP_GET, handleStatus);
  server.on("/api/stats", HTTP_GET, handleStats);
  server.on("/api/settings", HTTP_GET, handleGetSettings);
  server.on("/api/settings", HTTP_POST, handlePostSettings);
  server.on("/api/treat", HTTP_POST, handleTreat);
  server.on("/api/motion", HTTP_ANY, handleMotion);
  server.on("/api/calibrate", HTTP_POST, handleCalibrate);
  server.on("/api/test-ntfy", HTTP_POST, handleTestNtfy);
  server.on("/api/ask-test", HTTP_POST, handleAskTest);    // v2.9.7
  server.on("/api/ask-ping", HTTP_ANY, handleAskPing);
  server.on("/api/ask", HTTP_GET, handleAskState);
  server.on("/api/reset-stats", HTTP_POST, handleResetStats);
  server.on("/api/reset-wifi", HTTP_POST, handleResetWifi);
  server.on("/api/days", HTTP_GET, handleDays);
  server.on("/api/days.csv", HTTP_GET, handleDaysCsv);
  server.on("/api/sound", HTTP_POST, handleSoundDone, handleSoundUpload);
  server.on("/api/play", HTTP_POST, handlePlay);
  server.on("/api/sound-del", HTTP_POST, handleSoundDel);
  server.on("/api/refilled", HTTP_POST, handleRefilled);
  server.on("/api/weekly-now", HTTP_POST, handleWeeklyNow);
  server.on("/api/train-now", HTTP_POST, handleTrainNow);
  server.on("/api/bursts", HTTP_GET, handleBursts);          // v3
  server.on("/api/bark-learn", HTTP_POST, handleBarkLearn);  // v3
  server.on("/api/bark-label", HTTP_POST, handleBarkLabel);  // v3
  server.on("/api/led-test", HTTP_POST, handleLedTest);      // v2.7.1
  server.on("/meal", HTTP_GET, []() { server.send_P(200, "text/html; charset=utf-8", MEAL_HTML); });   // v2.7.1-food
  server.on("/api/meal", HTTP_GET, handleMealGet);
  server.on("/api/meal", HTTP_POST, handleMealSet);
  server.on("/api/meal-now", HTTP_POST, handleMealNow);
  server.on("/api/meal-stop", HTTP_POST, handleMealStop);
  server.on("/api/meal-cal", HTTP_POST, handleMealCal);
  server.on("/api/clean-start", HTTP_POST, handleCleanStart);   // v2.9.4
  server.on("/api/clean-done", HTTP_POST, handleCleanDone);     // v2.9.4
  setupSelfTest();                                              // v2.9.5: /check + /api/check/*
  setupDiag();                                                  // v2.9.6 help: GET /api/diag
  setupRemote();                                                // v2.9.8: /api/remote, /api/remote-reset + the ntfy poll task
  setupTrain296();                                              // v2.9.6: /api/stop, /api/resume, /api/paid, /api/weight, /api/stage
  server.on("/api/doorbell", HTTP_POST, []() { const char* r = outsideEvent(33, 0); server.send(200, "application/json", String("{\"ok\":true,\"status\":\"") + r + "\"}"); });
  server.begin();
  setupEspNow();                       // works with or without the router (same channel as Wi-Fi)

  pickAloneInterval();
  // start with a calibration so the baseline is right from the first minute
  calibSum = 0; calibN = 0; calibrateUntil = millis() + 3000;
}

void loop() {
  readAudio();          // ~50 ms per window (blocks on the mic)
  dispenseTick();
  trainingTick();
  progressTick();
  // the motor needs a step every ~1.5 ms; readAudio blocks 50 ms, so while moving we step in a tight loop
  while (motorBusy()) { motorTick(); if (cState) ledTick(); if (!motorBusy()) { dispenseTick(); mealTick(); cleanTick(); } yield(); }   // agitate -> turn (~6 s)
  dispenseTick();
  mealTick();            // v2.7.1-food
  cleanTick();           // v2.9.4
  cleanButtonTick();     // v2.9.4
  mealScheduleTick();
  server.handleClient();
  ledTick();
  if (notifyTreatPending && !dispBusy()) { notifyTreatPending = false; sendNtfy(String("🦴 חטיף! היום: ") + sum24(today.treats) + " חטיפים (" + String(treatGToday(), 0) + " ג׳), " + sum24(today.barks) + " נביחות.", "Treat"); }
  train296Tick();        // v2.9.6: fast-treat staging, STOP timer
  stTick();              // v2.9.5 self-test (LED blink, buzzer beeps, IR/PIR watch)
  diagTick();            // v2.9.6 help: watches pins/counters for the diagnostics page (no actions)
  askTick();             // v2.9.7: sends a queued "לא בטוח" question push (own task, never blocks)
  remoteTick();          // v2.9.8: runs accepted remote commands (network in its own task, never blocks)
  if (espNowEvent) { uint8_t s = espNowEvent; espNowEvent = 0; if (!stActive()) outsideEvent(s, espNowDb, s == 7 ? espNowBark : 255); }
  // PIR: rising edge = motion. Ignore the first 60 s (sensor warm-up). Not while the self-test is open (hand-waving test).
  bool pir = digitalRead(PIN_PIR);
  if (pir && !pirPrev && millis() > 60000 && !stActive()) outsideEvent(6, 0);
  pirPrev = pir;
  if (millis() - lastStatsSaveMs > 600000UL) { lastStatsSaveMs = millis(); rollDayIfNeeded(); saveStats(); }
  static uint32_t lastRoll = 0;
  if (millis() - lastRoll > 30000) { lastRoll = millis(); rollDayIfNeeded(); weeklyTick(); }
}
