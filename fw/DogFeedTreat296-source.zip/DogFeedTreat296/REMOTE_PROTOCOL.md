# Feeder remote control — protocol (firmware 2.9.9, rev 3)

Status: FINAL rev 3 (2026-11-10 14:05Z). Firmware 2.9.9 implements exactly this.
History: rev 1/2 = firmware 2.9.8 (commands treat/meal/status/clean_start/clean_done/label, status, pairing, push format §9).
rev 3 (firmware 2.9.9): + command `api` = encrypted tunnel for the WHOLE web page API (§10–§15), + response topic `<rtopic>-r`,
  periodic status every 30 min instead of 5 (ntfy.sh limit: 250 published messages per day per IP, see §15), nonce ring 64 → 256.
  Everything from rev 2 still works unchanged (an app built for rev 2 keeps working).
Transport: ntfy.sh (public, free, no account). Nothing of ours runs a server.

## 1. Secrets & topics (stored in feeder NVS, namespace "remote")
- `rkey`   = 16 random bytes (esp_random), stored as 32 lowercase hex chars. Generated once (first boot with 2.9.8) and on "צור קוד חדש".
- `rtopic` = "dt-" + 16 random chars from [a-z0-9]  (e.g. `dt-k3j9x0a7mq2plz8c`). Separate from the push-notification topic ("dogtreat-…").
- Command topic: `<rtopic>-c`   (app → feeder)
- Status topic:  `<rtopic>-s`   (feeder → app)
- Response topic: `<rtopic>-r`  (feeder → app, answers to `api` commands — rev 3, §12)
- `ron` = remote switch, default OFF. When OFF the feeder neither polls nor publishes.

**HMAC key = the 16 RAW bytes** (hex-decode `rkey`), NOT the 32-char ASCII string.

## 2. Pairing (home Wi-Fi only — these endpoints live on the feeder's local web server)
- `GET  /api/remote` → `{"on":true|false,"topic":"dt-…","key":"<32 hex>","pushTopic":"dogtreat-…","pushOn":true|false,"last":<unix s of last accepted command or 0>,"lastCmd":"<cmd or "">","err":"sig|time|replay|""","poll":<last HTTP code of the feeder's ntfy poll, 0 = never>,"pollAgo":<s since last good poll or -1>,"clock":true|false}`
  `pushTopic` = the existing alert topic (ask.h / "התראות לטלפון"); the app can subscribe to it itself (see §9). `pushOn` = that master switch.
- `POST /api/remote` with form/query `on=1` or `on=0` → same JSON as GET.
- `POST /api/remote-reset` → new rkey + new rtopic (old app pairing stops working) → same JSON as GET.
- QR in Settings ("קוד צימוד") encodes exactly: `{"topic":"dt-…","key":"<32 hex>"}`
- The app may pair automatically: when it reaches the feeder on home Wi-Fi, GET /api/remote and store topic+key (if `on` is false, tell the user to switch on "שליטה מרחוק" in settings, or POST on=1 after asking).

## 3. Sending a command (app)
HTTP `POST https://ntfy.sh/<rtopic>-c`, body = the command JSON as plain text (one line). No ntfy headers needed.
(ntfy wraps it; the feeder reads the ntfy event's `message` field and JSON-parses it.)

Command JSON:
```
{"c":"treat","g":"","t":1762785000,"n":"Zx9Qw8Er7Ty6Ui5O","h":"<64 hex>"}
```
- `c`: one of `treat` | `meal` | `status` | `clean_start` | `clean_done` | `label` | `api` (rev 3, §10)
- `g`: depends on c. **Send it as a JSON string** (recommended) or omit it. The HMAC uses g EXACTLY as sent
  (the string's content; if a JSON number is sent, its literal text, e.g. `25`); absent / null / "" → empty string.
  - `meal`: grams, digits only, 1–4 chars (e.g. `"25"`); empty = the default manual portion (same as the web "ארוחה עכשיו").
    Feeder clamps to 10..600 g exactly like the web settings path, then runs the web meal path (today's treats still come off it).
  - `label`: `"<soundId>:<1|0>"` — soundId = decimal burst id (1–5 digits), 1 = "it was a bark", 0 = "not a bark".
    Runs the same code as `POST /api/bark-label?id=<soundId>&bark=<1|0>` (adds to the "learn my dog" template / "not a bark" examples).
    If the sound is no longer in the feeder's list (it keeps the last 20) → ok:false "הקול הזה כבר לא ברשימה".
  - all other commands: g must be empty/absent, else rejected as "bad".
- `t`: unix seconds (integer, UTC) at send time.
- `n`: nonce, 8–16 chars, ONLY `[A-Za-z0-9_-]` (feeder rejects anything else). Random per command.
- `h`: lowercase hex HMAC-SHA256( key = raw 16 bytes, message = `c + "|" + g + "|" + t + "|" + n` ), UTF-8, no trailing newline. Feeder compares case-insensitively.

## 4. Feeder acceptance rules (in order)
1. ntfy event `event=="message"`, `message` parses as JSON object with string c, n, h and integer t → else reject "bad".
2. `c` in the list, `g` valid for that c (§3) → else "bad".
3. nonce charset/length → else "bad".
4. HMAC matches (constant-time compare) → else "sig".
5. Feeder has NTP time (clock past Nov 2023) → else "time" (no clock = reject everything).
6. |t − now| ≤ 300 s → else "time".
7. nonce not among the last 256 accepted nonces (rev 3; was 64) (RAM ring; also: commands older than the newest accepted t − 300 are already rejected by rule 6) → else "replay".
Rejected commands are NOT executed. Rejections of type sig/time/replay publish a status with `ok:false` (rate-limited to 1 per 30 s) so the app can tell the user; "bad" is silent.

Execution = the SAME internal functions the web buttons call:
- `treat` → the web "חטיף" button path (same rules as that button: refused in "רק מדידה" mode, in cleaning mode, during a meal, or while the motor/another treat is busy). May answer ok:false with the reason.
- `meal` → manual-meal path with its clamps.
- `status` → just publishes status.
- `clean_start` / `clean_done` → cleaning mode on / off, as the web buttons.
- `label` → bark-label path (see g).

After a remote `treat` the feeder sends a SECOND status when the dispense ends: ok:true "החטיף נפל" or ok:false ("לא ראיתי חטיף נופל" / "לא נפל חטיף. אולי נגמרו החטיפים"). After a remote `meal`, a second status when the meal ends (msg = the meal summary line).

## 5. Polling (feeder)
- Every 10 s while ON and STA Wi-Fi is connected (rev 3: every 2 s for 60 s after each accepted `api` command — §14):
  `GET https://ntfy.sh/<rtopic>-c/json?poll=1&since=<last ntfy message id>` (first poll after boot: `since=2m`).
  4 s connect/read timeouts, runs in its own FreeRTOS task (core 0), never blocks meals/treats/bark detection.
  Each response line is one ntfy JSON event; feeder remembers the id of the last event it processed (RAM only).
- Commands are delivered within ~10 s (poll interval). ntfy caches messages ~12 h; old ones fail rule 6 anyway.

## 6. Status (feeder → app)
`POST https://ntfy.sh/<rtopic>-s` body = one line JSON, after every processed command (except `api`, which answers on `-r`) and every 30 min while ON (rev 3; was 5 min):
```
{"v":"2.9.9","t":1762785003,"ok":true,"last":"treat","msg":"חטיף ניתן","food":62,"treats":3,"lastMeal":"07:30","jam":false,"online":true}
```
- `v` firmware version; `t` feeder unix time; `ok` result of the last command (true for periodic reports);
- `last` = command this status answers ("" for a periodic report, "reject" for a rejected command);
- `msg` short Hebrew text for the UI; `food` = food level % or null if unknown; `treats` = treats given today;
- `lastMeal` "HH:MM" local time or "" if none today; `jam` bool; `online` always true.
- Never contains the key or topic.
App reads latest status: `GET https://ntfy.sh/<rtopic>-s/json?poll=1&since=10m` (take the last line), or subscribe with `/json` streaming / `/sse`.
"Feeder offline" heuristic for the app (rev 3): no status AND no `-r` response within the last ~35 min. For a fresh answer send `status` (or an `api` GET /api/status).

## 7. Test vectors (key hex `00112233445566778899aabbccddeeff`, used as raw 16 bytes)
- c=`treat` g=`` t=`1700000000` n=`abcd1234`
  message `treat||1700000000|abcd1234`
  h = `86556d1d7d60d3ae05c23fd0a245f2ec9a047525b658331106a5bcc3d950b063`
- c=`meal` g=`25` t=`1700000060` n=`n0nce-xyz123`
  message `meal|25|1700000060|n0nce-xyz123`
  h = `5baaaa5058ff338f3e348f6a459a3ce8f49213523dd21fc42bd05ee44bd846a0`
- c=`status` g=`` t=`1762785000` n=`Zx9Qw8Er7Ty6Ui5O`
  message `status||1762785000|Zx9Qw8Er7Ty6Ui5O`
  h = `c383518379c0e59330b6c694d575d03348fac985ce6a2d5dcacb08962e41869e`
- c=`clean_start` g=`` t=`1762785100` n=`cs000001`
  message `clean_start||1762785100|cs000001`
  h = `cbcf6f9ba7be0f8f99e26eb4f8c1c3547e2026f7097f6fb499bcbf6e6fe0c7a7`
- c=`clean_done` g=`` t=`1762785200` n=`cd000001`
  message `clean_done||1762785200|cd000001`
  h = `ec1218fe1c68c088cb9bcb20964051cbcb22bbbb1474736746a9205594544e3f`
- c=`label` g=`12:1` t=`1762785300` n=`lb-0001x`
  message `label|12:1|1762785300|lb-0001x`
  h = `f0c11e17922e61d02e4e67a932b3f7b9a10a0b75264ea9362d0264cf6f7d9a05`

Wrong-key trap: using the ASCII hex string as the key for the first vector gives
`3831e448b1824db007001ae1202802a5e1863a4308a4e25a23d1449f9fb996e0` — that is WRONG.

Full example command (vector 2): `{"c":"meal","g":"25","t":1700000060,"n":"n0nce-xyz123","h":"5baaaa5058ff338f3e348f6a459a3ce8f49213523dd21fc42bd05ee44bd846a0"}`

## 8. Security notes
- Anyone who knows the topic can post to it, but without the key they cannot make a valid HMAC; replays are blocked by time window + nonce ring.
- Anyone who knows the status topic can read status (no secrets in it; topic names are random, 16 chars ≈ 82 bits).
- Key leaves the feeder only via GET /api/remote on the local network (and the QR on the local settings page).
- "צור קוד חדש" rotates both key and topic.

## 9. Alert pushes on pushTopic (existing feature, for the app to show alerts itself)
The feeder posts alerts to `https://ntfy.sh/<pushTopic>` (only while "התראות לטלפון" = pushOn is on). The ntfy app keeps working;
the feeder app can subscribe instead: `GET https://ntfy.sh/<pushTopic>/json?poll=1&since=<last id>` (or stream `/json`).
Each line is an ntfy event; use `event=="message"` lines. Fields used:
- `title`: "המתקן שואל" (question), "המתקן שואל (בדיקה)" (test), "Treat", "Meal", "Barking", "DogTreat" (others; English titles are old).
- `message`: Hebrew text (may contain \n). Some alerts have a photo: `attachment.url` (jpg, "dog.jpg").
- `tags`: always contains "dog". A question has tags `["dog","question","sid-<soundId>"]` (sid tag new in 2.9.8).
- `click`: `http://<feeder LAN IP>/#ask` for questions (works on home Wi-Fi only).
- `actions` (questions): two http actions, labels "כן" / "לא", url `http://<feeder IP>/api/bark-label?id=<soundId>&bark=1|0`, method POST.
  The soundId is ALSO in these URLs (`id=` query), for older firmware without the sid tag.
Answering from outside home: send the signed remote command `label` with g `"<soundId>:1"` or `"<soundId>:0"` (needs remote ON).
The test push's actions point to `/api/ask-ping?ans=1|0` and carry no sid tag — not a real question; the app can just show it.


---------------------------------------------------------------------------------------------------
# REV 3 — the `api` tunnel: the whole feeder page works from outside home

## 10. Keys (both derived from the 16 raw key bytes K = hex-decode(rkey))
- Signing: HMAC-SHA256 with K (as in §3).
- Encryption key `kEnc` = first 16 bytes of HMAC-SHA256(K, ASCII `feeder-enc`). For the test key: `38f5db7dd900ab983d034f10a4bb4faa`.
- Cipher: AES-128-CTR, the 16-byte IV is the initial counter block, whole block incremented big-endian
  (= Android/Java `Cipher.getInstance("AES/CTR/NoPadding")` with `IvParameterSpec(iv)`; = OpenSSL `aes-128-ctr`). No padding.
- A fresh random 16-byte IV for EVERY encrypted thing (request, response, file). Never reuse an IV.
- Base64 = standard alphabet (`+` `/`) WITH `=` padding, no line breaks.
Why encrypt: tunnelled answers contain settings (incl. the CallMeBot key, the outdoor-sensor token, the push topic), stats and history,
and requests can carry setting values. ntfy.sh topics are public to anyone who learns the name, so both directions are encrypted and authenticated.

## 11. Request (app → feeder), on `<rtopic>-c`, same envelope as every command
```
{"c":"api","g":"<iv 32 lowercase hex>.<base64(AES-CTR(kEnc, iv, Q))>","t":<unix s>,"n":"<nonce>","h":"<hex HMAC-SHA256(K, "api|" + g + "|" + t + "|" + n)>"}
```
- Signed exactly like every command (§3/§4 rules 1–7 apply in full: HMAC, ±300 s, nonce ring). `g` is signed exactly as its string content.
  (Android `org.json` writes `/` as `\/` — fine, the feeder JSON-unescapes before checking the HMAC.)
- Size: `g` at most 3600 characters (ntfy turns bigger messages into files, which the feeder does not read on `-c`) → Q at most ~2650 bytes.
- Q (plaintext, UTF-8, compact JSON):
```
{"id":"<4–16 chars [A-Za-z0-9_-]>","r":[ <item>, ... ]}          1 to 8 items, answered in order in ONE response
item = {"m":"GET"|"POST","p":"/api/...(path + optional ?query, ≤ 240 chars)","b":"<request body text, optional>","ct":"<request Content-Type, optional>","u":<upload, optional, §13>}
```
  - `b`: the body exactly as the page's fetch() would send it (the page uses `application/x-www-form-urlencoded`; default ct when b is present).
  - Batch: the app SHOULD gather the page's fetch() calls for ~150–300 ms and send them as one `api` command (page start = ~8 GETs → 1 message each way).
  - `id`: random per command; the response carries it.

## 12. Response (feeder → app), ONE ntfy message on `<rtopic>-r` per `api` command
Message body (one line JSON, ASCII):
```
{"id":"<id>","i":0,"n":1,"iv":"<32 hex>","x":"<base64(AES-CTR(kEnc, iv, R))>","m":"<first 16 bytes, hex, of HMAC-SHA256(K, "r|"+id+"|"+i+"|"+n+"|"+iv+"|"+x)>"}
```
- If the sealed answer would not fit in one message (R larger than ~2600 bytes), the feeder sends it as an ntfy FILE instead
  (one message, same JSON but `"x":""` and `"a":<file size in bytes>`); the ntfy event then carries `attachment.url`
  (`https://ntfy.sh/file/<id>.bin`, kept 3 h). The file = `AES-CTR(kEnc, iv, R)` followed by a 32-byte tag
  `HMAC-SHA256(K, "f|" + id + "|" + iv + "|" ‖ ciphertext)` (ASCII prefix then the raw ciphertext bytes). The app: download, check the tag (constant time), decrypt.
- App checks `m` (constant time) BEFORE decrypting; drops anything that fails. `i`/`n`: 2.9.9 always sends i=0 n=1
  (reserved for split answers: if n>1 ever arrives, join the `x` pieces in i order, all pieces share iv, each piece has its own m).
- R (plaintext, UTF-8 JSON):
```
{"id":"<id>","r":[ {"s":<http status>,"ct":"<Content-Type>","b":"<body text>"}                      text answers (json, text/*)
                   | {"s":200,"ct":"image/jpeg","b64":"<base64 body>","name":"cam.jpg"}   binary answers (camera photo)
                   , ... one per request item, same order ] }
```
  `name` appears when the feeder sends a file name (CSV export: `dog-progress.csv`, camera: `cam.jpg`). The app gives `b`/`b64` back to the page
  as the fetch() Response body with status `s` and Content-Type `ct`.
- Errors made by the tunnel itself (all with ct `application/json`, body has `ok:false` + Hebrew `error`, which the page shows):
  - 403 `{"ok":false,"error":"זמין רק בבית","home":true}` — blocked from outside (§13).
  - 404 `{"ok":false,"error":"לא קיים במתקן"}` — path not on the allowlist.
  - 400 bad item; 413 upload too big; 422 upload damaged (tag wrong); 502 `{"ok":false,"error":"המתקן לא הצליח לענות"}` (internal call failed);
  - 429 `{"ok":false,"error":"הגעתי למכסת השליטה מרחוק להיום. מחר זה חוזר, ובבית הכול עובד"}` — daily budget (§15).
- Bad/expired/replayed `api` commands are not answered on `-r`; as in rev 2 a rejected sig/time/replay publishes an ok:false status on `-s` (max 1 per 30 s).

## 13. What works from outside home
Allowlist (exactly the endpoints the feeder's pages call; query strings allowed):
- GET : /api/status /api/stats /api/settings /api/days /api/days.csv /api/weight /api/stage /api/bursts /api/ask /api/diag /api/meal
        /api/check/state /api/check/cam /api/cam.jpg (NEW in 2.9.9, §13a)
- POST: /api/settings /api/treat /api/calibrate /api/ask-test /api/ask-ping /api/play /api/sound (upload only, §13b) /api/sound-del /api/refilled
        /api/weekly-now /api/train-now /api/bark-learn /api/bark-label /api/led-test /api/meal /api/meal-now /api/meal-stop /api/meal-cal
        /api/clean-start /api/clean-done /api/doorbell /api/stop /api/resume /api/paid /api/weight /api/stage
        /api/check/reset /api/check/beep /api/check/led /api/check/motor
- Blocked (403 "זמין רק בבית"): /api/remote, /api/remote-reset (anything starting /api/remote — the key never leaves home),
  /api/reset-wifi (Wi-Fi change would strand the feeder), /api/reset-stats (the "איפוס" button), anything with update/ota in the path
  (the feeder has no web update; updates are by USB from the kit site). Everything else not listed → 404.
- Home-only by nature (not an API call): camera LIVE video (`:81/stream` from the camera itself) and the 3-second camera refresh straight from the camera;
  from outside use /api/cam.jpg (one photo per tap, ~5–10 s). Setup Wi-Fi portal (DogTreat-Setup) and firmware install stay physical.

### 13a. Camera photo — GET /api/cam.jpg (new, also works at home)
The feeder fetches `http://<camHost>/jpg` (the camera address in settings, port 80, 4 s timeouts, ≤ 200 KB) and answers `image/jpeg`;
through the tunnel it comes back as `b64` in a FILE response. 404 `{"ok":false,"error":"אין מצלמה בהגדרות"}` if no camera host; 502 if the camera did not answer.

### 13b. Uploads (the page's "קובץ"/record buttons → POST /api/sound?slot=voice|bell|bark)
1. App encrypts the file bytes F (the same WAV the page would upload): C = AES-CTR(kEnc, ivU, F), tag = HMAC-SHA256(K, "u|" + id + "|" + ivU + "|" ‖ C) (32 bytes).
2. App `PUT https://ntfy.sh/<rtopic>-u` with body C‖tag and header `X-Filename: u.bin` → ntfy answers JSON with `attachment.url`.
3. App sends the `api` command with item `{"m":"POST","p":"/api/sound?slot=bark","u":{"url":"<attachment.url>","len":<len(F)>,"iv":"<ivU hex>","name":"bark.wav","field":"f"}}`.
4. Feeder: url must start with `https://ntfy.sh/file/`; len ≤ 400000 (the page's own limit) else 413; downloads C‖tag (exactly len+32 bytes), decrypts while
   posting it as multipart field `field` (filename `name`) to its own POST handler; the final multipart boundary is only sent after the tag checks out, so a damaged
   file is aborted and the old sound stays (422). Answer = the handler's own answer (`{"ok":true}`).
The whole upload rides inside the signed `api` command (URL, length, IV are covered by the HMAC).

### 13c. Downloads
CSV export (GET /api/days.csv) and the camera photo come back with `name` (`dog-progress.csv`, `cam.jpg`) — inline when the whole answer is ≤ 2600 B, otherwise as a FILE response (§12); the app handles both the same way. The page's `<a href="/api/days.csv" download>` is a link, not a fetch():
the app should intercept that link and save `b` as `dog-progress.csv`.

## 14. Timing (firmware)
- Normal poll every 10 s. After every accepted `api` command: poll every 2 s for the next 60 s (each new api command restarts the 60 s), subject to the request budget below.
- ntfy.sh limits REQUESTS per IP (burst 60, then 1 per 5 s = 12/min sustained; measured: a test polling every 1–2 s got HTTP 429 after ~2 min). The feeder keeps a budget:
  2 s polling only while at least 15 of the 60 tokens are left, otherwise every 5 s (= the refill rate); every poll/publish/download costs 1 token.
  If ntfy.sh answers 429 anyway the feeder waits 30 s between polls for 2 min.
- APP SIDE (important): do NOT poll `-r` with `?poll=1` more often than every ~5 s. While waiting for an answer open ONE streaming request:
  `GET https://ntfy.sh/<rtopic>-r/json` (or `/sse`) — one request delivers every new message instantly. (A stream is a single request for the limiter.)
  Same for `-s` and the alert topic. On HTTP 429 wait 10–30 s and retry; the answer is not lost (ntfy keeps messages ~12 h; use `since=<last id>`).
- All network work runs in the feeder's own background task (core 0). The internal call to its own page handler is a short local
  HTTP request to 127.0.0.1 that the normal web server answers in loop() — exactly like a phone on home Wi-Fi, so treats/meals/bark detection are never blocked
  and no handler runs twice at once.
- Expected latency from the app: ≈ 1–3 s for the poll + ≈ 1–2 s per TLS publish ≈ 2–5 s per request (first request after idle up to ~10 s);
  photo/CSV files ≈ 5–10 s. The app should show a spinner and time out after ~25 s ("המתקן לא ענה").
- Page polling while away: the app should not forward the page's 2–3 s status polls one-by-one. Recommended: GET /api/status at most every 15 s while away
  (and only while the screen is visible), batch everything else (§11).

## 15. ntfy.sh limits (measured from https://ntfy.sh/v1/account, 2026-11-10, anonymous)
- 250 published messages per day per IP (feeder's home IP and the phone's IP each), files ≤ 2 MB each, 20 MB total kept, files expire after 3 h.
  Reading/polling is not a published message (only a request; see §14 for the request limit).
- So the feeder: status every 30 min (48/day) instead of every 5 min (288/day would have hit the limit); one message per `api` answer (no split chunks;
  big answers become one file); at most 150 `api` answers per local day — the 150th answers 429 for every item, later api commands that day get no answer.
  That leaves room for alerts/questions on the same IP.
- `GET /api/remote` (home only) gains `"api":<api answers today>,"fast":true|false`; `/api/diag` "remote" block the same.

## 16. Rev 3 test vectors (K = `00112233445566778899aabbccddeeff`, kEnc = `38f5db7dd900ab983d034f10a4bb4faa`)
A. Request: iv = `000102030405060708090a0b0c0d0e0f`, t = 1762785400, n = `api-0001`
   Q = `{"id":"req1","r":[{"m":"GET","p":"/api/status"},{"m":"POST","p":"/api/treat","b":""}]}`
   g = `000102030405060708090a0b0c0d0e0f.XlLGKbMYz2jKuppLbjD20RVDN7Zmcrq7ILXArqbQNr4nc9VGMQXAKuIoPZzuhUghz7z8myWYjYQauCdU1qXhurQ7bYT/vy9qg7lQjujLTh7l56R+oPE=`
   HMAC message `api|<g>|1762785400|api-0001` → h = `d931645ba9145b8917078974515bd0e05caa662ac2fe8ba9b0012708fce9721c`
   Full command: `{"c":"api","g":"000102030405060708090a0b0c0d0e0f.XlLGKbMYz2jKuppLbjD20RVDN7Zmcrq7ILXArqbQNr4nc9VGMQXAKuIoPZzuhUghz7z8myWYjYQauCdU1qXhurQ7bYT/vy9qg7lQjujLTh7l56R+oPE=","t":1762785400,"n":"api-0001","h":"d931645ba9145b8917078974515bd0e05caa662ac2fe8ba9b0012708fce9721c"}`
B. Response (inline): iv = `0f0e0d0c0b0a09080706050403020100`, id `req1`, i 0, n 1
   R = `{"id":"req1","r":[{"s":200,"ct":"application/json","b":"{\"ok\":true,\"msg\":\"חטיף\"}"}]}` (UTF-8; the Hebrew word is 8 bytes)
   x = `bdygJn9ydDA5HpkFq+su8B0cyjDdim9v51Lkn21ms0hdbRKTQMSZAHXgDAmL5mE92KmpHLIsiLo4B0KS3SaZB3f93F047A0C310fUG2HPTblBlCw5dtXUBDnmZcd3w==`
   m = `bd02d87fbbada11dd53fd63be1fd520b`  (HMAC over `r|req1|0|1|0f0e0d0c0b0a09080706050403020100|<x>`, first 16 bytes)
C. File (download) tag: id `req2`, iv = 16 × `a5`, plaintext `date,barks\n2026-11-10,3\n` (24 bytes)
   ciphertext = `e49b4fdddb8d49485f588b59aa9a5cf53f7e615fa5ed1014`
   tag = `6967538cc0fcaaa83405972d26a45cb4f0fad890b930f2a96664cfe6b779def1`  (HMAC over ASCII `f|req2|a5a5…a5|` then the 24 ciphertext bytes)
D. Upload tag: id `up01`, ivU = 16 × `3c`, plaintext `RIFF1234WAVE` (12 bytes)
   ciphertext = `be968179a1fa22c0fa32d0a7`, tag = `07d1665ceb85278d5a31e9cb89c31746140ffb1b99cea4127e1a50f03a50bcaa`  (prefix `u|up01|3c3c…3c|`)
All four are checked by the host C++ test (test_remote/test_api.cpp) against the firmware's own crypto code.

## 17. Firmware limits & behaviour worth knowing (2.9.9)
- One answer (all items together) is at most 140 KB of plaintext; bigger → every item answers 413 "התשובה גדולה מדי…". Answers > 2600 B are spooled to the feeder's flash (LittleFS temp file, removed right after) — needs ≥ 32 KB free there, else 413 as well.
- Camera photo: JPEG ≤ 96 KB (base64 inside R, so ≤ 128 KB), 4 s camera timeout; refused with 502 "המתקן עסוק…" while a treat/meal/motor is running (same rule as the diag camera probe).
- Upload: ≤ 400000 B (the page's own limit), `url` must start `https://ntfy.sh/file/`, name/field characters `[A-Za-z0-9._-]`; the old sound stays until the tag is verified.
- Commands published BEFORE the feeder booted are never executed (ntfy event `time` < boot): a reboot can't replay a treat from the cache. The app should retry a command that got no answer after ~25 s.
- Order: items of one command run one after another, in order; each internal request has an 8–10 s limit. A long item (e.g. /api/led-test takes 3 s) delays the answer only.
- The whole tunnel runs in the feeder's background task: the same web handlers answer in loop(), exactly as for a phone at home; blocked/unknown paths are never forwarded.
