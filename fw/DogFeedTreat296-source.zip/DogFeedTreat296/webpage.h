#pragma once
// Hebrew RTL web UI, served from flash. ממשק בעברית
// v2.9.6 UI redesign: "kibble label" look (paper / rubber-ink / tennis-ball), Suez One served from flash (/f.woff2), no sliders (steppers),
//   floating pill nav + round STOP. Look only: same IDs, endpoints and settings as the first 2.9.6 build.
//         STOP on every page, food grams, difficulty levels, weight tab, doorbell = good thing. "קרא לו" removed.
const char INDEX_HTML[] PROGMEM = R"HTMLPAGE(
<!DOCTYPE html>
<html lang="he" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>מתקן החטיפים</title>
<meta name="theme-color" content="#1F3B2D">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Crect x='8' y='8' width='184' height='184' rx='56' fill='%23F4A988'/%3E%3Cg fill='%231F3B2D'%3E%3Cellipse cx='100' cy='122' rx='36' ry='30'/%3E%3Cellipse cx='58' cy='84' rx='14' ry='18'/%3E%3Cellipse cx='84' cy='60' rx='14' ry='19'/%3E%3Cellipse cx='116' cy='60' rx='14' ry='19'/%3E%3Cellipse cx='142' cy='84' rx='14' ry='18'/%3E%3C/g%3E%3C/svg%3E">
<style>
@font-face{font-family:Suez;src:url(/f.woff2) format("woff2");font-display:swap}
:root{--paper:#F3F1EA;--card:#FBFAF5;--ink:#1F3B2D;--ink2:#2E4A3B;--mut:#4E5F55;--line:#DDD8CA;--soft:#E9E6DB;--ball:#F4A988;--ballD:#EC9470;--peachT:#FBE0D2;--olive:#3E6B52;--bark:#3F5A78;--barkbg:#E1E7EE;--ok:#2D6A43;--bad:#3F5A78;--okbg:#E2EBDF;--stop:#D7263D;--stopD:#A8172B;--warn:#F6C85F;--fsoft:#D6DED8;--fmut:#C9D3CB;--ftrack:#36533F;--disp:Suez,"Arial Hebrew","Noto Sans Hebrew",system-ui,sans-serif}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI","Noto Sans Hebrew","Arial Hebrew",Arial,sans-serif;background:var(--paper);color:var(--ink);font-size:16px;line-height:1.5;padding-bottom:calc(112px + env(safe-area-inset-bottom))}
p,li{text-wrap:pretty}a{color:inherit}
h1,h2,.d{font-family:var(--disp);font-weight:400;letter-spacing:0}
h2{font-size:25px;line-height:1.15;margin:0 0 10px}
h3{font-size:16px;font-weight:700;margin:22px 0 6px;padding-top:14px;border-top:1px solid var(--line)}
.mut{color:var(--mut);font-size:14.5px}.num{font-variant-numeric:tabular-nums}.ltr{direction:ltr;unicode-bidi:isolate}
main{max-width:640px;margin:auto}
.card{padding:22px 18px 24px;border-top:1px solid var(--line)}
.card:first-child{border-top:0}
.big{font-family:var(--disp);font-size:46px;line-height:1;font-variant-numeric:tabular-nums}
.row{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:10px 0}
button,.btn,label.btn{-webkit-tap-highlight-color:transparent;transition:transform .12s ease-out,background-color .12s,box-shadow .12s;cursor:pointer}
button:active,.btn:active{transform:scale(.96)}
.btn{display:inline-flex;align-items:center;justify-content:center;min-height:44px;border:2px solid var(--ink);background:var(--card);color:var(--ink);border-radius:18px;padding:8px 14px;font:inherit;font-size:15px;font-weight:700;text-decoration:none}
.btn:active{background:var(--soft)}.btn.dark{background:var(--ink);color:#fff}.btn.dark:active{background:#142A1F}
.btn.rec{background:var(--bark);border-color:var(--bark);color:#fff}
.stp{display:flex;align-items:center;gap:6px;flex:none}
.stp button{width:48px;height:48px;border:2px solid var(--ink);background:var(--card);color:var(--ink);border-radius:50%;font:inherit;font-size:26px;font-weight:700;line-height:1;padding:0}
.stp button:active{background:var(--ball)}
.stp input[type=number]{width:84px;height:52px;border:0;border-bottom:3px dotted var(--ink2);border-radius:14px 14px 0 0;background:none;text-align:center;font-family:var(--disp);font-size:34px;color:var(--ink);padding:0;-moz-appearance:textfield}
.stp input::-webkit-inner-spin-button,.stp input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}
.stp input[type=number]:focus{outline:0;border-bottom-color:var(--ink);background:var(--ball)}
.unit{font-size:14px;color:var(--mut);font-weight:600;min-width:1.2em}
.sw{position:relative;width:30px;height:30px;flex:none;display:inline-block}.sw input{position:absolute;opacity:0;width:0;height:0}
.sw span{position:absolute;inset:0;border:2px solid var(--ink);border-radius:10px;background:var(--card);transition:background-color .15s}
.sw span:before{content:"";position:absolute;width:7px;height:14px;left:9px;top:3px;border:solid var(--ball);border-width:0 3px 3px 0;transform:rotate(45deg) scale(0);transition:transform .15s}
.sw input:checked+span{background:var(--ink)}.sw input:checked+span:before{transform:rotate(45deg) scale(1)}
.sw input:focus-visible+span{outline:3px solid var(--ballD);outline-offset:2px}
input[type=number],input[type=text],input[type=date],input[type=time],select{width:96px;min-height:44px;padding:6px 8px;border:0;border-bottom:2px solid var(--ink2);border-radius:12px 12px 4px 4px;background:var(--soft);font:inherit;font-size:17px;font-weight:600;text-align:center;color:var(--ink);font-variant-numeric:tabular-nums}
input[type=text]{width:160px;direction:ltr}input[type=time]{width:150px}input[type=date]{width:160px}select{width:auto;text-align:start}
input:focus,select:focus{outline:0;border-bottom-color:var(--ink);background:var(--peachT)}
.pill{display:inline-block;padding:4px 12px;border-radius:999px;font-size:14.5px;font-weight:600;background:var(--soft)}
.pill.ok{background:var(--okbg);color:#1E4D30}.pill.bad{background:var(--barkbg);color:#2C4560}
.banner{padding:16px 18px;font-weight:700;font-size:17px;margin:12px 12px 0;border-radius:22px}
.banner.bad{background:var(--stop);color:#fff}.banner.warn{background:var(--warn);color:var(--ink)}
.banner .btn{margin-top:10px;border-color:currentColor;background:transparent;color:inherit}
#toast{position:fixed;top:calc(12px + env(safe-area-inset-top));left:50%;transform:translateX(-50%);background:var(--ink);color:#fff;padding:12px 20px;border-radius:22px;display:none;z-index:40;max-width:90vw;width:max-content;text-align:center;font-weight:600;box-shadow:0 10px 30px rgba(31,59,45,.28)}
nav.dock{position:fixed;left:12px;right:12px;bottom:calc(14px + env(safe-area-inset-bottom));z-index:30;display:flex;align-items:center;gap:10px;max-width:616px;margin:auto}
.bar{flex:1;display:flex;gap:2px;padding:5px;border-radius:999px;background:rgba(31,59,45,.96);border:1px solid rgba(243,241,234,.14);box-shadow:0 10px 28px rgba(31,59,45,.2),0 1px 2px rgba(31,59,45,.1)}
@supports ((-webkit-backdrop-filter:blur(1px)) or (backdrop-filter:blur(1px))){.bar{background:rgba(31,59,45,.8);-webkit-backdrop-filter:blur(18px) saturate(1.7);backdrop-filter:blur(18px) saturate(1.7)}}
.bar .tb,.bar a{flex:1;min-height:46px;border:0;border-radius:999px;background:none;color:var(--ink2);font:inherit;font-size:15px;font-weight:600;padding:0 4px;display:flex;align-items:center;justify-content:center;text-decoration:none;white-space:nowrap;color:#EEF0EA}
.bar .tb.on,.bar a.on{background:var(--ball);color:var(--ink);font-weight:800}
.stop{flex:none;width:66px;height:66px;border-radius:50%;border:3px solid #fff;background:var(--stop);color:#fff;font:inherit;font-size:16px;font-weight:800;letter-spacing:.02em;box-shadow:0 6px 18px rgba(20,30,25,.32),0 0 0 1px rgba(31,59,45,.12)}
.stop:active{background:var(--stopD);transform:scale(.92)}
footer{text-align:center;color:var(--mut);font-size:13px;padding:16px 18px}

.face{background:var(--ink);color:#fff;padding:18px 20px 24px;margin:12px 12px 0;border-radius:22px}
.face .top{display:flex;justify-content:space-between;align-items:baseline;gap:10px;flex-wrap:wrap}
.brand{font-family:var(--disp);font-size:22px;line-height:1.2}
#sub{color:var(--fmut);font-size:13px}.logo{display:inline-flex;vertical-align:-6px;margin-inline-end:8px}.logo svg{width:30px;height:30px;display:block}
.links{display:flex;gap:18px;margin-top:6px}.links a{color:#fff;font-size:14.5px;font-weight:600;text-decoration:underline;text-decoration-color:var(--ball);text-decoration-thickness:2px;text-underline-offset:5px;padding:6px 0}
.hero{display:flex;align-items:flex-end;gap:14px;margin-top:24px}
#leftG{font-family:var(--disp);font-size:100px;line-height:.82;color:#FBFAF5;font-variant-numeric:tabular-nums}
.hero .lbl{font-size:16px;color:#EEF0EA;padding-bottom:4px;line-height:1.3}
.food{display:flex;height:14px;background:var(--ftrack);margin:20px 0 8px;border-radius:999px;overflow:hidden;direction:rtl}
.food i{display:block;height:100%}#fbM{background:var(--paper)}#fbT{background:var(--ball)}
.split{display:flex;justify-content:space-between;font-size:14px;color:var(--fsoft)}.split b{color:#fff;font-weight:700}
.key{display:inline-block;width:10px;height:10px;border-radius:50%;margin-inline-end:6px;vertical-align:-1px}
#nextMeal{color:var(--fsoft);font-size:14.5px;margin:10px 0 0}
.treat{display:block;width:100%;min-height:76px;border:0;border-radius:22px;background:var(--ball);color:var(--ink);font-family:var(--disp);font-size:31px;line-height:1.1;padding:10px 16px;box-shadow:inset 0 -5px 0 rgba(31,59,45,.16)}
.treat:active{background:var(--ballD);box-shadow:inset 0 -2px 0 rgba(31,59,45,.16)}.treat:disabled{opacity:.45}
.treat.sm{min-height:56px;font-size:22px;border-radius:18px;margin:6px 0}
.treatSec{padding-top:18px}
.pw{display:flex;align-items:center;gap:12px;font-size:19px;min-height:44px;cursor:pointer}
.pw input{position:absolute;opacity:0;width:0;height:0}
.pw .box{position:relative;width:30px;height:30px;flex:none;border:2px solid var(--ink);border-radius:10px;background:var(--card)}
.pw .box:before{content:"";position:absolute;width:7px;height:14px;left:9px;top:3px;border:solid var(--ball);border-width:0 3px 3px 0;transform:rotate(45deg) scale(0);transition:transform .15s}
.pw input:checked~.box{background:var(--ink)}.pw input:checked~.box:before{transform:rotate(45deg) scale(1)}
.pw input:focus-visible~.box{outline:3px solid var(--ballD);outline-offset:2px}
.pw input:checked~.off1,.pw input:not(:checked)~.on1{display:none}.pw .off1{color:var(--bark)}
.modes{margin:14px 0 8px;border-top:2px solid var(--ink)}.modes button.on{background:var(--peachT);border-radius:16px;padding-inline:10px}
.modes button{display:flex;align-items:center;gap:14px;width:100%;min-height:56px;padding:10px 2px;border:0;border-bottom:1px solid var(--line);background:none;color:var(--ink2);font:inherit;font-size:19px;font-weight:600;text-align:start}
.modes button:before{content:"";flex:none;width:24px;height:24px;border-radius:50%;border:2px solid var(--ink);background:var(--card);box-sizing:border-box}
.modes button.on{color:var(--ink);font-weight:800}
.modes button.on:before{background:var(--ball);box-shadow:inset 0 0 0 3px var(--card),inset 0 0 0 12px var(--ball)}
.seg{display:flex;gap:8px;flex-wrap:wrap;margin:6px 0}
.seg button{border:0;background:none;border-radius:999px;padding:6px 14px;min-height:44px;font:inherit;font-size:18px;font-weight:600;color:var(--mut)}
.seg button.on{color:var(--ink);font-weight:800;background:var(--ball)}
.lv{display:grid;grid-template-columns:1fr 48px 64px 48px;align-items:center;gap:12px 8px;margin-top:12px}
.lv>span{font-size:17px;font-weight:700;line-height:1.25}.lv>span .mut{display:block;font-weight:400;font-size:13.5px}
.lv .btn{width:48px;height:48px;padding:0;font-size:24px;border-radius:50%}
.lv input{width:64px;height:50px;border:0;border-bottom:3px dotted var(--ink2);background:none;font-family:var(--disp);font-size:32px;font-weight:400;padding:0;-moz-appearance:textfield}
.lv input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
#barkStat{font-family:var(--disp);font-size:24px;line-height:1.25}
.meter{position:relative;height:26px;background:var(--soft);overflow:hidden;direction:ltr;border-radius:999px;margin:10px 0 6px}
.meter .fill{position:absolute;top:0;bottom:0;left:0;background:var(--ink)}
.meter .mark{position:absolute;top:0;bottom:0;width:3px;background:var(--olive)}#mB{background:var(--bark)}
.trio{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:6px 0 4px}.trio .mut{font-size:14px}
canvas{width:100%;height:160px;display:block;margin:10px 0 6px}
.legend{font-size:13px;color:var(--mut)}.legend i{display:inline-block;width:16px;height:6px;border-radius:999px;margin:0 4px 0 10px;vertical-align:middle}
details>summary{list-style:none;cursor:pointer}details>summary::-webkit-details-marker{display:none}
.card>details>summary{display:flex;justify-content:space-between;align-items:center;min-height:48px;font-family:var(--disp);font-size:25px}
.card>details>summary:after{content:"+";font-family:system-ui,sans-serif;font-size:30px;font-weight:300;line-height:1}
.card>details[open]>summary:after{content:"−"}
summary.mut{text-decoration:underline;text-underline-offset:4px;padding:8px 0}.card details>summary.mut{font-family:inherit;font-size:14.5px;min-height:44px;justify-content:flex-start;gap:8px}.card details>summary.mut:after{font-size:18px}
.log{font-size:14px;max-height:300px;overflow:auto}.log div{padding:7px 0;border-bottom:1px solid var(--line)}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-inline-end:7px;background:#B9C2B5;vertical-align:0}
.dot.b{background:var(--bark)}.dot.t{background:var(--ok)}.dot.a{background:var(--olive)}
.page{display:none}.page.on{display:block}
.face.v .verdict{font-family:var(--disp);font-size:34px;line-height:1.15;margin:6px 0 4px}
.face.v h2{font-family:system-ui,sans-serif;font-size:15px;font-weight:600;color:var(--fmut);margin:0}
.face.v .mut{color:var(--fsoft)}
.kpi{display:grid;grid-template-columns:1fr 1fr;border-top:2px solid var(--ink);margin-top:8px}
.kpi div{padding:12px 0 14px;font-size:14px;color:var(--mut);border-bottom:1px solid var(--line)}
.kpi div:nth-child(odd){padding-inline-end:12px;border-inline-end:1px solid var(--line)}.kpi div:nth-child(even){padding-inline-start:14px}
.kpi b{display:block;font-family:var(--disp);font-weight:400;font-size:36px;color:var(--ink);line-height:1.1}
table.t{width:100%;border-collapse:collapse;font-size:15px}table.t th,table.t td{padding:9px 4px;border-bottom:1px solid var(--line);text-align:start}
table.t th{color:var(--mut);font-weight:600;font-size:13px;border-bottom:2px solid var(--ink)}
table.t .btn{min-height:36px;padding:4px 12px;font-size:13.5px;border-radius:999px}
.bv{border-top:1px solid var(--line);padding:10px 0;font-size:14px}.bv .row{margin:2px 0}.bv details{font-size:12px;color:var(--mut);direction:ltr;text-align:left}
.vb{color:var(--bark);font-weight:700}.vn{color:var(--ok);font-weight:700}.vm{color:#8A5A00;font-weight:700}
.wface{display:flex;justify-content:space-between;align-items:flex-end}
#wNow{font-family:var(--disp);font-size:88px;line-height:.85;color:#FBFAF5}#wSub{color:var(--fsoft)}
#wTarget{font-family:var(--disp);font-size:34px;color:#fff;text-align:left}.wface .mut{color:var(--fsoft);text-align:left}
#camImg{width:100%;background:var(--ink);min-height:120px;display:block;border-radius:22px}
@keyframes shk{0%,100%{transform:none}20%,60%{transform:translateX(-7px)}40%,80%{transform:translateX(7px)}}.shk{animation:shk .36s;border-bottom-color:var(--stop)!important}
.mh{font-size:15.5px;color:var(--ink2);margin:10px 0 4px;padding-inline-start:12px;border-inline-start:4px solid var(--ball)}
.diff{margin:6px 0 10px}.cmp{font-size:13px;line-height:1.35;margin-top:6px}.cmp th,.cmp td{padding:7px 3px;vertical-align:top}.cmp td:first-child{font-weight:700;width:18%}

/* v2.9.6 help: instructions + "what is not working" pages, status badge, button spinner */
.hbadge{display:flex;align-items:center;gap:10px;width:100%;margin-top:14px;min-height:48px;padding:8px 16px;border-radius:18px;border:2px solid rgba(243,241,234,.5);background:transparent;color:#fff;font:inherit;font-size:16px;font-weight:700;text-align:start;cursor:pointer}
.hbadge i{width:12px;height:12px;border-radius:50%;background:var(--ball);flex:none}
.hbadge small{margin-inline-start:auto;font-size:13.5px;font-weight:600;color:var(--fsoft)}
.hbadge.bad{background:var(--warn);border-color:var(--warn);color:var(--ink)}
.hbadge.bad i{background:var(--ink)}.hbadge.bad small{color:var(--ink)}
.pgtop{display:flex;justify-content:space-between;gap:10px}
.back{min-height:44px;padding:6px 14px;border-radius:999px;border:2px solid rgba(243,241,234,.5);background:transparent;color:#fff;font:inherit;font-size:15px;font-weight:700;cursor:pointer}
.face .hb2{margin-top:12px;background:var(--ball);border-color:var(--ball);color:var(--ink)}
.help details{border-top:1px solid var(--line)}.help details:first-of-type{border-top:0}
.help .card>details>summary,.help>details>summary{font-size:21px}
ol.how{list-style:none;counter-reset:h;padding:0;margin:6px 0 14px}
ol.how>li{counter-increment:h;position:relative;padding:7px 42px 7px 0;min-height:30px}
ol.how>li:before{content:counter(h);position:absolute;right:0;top:5px;width:30px;height:30px;border-radius:50%;background:var(--ball);color:var(--ink);font-weight:800;font-size:15px;display:flex;align-items:center;justify-content:center}
.tip{background:var(--peachT);border-radius:16px;padding:12px 14px;margin:6px 0 14px;font-size:15px}
.qr{display:block;margin:6px auto 10px;background:#fff;border-radius:16px;border:2px solid var(--ink);width:205px!important;height:205px!important;max-width:none;image-rendering:pixelated}.topic .rmc{font-size:13px;font-weight:700;flex:1 1 100%;min-width:0;word-break:break-all;overflow-wrap:anywhere;white-space:normal;font-family:ui-monospace,monospace}
.tip b{display:block}
.ltr{direction:ltr;unicode-bidi:isolate;white-space:nowrap;font-family:ui-monospace,Menlo,monospace;font-size:.95em}
.dg{background:var(--card);border:1px solid var(--line);border-radius:22px;padding:16px 16px 6px;margin:12px}
.dg h3{border:0;margin:8px 0 6px;padding:0;font-size:18px}
.chip{display:inline-block;padding:3px 12px;border-radius:999px;font-size:13.5px;font-weight:700;background:var(--soft);color:var(--ink)}
.dg.bad .chip{background:var(--warn)}.dg.warn .chip{background:var(--peachT)}
.dg .why{margin:4px 0 8px}.dg .why b{font-weight:700}
.dg .btn{margin:0 0 12px}
.okl{list-style:none;padding:0;margin:0}.okl li{position:relative;padding:8px 22px 8px 0;border-bottom:1px solid var(--line)}
.okl li:before{content:"";position:absolute;right:2px;top:17px;width:10px;height:10px;border-radius:50%;background:var(--ok)}
.okl li.i:before{background:var(--mut)}
.okl li:last-child{border-bottom:0}
button.wait{position:relative;color:transparent!important;pointer-events:none}
button.wait:after{content:"";position:absolute;inset:0;margin:auto;width:20px;height:20px;border-radius:50%;border:3px solid var(--ink);border-top-color:transparent;animation:spn .7s linear infinite}
.btn.dark.wait:after{border-color:#fff;border-top-color:transparent}
button.okd{animation:pop .4s ease}button.nod{animation:shk .4s}
@keyframes spn{to{transform:rotate(1turn)}}@keyframes pop{50%{transform:scale(1.06)}}

/* v2.9.7: "כשהוא לא בטוח" — question card + header badge + phone notifications */
.qbadge{display:flex;align-items:center;gap:10px;width:100%;margin-top:10px;min-height:48px;padding:8px 16px;border-radius:18px;border:2px solid var(--ball);background:var(--ball);color:var(--ink);font:inherit;font-size:16px;font-weight:700;text-align:start;cursor:pointer}
.qbadge i{font-style:normal;width:26px;height:26px;border-radius:50%;background:var(--ink);color:var(--ball);display:flex;align-items:center;justify-content:center;font-family:var(--disp);font-size:17px;flex:none;animation:qp 1.6s ease-in-out infinite}
.qbadge small{margin-inline-start:auto;font-size:13.5px;font-weight:600}
@keyframes qp{50%{box-shadow:0 0 0 6px rgba(31,59,45,.18)}}
@media (prefers-reduced-motion:reduce){.qbadge i{animation:none}}
.card.ask{margin:12px 12px 0;border:2px solid var(--ball);background:var(--peachT);border-radius:22px;padding:18px 18px 16px;scroll-margin-top:12px}
.card.ask h2{margin:0 0 4px}
.card.ask .mut{color:#3F4E45}
.askB{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:14px 0 8px}
.askB .btn{min-height:58px;font-size:21px;border-radius:20px}
.lnk{background:none;border:0;padding:0;font:inherit;font-weight:700;color:var(--ink);text-decoration:underline;cursor:pointer}
.topic{display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:var(--peachT);border-radius:16px;padding:10px 14px;margin:8px 0}
.qbadge[hidden],.card.ask[hidden]{display:none}
.topic b{font-size:17px;word-break:break-all;flex:1 1 160px}
</style></head><body>

<main>
<div class="banner bad" id="stopBox" style="display:none">הכול עצור. חטיפים אוטומטיים, אימון וארוחות ממתינים עוד <span id="stopLeft"></span>.<br><button class="btn" onclick="post('/api/resume').then(()=>toast('ממשיכים'))">המשך עכשיו</button></div>
<div class="banner bad" id="payBox" style="display:none">הקליק לא שולם: החטיף לא נפל. תן לה חטיף ביד עכשיו, ואז בדוק את גלגל החטיפים.<br><button class="btn" onclick="post('/api/paid').then(()=>toast('תודה'))">נתתי ביד</button></div>
<div class="banner warn" id="cleanBox" style="display:none">מצב ניקוי פעיל: אין ארוחות ואין חטיפים. <span id="cleanTxt"></span><br><button class="btn" onclick="post('/api/clean-done').then(()=>toast('חזרנו לעבודה'))">סיימתי לנקות</button></div>
<div class="banner warn" id="emptyBox" style="display:none">נראה שנגמרו החטיפים (או שהגלגל תקוע). מלא את המיכל ואז:<br><button class="btn" onclick="post('/api/refilled').then(()=>toast('מעולה'))">מילאתי</button></div>

<div class="page on" id="pg0">
<header class="face">
 <div class="top"><span class="brand"><span class="logo"><svg viewBox="0 0 200 200" aria-hidden="true"><rect x="8" y="8" width="184" height="184" rx="56" fill="#F4A988"/><g fill="#1F3B2D"><ellipse cx="100" cy="122" rx="36" ry="30"/><ellipse cx="58" cy="84" rx="14" ry="18"/><ellipse cx="84" cy="60" rx="14" ry="19"/><ellipse cx="116" cy="60" rx="14" ry="19"/><ellipse cx="142" cy="84" rx="14" ry="18"/></g></svg></span>מתקן החטיפים</span><span id="sub">מתחבר…</span></div>
 <div class="links"><a href="/meal">ארוחות וכיול</a><a href="/check">בדיקת חיבורים</a><a href="#help" onclick="tab(4);return false">הוראות</a></div>
 <button class="hbadge" id="hBadge" onclick="tab(5)"><i></i><span id="hBadgeT">בודק את החלקים…</span><small id="hBadgeS">בדיקת מצב</small></button>
 <button class="qbadge" id="qBadge" hidden onclick="askGo()"><i>?</i><span id="qBadgeT">שאלה מחכה לך</span><small>לענות</small></button>
 <div class="hero"><div id="leftG">--</div><div class="lbl">גרם נשארו היום<br>מתוך <span id="foodG" class="num"></span> ג׳</div></div>
 <div class="food" id="foodBar"><i id="fbM"></i><i id="fbT"></i></div>
 <div class="split"><span><i class="key" style="background:var(--paper)"></i>ארוחות · <i class="key" style="background:var(--ball)"></i>חטיפים</span><b class="num" id="foodSplit"></b></div>
 <p id="nextMeal"></p>
</header>
<section class="card ask" id="askCard" hidden>
  <h2>שמעתי משהו — זו הייתה נביחה?</h2>
  <p class="mut" id="askInfo"></p>
  <div class="askB"><button class="btn dark" id="askYes" onclick="askAns(1)">כן</button><button class="btn" id="askNo" onclick="askAns(0)">לא</button></div>
  <p class="mut" style="margin:0">התשובה מלמדת אותו. היא לא נותנת חטיף עכשיו. <button class="lnk" onclick="askSkip()">לא יודע</button> · <a href="#help" onclick="helpAt('hAsk');return false">למה הוא שואל?</a></p>
</section>
<section class="card treatSec">
  <button class="treat" id="treatBtn" onclick="treat()">זרוק חטיף</button>
  <p class="mut" id="treatWarn" style="margin:6px 0 0"></p>
  <div class="row"><span class="mut" id="fastStat"></span><button class="btn" onclick="playV()">השמע את הקול שלך</button></div>
  <div class="row" id="doorRow"><span class="mut">צלצלו בדלת עכשיו? לחץ, ואם היא תישאר שקטה היא תקבל חטיף.</span><button class="btn dark" onclick="door()">צלצלו</button></div>
  <p class="mut" id="dropStat"></p>
</section>
<section class="card">
  <h2>מצב</h2>
  <label class="pw"><input type="checkbox" id="enabled" onchange="setv('enabled',this.checked?1:0)"><span class="box"></span><b class="on1">המתקן פועל</b><b class="off1">המתקן כבוי, לחץ להפעלה</b></label>
  <div class="modes"><button id="m0" onclick="setv('mode',0)">בית</button><button id="m1" onclick="setv('mode',1)">לבד</button><button id="m3" onclick="setv('mode',3)">אימון לרעשים</button><button id="m4" onclick="setv('mode',4)">פעמון = דבר טוב</button><button id="m2" onclick="setv('mode',2)">רק מדידה</button></div>
  <p id="modeHelp" class="mh"></p>
  <details class="diff"><summary class="mut">מה ההבדל בין המצבים?</summary>
  <table class="t cmp"><tr><th>מצב</th><th>מתי</th><th>חטיף לבד?</th><th>נביחה</th><th>מה נרשם</th></tr>
  <tr><td>בית</td><td>כשאתם בבית</td><td>כן, אחרי רעש או משהו בחוץ ואז שקט</td><td>אין חטיף, ומחכים לשקט</td><td>נביחות, רעשים, אירועים בחוץ, חטיפים</td></tr>
  <tr><td>לבד</td><td>כשאין אף אחד בבית</td><td>כן, אחרי זמן שקט אקראי (וגם אחרי משהו בחוץ ואז שקט)</td><td>הספירה מתחילה מחדש</td><td>נביחות, רעשים, ניסיונות לבד, חטיפים</td></tr>
  <tr><td>רק מדידה</td><td>שבוע ראשון, להשוואה</td><td>לא, גם לא ידני</td><td>רק נספרת</td><td>נביחות, רעשים, אירועים בחוץ</td></tr>
  <tr><td>אימון לרעשים</td><td>אחרי שלב הפעמון</td><td>כן, אחרי צליל מהרמקול ואז שקט</td><td>אין חטיף, והפסקה</td><td>ניסיונות, הצלחות, עוצמה</td></tr>
  <tr><td>פעמון = דבר טוב</td><td>שלב ראשון מול הפעמון</td><td>כן, אחרי צלצול חלש ואז שקט</td><td>אין חטיף, והצלצול הבא שקט יותר</td><td>ניסיונות, הצלחות, עוצמה</td></tr></table>
  <p class="mut">בכל המצבים: הארוחות לפי השעון ממשיכות, חטיף מהיר עובד, ו-STOP עוצר הכול. כפתור "זרוק חטיף" עובד בכל מצב חוץ מרק מדידה. אימון לרעשים ופעמון = דבר טוב צריכים רמקול.</p>
  </details>
  <div id="state"></div>
</section>


<section class="card">
  <div class="row"><h2 style="margin:0">רמת קושי</h2><label class="row" style="margin:0;gap:8px"><span class="mut">אוטומטי</span><span class="sw"><input type="checkbox" id="autoDiff" onchange="setv('autoDiff',this.checked?1:0)"><span></span></span></label></div>
  <p class="mut" style="margin:4px 0">8–10 הצלחות מתוך 10 = רמה למעלה. חצי או פחות = רמה למטה. רמה גבוהה = צריך יותר שקט לכל חטיף (בלבד: מרווח ארוך יותר).</p>
  <div class="lv" id="lvBox"></div>
  <p class="mut" id="diffMsg"></p>
</section>
<section class="card"><h2>נביחות</h2><div id="barkStat">--</div><p class="mut" id="outStat"></p></section>
<section class="card" id="bmCard"><h2>זיהוי נביחות</h2>
  <p class="mut">המתקן בודק את <b>צורת</b> הקול (תדרים, חדות, אורך, חזרתיות), לא רק כמה הוא חזק. רעש = יכול לקבל חטיף אם היא שקטה. "לא בטוח" = אף פעם לא חטיף, והוא שואל אותך.</p>
  <div class="seg" style="margin:8px 0"><button id="bs0" onclick="setv('barkSens',0)">קפדני</button><button id="bs1" onclick="setv('barkSens',1)">רגיל</button><button id="bs2" onclick="setv('barkSens',2)">רגיש</button></div>
  <p class="mut" id="bsHelp"></p>
  <p id="bmStat" class="mut"></p>
  <div class="row"><button class="btn rec" id="learnBtn" onclick="learn()">הקלט נביחה</button><span class="mut" id="learnStat"></span></div>
  <p class="mut">איך: לחץ, וגרום לה לנבוח 3–10 פעמים בתוך 30 שניות (דפיקה בדלת, פעמון). לחץ שוב כדי לסיים מוקדם.</p>
  <p class="mut">ככל שתקליט ותסמן יותר ("זה לא היה נביחה" / "זו כן נביחה" למטה), הזיהוי משתפר. הוא לא לומד לבד. <a href="#help" onclick="tab(4);$('hLearn').open=true;$('hLearn').scrollIntoView();return false">איך?</a></p>
  <h3>קולות אחרונים</h3>
  <div id="bursts" class="mut">אין עדיין</div>
  <details style="margin-top:8px"><summary class="mut">איפוס כיול</summary>
   <div class="row"><button class="btn" onclick="bml('reset-template')">מחק את הנביחה שהוקלטה</button><button class="btn" onclick="bml('reset-neg')">מחק דוגמאות "לא נביחה"</button></div></details>
</section>
<section class="card" id="camCard" style="display:none"><h2>מצלמה</h2>
  <img id="camImg" alt="תמונה מהמצלמה" onerror="camErr()" onload="camOk()">
  <div class="row"><button class="btn" id="liveBtn" onclick="toggleLive()">שידור חי</button><span class="mut" id="camNote">תמונה מתעדכנת כל 3 שניות</span></div></section>
<section class="card">
  <h2>עוצמת קול עכשיו</h2>
  <div class="row"><span class="big num ltr" id="lvl">--</span><span class="mut" id="base"></span></div>
  <div class="meter"><div class="fill" id="fill"></div><div class="mark" id="mN"></div><div class="mark" id="mB"></div></div>
  <p class="mut">קו ראשון = סף "רעש", קו שני = סף "נביחה" (מעל רעש הרקע)</p>
  <button class="btn" onclick="calib()">כיול (5 שניות שקט)</button>
</section>
<section class="card">
  <h2>היום</h2>
  <div class="trio"><div><div class="big num" id="tT">0</div><div class="mut">חטיפים</div></div>
  <div><div class="big num" id="tB">0</div><div class="mut">נביחות</div></div>
  <div><div class="big num" id="tG">0</div><div class="mut">גרם חטיפים</div></div></div>
  <canvas id="ch" width="520" height="160"></canvas>
  <div class="legend"><i style="background:#3F5A78"></i>נביחות<i style="background:#2D6A43"></i>חטיפים · לפי שעה</div>
  <h3>ימים קודמים</h3><div id="hist" class="mut">אין עדיין</div>
</section>
<section class="card"><details><summary>הגדרות</summary>
  <h3>אוכל</h3>
  <div class="row"><label for="dailyFoodG">אוכל ליום (גרם, ארוחות + חטיפים)</label><div class="stp"><button type="button" onclick="stp('dailyFoodG',-1)" aria-label="פחות">−</button><input type="number" inputmode="numeric" id="dailyFoodG" min="0" max="2000" step="10"><button type="button" onclick="stp('dailyFoodG',1)" aria-label="יותר">+</button><span class="unit">ג׳</span></div></div>
  <div class="row"><label>להוריד את גרמי החטיפים מהארוחה הבאה</label><label class="sw"><input type="checkbox" id="treatFromMeal"><span></span></label></div>
  <div class="row"><label for="mealFloorPct">ארוחה לא יורדת מתחת ל- (% מהארוחה)</label><div class="stp"><button type="button" onclick="stp('mealFloorPct',-1)" aria-label="פחות">−</button><input type="number" inputmode="numeric" id="mealFloorPct" min="0" max="100" step="5"><button type="button" onclick="stp('mealFloorPct',1)" aria-label="יותר">+</button><span class="unit">%</span></div></div>
  <p class="mut">גודל ארוחה, שעות וכיול הגרמים: בדף <a href="/meal">ארוחות וכיול</a>.</p>
  <h3>זיהוי קול</h3>
  <div class="row"><label for="noiseDb">סף רעש (dB מעל הרקע)</label><input type="number" inputmode="decimal" step="0.5" id="noiseDb"></div>
  <div class="row"><label for="barkDb">סף עוצמה לנביחה (dB מעל הרקע)</label><input type="number" inputmode="decimal" step="0.5" id="barkDb"></div>
  <div class="row"><label for="barkMaxMs">נביחה רצופה ארוכה מ- (ms) = "קול חזק וארוך"</label><input type="number" inputmode="numeric" id="barkMaxMs"></div>
  <h3 id="askSet">כשהוא לא בטוח</h3>
  <div class="row"><label for="askBand">אזור "לא בטוח" מתחת לסף הנביחה</label><div class="stp"><button type="button" onclick="stp('askBand',-1)" aria-label="פחות">−</button><input type="number" inputmode="numeric" id="askBand" min="0" max="40" step="5" onchange="setv('askBand',Math.min(40,Math.max(0,Math.round(+this.value||0))))"><button type="button" onclick="stp('askBand',1)" aria-label="יותר">+</button><span class="unit">%</span></div></div>
  <p class="mut" id="askBandHelp"></p>
  <h3>מצב בית</h3>
  <div class="row"><label for="quietAfterNoiseS">שקט אחרי רעש, ברמה 1 (שניות)</label><input type="number" inputmode="decimal" step="0.5" id="quietAfterNoiseS"></div>
  <div class="row"><label for="barkCooldownS">שקט נדרש אחרי נביחה (שניות)</label><input type="number" inputmode="numeric" id="barkCooldownS"></div>
  <div class="row"><label for="minGapS">מינימום בין חטיפים (שניות)</label><input type="number" inputmode="numeric" id="minGapS"></div>
  <div class="row"><label for="postTreatIgnoreS">התעלמות אחרי חטיף (שניות)</label><input type="number" inputmode="numeric" id="postTreatIgnoreS"></div>
  <h3>מצב לבד</h3>
  <div class="row"><label for="aloneMinS">מרווח מינ׳ ברמה 1 (שניות)</label><input type="number" inputmode="numeric" id="aloneMinS"></div>
  <div class="row"><label for="aloneMaxS">מרווח מקס׳ ברמה 1 (שניות)</label><input type="number" inputmode="numeric" id="aloneMaxS"></div>
  <p class="mut" id="diffHelp"></p>
  <h3>טריגרים מבחוץ</h3>
  <div class="row"><label>רעש בחדר (מיקרופון פנימי, מצב בית)</label><label class="sw"><input type="checkbox" id="srcIndoor"><span></span></label></div>
  <div class="row"><label>מיקרופון חיצוני</label><label class="sw"><input type="checkbox" id="srcOutdoor"><span></span></label></div>
  <div class="row"><label>חיישן תנועה / מצלמה</label><label class="sw"><input type="checkbox" id="srcMotion"><span></span></label></div>
  <div class="row"><label for="eventQuietS">אירוע בחוץ ← שקט, ברמה 1 (שניות) ← חטיף</label><input type="number" inputmode="decimal" step="0.5" id="eventQuietS"></div>
  <div class="row"><label for="motionCooldownS">תנועה: התעלמות מחזרה (שניות)</label><input type="number" inputmode="numeric" id="motionCooldownS"></div>
  <div class="row"><label for="outdoorMinDb">מיק׳ חיצוני: רגישות (dB, נמוך = רגיש)</label><input type="number" inputmode="decimal" step="0.5" id="outdoorMinDb"></div>
  <div class="row"><label for="outdoorMinMs">מיק׳ חיצוני: אורך מינ׳ (ms)</label><input type="number" inputmode="numeric" id="outdoorMinMs"></div>
  <div class="row"><label for="outdoorCooldownS">מיק׳ חיצוני: התעלמות מחזרה (שניות)</label><input type="number" inputmode="numeric" id="outdoorCooldownS"></div>
  <div class="row"><label for="token">קוד סודי (token, לא חובה)</label><input type="text" id="token"></div>
  <h3>מצלמה ונביחות</h3>
  <div class="row"><label for="camHost">כתובת המצלמה</label><input type="text" id="camHost" placeholder="dogcam.local"></div>
  <div class="row"><label for="barkWindowMin">"נבחה?" בודק X דקות אחרונות</label><input type="number" inputmode="numeric" id="barkWindowMin"></div>
  <h3>מנוע וחטיף</h3>
  <div class="row"><label>צליל קליק לפני חטיף</label><label class="sw"><input type="checkbox" id="clicker"><span></span></label></div>
  <div class="row"><label for="stepsPerTreat">צעדי מנוע לחטיף</label><input type="number" inputmode="numeric" id="stepsPerTreat"></div>
  <div class="row"><label for="stepUs">מהירות מנוע (µs לצעד)</label><input type="number" inputmode="numeric" id="stepUs"></div>
  <div class="row"><label>היפוך כיוון המנוע</label><label class="sw"><input type="checkbox" id="reverseDir"><span></span></label></div>
  <div class="row"><label>חיישן IR במגלשה מחובר</label><label class="sw"><input type="checkbox" id="irFitted"><span></span></label></div>
  <div class="row"><label for="dropWaitMs">זמן המתנה לנפילה (ms)</label><input type="number" inputmode="numeric" id="dropWaitMs"></div>
  <div class="row"><label for="retries">ניסיונות שחרור תקיעה</label><input type="number" inputmode="numeric" id="retries"></div>
  <div class="row"><label for="emptyAfter">"נגמרו החטיפים" אחרי X ריקים ברצף</label><input type="number" inputmode="numeric" id="emptyAfter"></div>
  <div class="row"><label for="agitateSteps">ערבול לפני חטיף (צעדים)</label><input type="number" inputmode="numeric" id="agitateSteps"></div>
  <p class="mut">חטיף מהיר (גלגל מוכן מראש) והכיול שלו: בדף <a href="/meal">ארוחות וכיול</a>.</p>
  <h3 id="pushSet">התראות לטלפון</h3>
  <div class="row"><label for="pushOn">התראות לטלפון</label><label class="sw"><input type="checkbox" id="pushOn" onchange="setv('pushOn',this.checked?1:0)"><span></span></label></div>
  <div class="row"><label for="askPush">לשאול אותי כשהוא לא בטוח שזו נביחה</label><label class="sw"><input type="checkbox" id="askPush" onchange="setv('askPush',this.checked?1:0)"><span></span></label></div>
  <div class="topic"><span class="mut">הערוץ שלך:</span><b class="ltr" id="topicShow">--</b><button class="btn" type="button" onclick="copyTopic()">העתק</button></div>
  <p><b>איך מקבלים את ההתראות (פעם אחת):</b></p>
  <ol class="how"><li>מתקינים את האפליקציה <a href="https://play.google.com/store/apps/details?id=io.heckel.ntfy" target="_blank" rel="noopener"><b>ntfy</b></a> מחנות Play. חינם, בלי חשבון.</li><li>פותחים אותה ולוחצים על <b>+</b>.</li><li>מקלידים את שם הערוץ <b class="ltr" id="topicIn">--</b> ולוחצים על Subscribe</li></ol>
  <div class="row" style="justify-content:flex-start"><button class="btn dark" type="button" onclick="askTest()">שלח בדיקה</button></div>
  <p class="mut" id="askTestS" style="margin:4px 0"></p>
  <p class="mut" id="askStateT"></p>
  <p class="mut">יש לך את האפליקציה של המתקן? ההתראות מגיעות גם אליה, בלי ntfy.</p>
  <p class="mut">הכפתורים כן / לא בהתראה עובדים רק כשהטלפון בוויי-פיי של הבית. מחוץ לבית: לוחצים על ההתראה ועונים בדף כשחוזרים. לכל היותר התראת שאלה אחת ל-2 דקות, ו-20 ביום.</p>
  <details><summary class="mut">שם ערוץ אחר ועוד התראות</summary>
  <div class="row"><label for="ntfyTopic">שם ערוץ (אותיות באנגלית, ספרות, - _)</label><input type="text" id="ntfyTopic" placeholder="dogtreat-abc123" autocapitalize="off" autocomplete="off" spellcheck="false"></div>
  <div class="row"><label for="ntfyBarks">נביחות בדקה = התראה</label><input type="number" inputmode="numeric" id="ntfyBarks"></div>
  <div class="row"><label>התראה (עם תמונה) על כל חטיף</label><label class="sw"><input type="checkbox" id="ntfyOnTreat"><span></span></label></div>
  <p class="mut">שם ריק = המתקן יוצר שם חדש לבד. אחרי שינוי שומרים את ההגדרות ונרשמים שוב באפליקציה.</p>
  </details>
  <h3 id="remoteSet">שליטה מרחוק</h3>
  <div class="row"><label for="rmOn">שליטה מרחוק</label><label class="sw"><input type="checkbox" id="rmOn" onchange="rmSet(this.checked)"><span></span></label></div>
  <p class="mut">שולט במתקן גם מחוץ לבית דרך האפליקציה. הכול עובד, חוץ מוויי-פיי ואיפוס.</p>
  <p><b>קוד צימוד</b></p>
  <canvas id="rmQr" class="qr" width="205" height="205" aria-label="קוד צימוד"></canvas>
  <div class="topic"><span class="ltr rmc" id="rmCode">--</span><button class="btn" type="button" onclick="rmCopy()">העתק</button></div>
  <p class="mut">האפליקציה לוקחת את הקוד לבד כשהטלפון בוויי-פיי של הבית.</p>
  <p class="mut" id="rmLast"></p>
  <div class="row" style="justify-content:flex-start"><button class="btn" type="button" onclick="rmReset()">צור קוד חדש</button></div>
  <h3>סיכום שבועי (שישי 12:00)</h3>
  <div class="row"><label>לשלוח סיכום שבועי</label><label class="sw"><input type="checkbox" id="weekly"><span></span></label></div>
  <div class="row"><label for="cmbPhone">וואטסאפ: המספר שלך</label><input type="text" id="cmbPhone" placeholder="972501234567"></div>
  <div class="row"><label for="cmbKey">וואטסאפ: CallMeBot apikey</label><input type="text" id="cmbKey" placeholder="123456"></div>
  <div class="row"><button class="btn" onclick="post('/api/weekly-now').then(r=>toast(r.whatsapp==200?'נשלח לנטפי ולוואטסאפ':'נשלח לנטפי (וואטסאפ: '+(r.whatsapp||'לא מוגדר')+')'))">שלח סיכום עכשיו</button></div>
  <div class="row"><button class="btn dark" onclick="saveAll()">שמור הגדרות</button></div>
  <div class="row"><button class="btn" onclick="if(confirm('לאפס את הסטטיסטיקה של היום?'))post('/api/reset-stats').then(loadStats)">אפס היום</button>
  <button class="btn" onclick="if(confirm('למחוק את הוויי-פיי ולהפעיל מחדש?'))post('/api/reset-wifi')">החלף וויי-פיי</button></div>
</details></section>
<section class="card"><div class="row"><h2 style="margin:0">יומן אירועים</h2><label class="mut"><input type="checkbox" id="onlyBarks" onchange="loadStats()"> רק נביחות</label></div><div class="log" id="log"></div></section>
</div>

<div class="page" id="pg1">
<section class="card face v"><h2>האם זה עובד?</h2><div class="verdict" id="verdict">…</div><p class="mut" id="verdictSub"></p></section>
<section class="card"><div class="row"><h2 style="margin:0">טווח</h2><div class="seg" style="width:180px"><button id="r14" class="on" onclick="setRange(14)">14 ימים</button><button id="r30" onclick="setRange(30)">30 ימים</button></div></div>
  <div class="kpi" id="kpi"></div></section>
<section class="card"><h2>לפי סוג טריגר</h2><table class="t" id="trigT"></table><p class="mut">נבחה = נביחה תוך 10 שניות מהטריגר. הרוויחה = נשארה שקטה וקיבלה חטיף. פחות נבחה = טוב.</p></section>
<section class="card"><h2>נביחות ליום</h2><canvas id="cB" width="520" height="170"></canvas><div class="legend"><i style="background:#3F5A78"></i>נביחות<i style="background:#9DB0C6"></i>התקפי נביחות</div></section>
<section class="card"><h2>תגובה לאירועים בחוץ (%)</h2><canvas id="cR" width="520" height="150"></canvas><p class="mut">כמה מהאירועים גררו נביחה תוך 10 שניות. פחות = טוב.</p></section>
<section class="card"><h2>זמן הרגעה ממוצע (שניות)</h2><canvas id="cC" width="520" height="150"></canvas></section>
<section class="card"><h2>גרם חטיפים ליום</h2><canvas id="cG" width="520" height="150"></canvas><div class="legend"><i style="background:#3E6B52"></i>גרם חטיפים<i style="background:#B9C2B5"></i>10% מהאוכל היומי</div></section>
<section class="card"><h2>רצף שקט הכי ארוך לבד (דק׳)</h2><canvas id="cT" width="520" height="150"></canvas></section>
<section class="card"><h2>רמות קושי</h2><canvas id="cL" width="520" height="150"></canvas><div class="legend"><i style="background:var(--ink)"></i>לבד<i style="background:#3E6B52"></i>פעמון<i style="background:#F4A988"></i>רעש ורחוב<i style="background:#B9C2B5"></i>תנועה</div></section>
<section class="card"><a class="btn dark" href="/api/days.csv" download="dog-progress.csv">ייצוא CSV (לאקסל)</a><p class="mut">הנתונים נשמרים במתקן 90 יום ונשארים גם אחרי כיבוי.</p></section>
</div>

<div class="page" id="pg2">
<section class="card face"><h2>משקל</h2>
  <div class="wface"><div><div class="num" id="wNow">--</div><div class="mut" id="wSub">ק״ג</div></div><div><div class="num" id="wTarget"></div><div class="mut">יעד</div></div></div>
</section>
<section class="card">
  <canvas id="cW" width="520" height="190"></canvas>
  <p class="mut" id="wTrend"></p>
</section>
<section class="card"><h2>שקילה חדשה</h2>
  <div class="row"><label for="wKg">משקל (ק״ג)</label><input type="number" inputmode="decimal" step="0.1" id="wKg" placeholder="27.0"></div>
  <div class="row"><label for="wDate">תאריך</label><input type="date" id="wDate"></div>
  <button class="treat sm" onclick="wSave()">שמור משקל</button>
  <div class="row"><label for="targetKg">יעד (ק״ג)</label><input type="number" inputmode="decimal" step="0.1" min="5" max="80" id="targetKg" onchange="post('/api/weight','target='+this.value).then(w=>{W=w;wRender();toast('היעד נשמר')})"></div>
  <p class="mut">שוקלים פעם בשבוע, באותה שעה, לפני אוכל. ירידה בטוחה: עד 1–2% ממשקל הגוף בשבוע.</p>
</section>
<section class="card"><h2>כל השקילות</h2><div id="wList" class="mut">אין עדיין</div></section>
</div>

<div class="page" id="pg3">
<section class="card"><h2>הקול שלך</h2>
  <div class="row"><label>רמקול מחובר</label><label class="sw"><input type="checkbox" id="spkFitted" onchange="setv('spkFitted',this.checked?1:0)"><span></span></label></div>
  <div class="row"><label>להשמיע עם כל חטיף</label><label class="sw"><input type="checkbox" id="voiceOnTreat" onchange="setv('voiceOnTreat',this.checked?1:0)"><span></span></label></div>
  <div class="row"><label for="volume">עוצמה</label><div class="stp"><button type="button" onclick="stp('volume',-1)" aria-label="פחות">−</button><input type="number" inputmode="numeric" id="volume" min="0" max="100" step="5" onchange="setv('volume',this.value)"><button type="button" onclick="stp('volume',1)" aria-label="יותר">+</button><span class="unit">%</span></div></div>
  <p id="voiceStat" class="mut"></p>
  <button class="treat sm" id="recBtn" onclick="rec('voice')">הקלט "כלבה טובה" (עד 5 שנ׳)</button>
  <div class="row"><label class="btn">או בחר קובץ קול<input type="file" accept="audio/*" style="display:none" onchange="pickFile(this,'voice')"></label><button class="btn" onclick="playV()">השמע</button></div>
  <p class="mut" id="recNote"></p>
</section>
<section class="card"><h2>פעמון = דבר טוב</h2>
  <p class="mut">שלב ראשון לכלבה שנבהלת מהפעמון: המתקן משמיע צלצול חלש מאוד, ואם היא לא נובחת היא מקבלת חטיף מיד. כך הצלצול מתחיל להבטיח משהו טוב. נבחה? אין חטיף, והצלצול הבא שקט יותר. 5 פעמים רגועה ברצף = קצת יותר חזק, אבל אף פעם לא מעל המקסימום. מפעילים במסך הראשי: "פעמון = דבר טוב".</p>
  <div id="bellStat"></div>
  <div class="row"><label for="bellVol">עוצמה עכשיו</label><div class="stp"><button type="button" onclick="stp('bellVol',-1)" aria-label="פחות">−</button><input type="number" inputmode="numeric" id="bellVol" min="1" max="100" step="1"><button type="button" onclick="stp('bellVol',1)" aria-label="יותר">+</button><span class="unit">%</span></div></div>
  <div class="row"><label for="bellVolMax">עוצמה מקסימלית</label><div class="stp"><button type="button" onclick="stp('bellVolMax',-1)" aria-label="פחות">−</button><input type="number" inputmode="numeric" id="bellVolMax" min="1" max="100" step="1"><button type="button" onclick="stp('bellVolMax',1)" aria-label="יותר">+</button><span class="unit">%</span></div></div>
  <div class="row"><button class="btn" onclick="post('/api/play','slot=bell&vol='+bellVol.value)">השמע צלצול</button><button class="btn dark" onclick="saveAll()">שמור</button></div>
</section>
<section class="card"><h2>אימון לרעשים</h2>
  <p class="mut">שלב שני: המתקן משמיע בשקט צלצול / נביחה. נשארה שקטה כמה שניות אחרי? חטיף. נבחה? אין חטיף, והפסקה. העוצמה עולה קצת כל יום שהיא מצליחה.</p>
  <div id="trainStat"></div>
  <div class="row"><label for="trainSound">צליל</label><select id="trainSound" onchange="setv('trainSound',this.value)"><option value="0">צלצול בדלת</option><option value="1">כלב נובח</option><option value="2">לסירוגין</option></select></div>
  <div class="row"><label for="trainVol">עוצמה עכשיו</label><div class="stp"><button type="button" onclick="stp('trainVol',-1)" aria-label="פחות">−</button><input type="number" inputmode="numeric" id="trainVol" min="1" max="100" step="1" onchange="setv('trainVol',this.value)"><button type="button" onclick="stp('trainVol',1)" aria-label="יותר">+</button><span class="unit">%</span></div></div>
  <div class="row"><button class="btn" onclick="post('/api/play','slot=bell&vol='+trainVol.value)">צלצול</button><button class="btn" onclick="post('/api/play','slot=bark&vol='+trainVol.value)">נביחה</button><button class="btn" onclick="post('/api/train-now').then(()=>toast('ניסיון הבא מיד כשהיא שקטה'))">ניסיון עכשיו</button></div>
  <div class="row"><label for="trainStep">עלייה ביום (%)</label><input type="number" inputmode="numeric" id="trainStep"></div>
  <div class="row"><label for="trainVolMax">עוצמה מקסימלית (%)</label><input type="number" inputmode="numeric" id="trainVolMax"></div>
  <div class="row"><label for="trainPassPct">הצלחה נדרשת לעלייה (%)</label><input type="number" inputmode="numeric" id="trainPassPct"></div>
  <div class="row"><label for="trainQuietS">שקט נדרש אחרי הצליל (שנ׳)</label><input type="number" inputmode="decimal" step="0.5" id="trainQuietS"></div>
  <div class="row"><label for="trainGapMinS">הפסקה בין ניסיונות: מינ׳ (שנ׳)</label><input type="number" inputmode="numeric" id="trainGapMinS"></div>
  <div class="row"><label for="trainGapMaxS">הפסקה בין ניסיונות: מקס׳ (שנ׳)</label><input type="number" inputmode="numeric" id="trainGapMaxS"></div>
  <div class="row"><label for="trainMaxDay">ניסיונות ביום (גם בפעמון = דבר טוב)</label><input type="number" inputmode="numeric" id="trainMaxDay"></div>
  <div class="row"><button class="btn dark" onclick="saveAll()">שמור</button></div>
</section>
<section class="card"><h2>צלילים משלך (לא חובה)</h2>
  <p class="mut">יש צלצול ונביחה מובנים. אפשר להחליף בהקלטה אמיתית (הפעמון שלכם, כלב של השכנים).</p>
  <div class="row"><button class="btn" onclick="rec('bell')">הקלט צלצול</button><label class="btn">קובץ<input type="file" accept="audio/*" style="display:none" onchange="pickFile(this,'bell')"></label><button class="btn" onclick="delSnd('bell')">חזרה למובנה</button></div>
  <div class="row"><button class="btn" onclick="rec('bark')">הקלט נביחה</button><label class="btn">קובץ<input type="file" accept="audio/*" style="display:none" onchange="pickFile(this,'bark')"></label><button class="btn" onclick="delSnd('bark')">חזרה למובנה</button></div>
</section>
</div>
<div class="page" id="pg4">
<header class="face v"><div class="pgtop"><button class="back" onclick="tab(0)">→ חזרה</button><button class="back" onclick="tab(5)">מה לא עובד?</button></div>
<div class="verdict">הוראות</div><p class="mut">פעולה אחת בכל שורה. לוחצים על נושא כדי לפתוח אותו.</p></header>
<section class="card help">
<details open><summary><span>חיבור ראשון לוויי-פיי</span></summary><ol class="how"><li>מחברים את המתקן לחשמל.</li><li>בטלפון: הגדרות ← <bdi>Wi-Fi</bdi>.</li><li>מתחברים לרשת <span class="ltr">DogTreat-Setup</span>.</li><li>נפתח דף. לא נפתח? פותחים בדפדפן <span class="ltr">192.168.4.1</span>.</li><li>לוחצים <span class="ltr">Configure WiFi</span>.</li><li>בוחרים את הוויי-פיי של הבית.</li><li>מקלידים את הסיסמה ולוחצים <span class="ltr">Save</span>.</li><li>בטלפון חוזרים לוויי-פיי של הבית.</li><li>פותחים בכרום: <span class="ltr">dogtreat.local</span>.</li></ol><div class="tip"><b>יש 3 דקות.</b>אחרי 3 דקות בלי חיבור הרשת <span class="ltr">DogTreat-Setup</span> נעלמת והמתקן עובד בלי וויי-פיי. מנתקים מהחשמל, מחברים שוב, ומתחילים מההתחלה.</div><div class="tip"><b>הרשת של הבית לא ברשימה?</b>המתקן רואה רק רשת <bdi>2.4GHz</bdi>. בראוטר עם שתי רשתות בוחרים את זו שהיא לא <bdi>5G</bdi>.</div><div class="tip"><b><span class="ltr">dogtreat.local</span> לא נפתח?</b>באתר ההתקנה במחשב: התקן ← <span class="ltr">Logs &amp; Console</span>, ומחפשים שורה <span class="ltr">[wifi] IP</span>. את המספר הזה מקלידים בדפדפן.</div></details>
<details><summary><span>להוסיף למסך הבית</span></summary><ol class="how"><li>פותחים את <span class="ltr">dogtreat.local</span> בטלפון.</li><li>אנדרואיד (כרום): ⋮ למעלה ← "הוספה למסך הבית" ← הוספה.</li><li>אייפון (ספארי): כפתור השיתוף ← "הוסף למסך הבית".</li><li>מעכשיו פותחים מהאייקון במסך הבית.</li></ol><div class="tip">זה עובד רק כשהטלפון מחובר לוויי-פיי של הבית.</div></details>
<details><summary><span>מילוי המיכל</span></summary><ol class="how"><li>לוחצים <bdi>STOP</bdi> (כדי שהגלגלים לא יזוזו).</li><li>פותחים את המכסה (04).</li><li>חטיפים: בצד שכתוב עליו <bdi>TREATS</bdi> (שמאל, צד <bdi>T</bdi>).</li><li>אוכל: בצד ימין (צד <bdi>F</bdi>).</li><li>סוגרים את המכסה עד קליק.</li><li>היה כתוב "נגמרו החטיפים"? לוחצים "מילאתי".</li><li>לוחצים "המשך עכשיו" בפס האדום למעלה.</li></ol></details>
<details><summary><span>המצבים</span></summary><p>בוחרים מצב במסך הראשי, בכרטיס "מצב".</p><ul class="okl"><li><b>בית:</b> כשאתם בבית. רעש או משהו בחוץ, והיא שקטה = חטיף.</li><li><b>לבד:</b> כשאין אף אחד. כל עוד היא שקטה, חטיף בזמן אקראי.</li><li><b>רק מדידה:</b> שבוע ראשון. אין חטיפים בכלל, רק ספירה.</li><li><b>פעמון = דבר טוב:</b> צלצול חלש, והיא שקטה = חטיף. צריך רמקול.</li><li><b>אימון לרעשים:</b> אחרי הפעמון. צליל מהרמקול, ואז שקט = חטיף.</li></ul><p><button class="btn" onclick="showModes()">לטבלה המלאה</button></p></details>
<details id="hLearn"><summary><span>זיהוי נביחות משתפר עם הזמן</span></summary><p>הוא משתפר רק ממה שאתה מלמד אותו. הוא לא לומד לבד.</p><p><b>ללמד אותו את הנביחה שלה:</b></p><ol class="how"><li>במסך הראשי, בכרטיס "זיהוי נביחות", לוחצים "הקלט נביחה".</li><li>גורמים לה לנבוח ליד המתקן 3–10 פעמים (דפיקה בדלת, פעמון).</li><li>מחכים 30 שניות. או לוחצים "סיים הקלטה".</li><li>כתוב "נשמר"? הוא למד את הקול שלה.</li><li>כתוב "נקלטו רק…"? מנסים שוב.</li></ol><p><b>כשהוא טועה:</b></p><ol class="how"><li>באותו כרטיס, ברשימה "קולות אחרונים", מוצאים את הקול.</li><li>זה לא היה נביחה? לוחצים "זה לא היה נביחה".</li><li>זו כן הייתה נביחה? לוחצים "זו כן נביחה".</li></ol><div class="tip">ככל שתקליט ותסמן יותר, הוא יזהה טוב יותר. כל הקלטה מתווספת לקודמות. הוא זוכר עד 24 דוגמאות של "לא נביחה", והחדשות מחליפות את הישנות.</div></details>
<details id="hAsk"><summary><span>כשהוא לא בטוח</span></summary><p>לפעמים קול נשמע קצת כמו נביחה, אבל לא מספיק.</p><ol class="how"><li>הוא לא נותן חטיף, וספירת השקט מתחילה מחדש.</li><li>הוא לא סופר את זה כנביחה.</li><li>הוא רושם "לא בטוח" ושואל אותך.</li><li>במסך הראשי, למעלה: "שמעתי משהו — זו הייתה נביחה?".</li><li>לוחצים "כן" או "לא".</li><li>כן = הוא לומד שזה הקול שלה. לא = הוא זוכר שזה לא נביחה.</li><li>לא בטוח בעצמך? לוחצים "לא יודע".</li></ol><p><b>שאלות גם לטלפון:</b></p><ol class="how"><li>במסך הראשי פותחים "הגדרות".</li><li>מדליקים "התראות לטלפון".</li><li>עושים את 3 השלבים שמתחת (אפליקציית ntfy).</li><li>לוחצים "שלח בדיקה".</li><li>בהתראה לוחצים "כן" או "לא".</li></ol><div class="tip">התשובה לא נותנת חטיף עכשיו. היא רק מלמדת אותו. הכפתורים בהתראה עובדים רק בוויי-פיי של הבית. לכל היותר שאלה אחת ל-2 דקות, ו-20 ביום. השאלה נעלמת אחרי 20 קולות חדשים.</div><p><b>שואל יותר מדי או פחות מדי?</b></p><ol class="how"><li>הגדרות ← "כשהוא לא בטוח".</li><li>לוחצים − כדי שישאל פחות. 0 = לא שואל אף פעם.</li><li>לוחצים + כדי שישאל יותר.</li></ol></details>
<details id="hRemote"><summary><span>שליטה מרחוק</span></summary><p>שולטים במתקן גם מחוץ לבית, דרך האפליקציה של המתקן. כמעט כל מה שיש בדף הזה עובד גם מרחוק.</p><ol class="how"><li>במסך הראשי פותחים "הגדרות".</li><li>מדליקים "שליטה מרחוק".</li><li>פותחים את האפליקציה כשהטלפון בוויי-פיי של הבית.</li><li>האפליקציה מתחברת לבד. צריך את זה רק פעם אחת.</li><li>מעכשיו אפשר מכל מקום, גם ב-4G או 5G.</li><li>עובד מרחוק: חטיף, ארוחה, ניקוי, מצב, הגדרות, סטטיסטיקה, הקלטות, כיול, תמונה מהמצלמה ו"זו הייתה נביחה?".</li></ol><div class="tip"><b>מה נשאר רק בבית?</b>החלפת וויי-פיי, איפוס הסטטיסטיקה, שידור חי מהמצלמה, והקוד של "שליטה מרחוק". כך המתקן לא מתנתק כשאין אף אחד בבית.</div><div class="tip"><b>כמה זמן זה לוקח?</b>תשובה מגיעה תוך 2 עד 5 שניות. תמונה והורדת קובץ: עד 10 שניות. אחרי כל פעולה המתקן בודק מהר יותר במשך דקה. מרחוק יש עד 150 בקשות ביום. בבית אין הגבלה.</div><div class="tip">חטיף מרחוק עובד לפי אותם כללים כמו הכפתור "חטיף" בדף. המתקן צריך וויי-פיי עם אינטרנט בבית.</div><p><b>טלפון אבד, או שמישהו אחר קיבל את הקוד?</b></p><ol class="how"><li>הגדרות ← "שליטה מרחוק".</li><li>לוחצים "צור קוד חדש" ומאשרים.</li><li>הקוד הישן מפסיק לעבוד.</li><li>פותחים את האפליקציה בבית, והיא מתחברת שוב.</li></ol><p><b>התראות באפליקציה:</b></p><ol class="how"><li>מדליקים "התראות לטלפון" בהגדרות.</li><li>ההתראות מגיעות גם לאפליקציה של המתקן. לא צריך ntfy.</li><li>מי שמשתמש ב-ntfy: הוא ממשיך לעבוד כמו קודם.</li></ol></details>
<details><summary><span>כפתור "זרוק חטיף"</span></summary><ol class="how"><li>במסך הראשי לוחצים "זרוק חטיף".</li><li>המתקן מקליק ומפיל חטיף אחד.</li><li>נבחה לפני פחות מ-10 שניות? מופיעה אזהרה. עדיף לחכות שתשתוק.</li></ol><div class="tip"><b>מתי הכפתור לא עובד?</b>במצב "רק מדידה", במצב ניקוי, באמצע ארוחה, וכשחטיף קודם עוד יוצא. ההודעה למעלה אומרת למה.</div><div class="tip"><b>חטיף מהיר (פעם אחת):</b>"ארוחות וכיול" ← "חטיף מהיר" ← "סובב למצב מוכן". נפל חטיף לבד? "נפל לפני הקליק", ושוב.</div></details>
<details><summary><span>ארוחות לפי שעון</span></summary><ol class="how"><li>במסך הראשי למעלה: "ארוחות וכיול".</li><li>מסמנים "ארוחות אוטומטיות".</li><li>קובעים גרם לארוחה עם − / +.</li><li>בוחרים שעה לארוחה 1 ולארוחה 2.</li><li>לוחצים "שמור".</li></ol><div class="tip"><b>צריך שעון.</b>המתקן לוקח את השעה מהאינטרנט. בלי אינטרנט אין ארוחות לפי שעון.</div><div class="tip"><b>חטיפים יורדים מהארוחה.</b>הגרמים של החטיפים יורדים מהארוחה הבאה, אבל לא מתחת לאחוז שקבעת בהגדרות.</div><div class="tip"><b>כיול גרמים (פעם אחת לכל גלגל):</b>"ארוחות וכיול" ← "כיול גרמים". כוס מתחת לפתח, "הפעל 20 שקעים", שוקלים ומקלידים.</div></details>
<details><summary><span>מצב ניקוי</span></summary><ol class="how"><li>"ארוחות וכיול" ← "התחל ניקוי". או: מחזיקים את כפתור <bdi>BOOT</bdi> על הלוח 5 שניות.</li><li>מחכים: הגלגלים מתרוקנים למגש, קודם חטיפים ואז אוכל.</li><li>מרימים את מחסנית הגלגלים החוצה.</li><li>שוטפים בכיור ומייבשים.</li><li>מחזירים את המחסנית למקום.</li><li>לוחצים "סיימתי לנקות". או: לחיצה קצרה על <bdi>BOOT</bdi>.</li><li>המתקן מסנכרן את הגלגלים לבד.</li></ol><div class="tip">בזמן ניקוי אין ארוחות ואין חטיפים, גם לא בכפתור.</div></details>
<details><summary><span>כפתור <bdi>STOP</bdi></span></summary><ol class="how"><li>לוחצים על הכפתור האדום העגול למטה. הוא נמצא בכל מסך.</li><li>הכול נעצר ל-10 דקות: חטיפים אוטומטיים, אימון, ארוחות וצלילים.</li><li>להמשיך לפני כן: "המשך עכשיו" בפס האדום למעלה.</li></ol></details>
<details><summary><span>מצלמה (לא חובה)</span></summary><ol class="how"><li>שמים את ה-<bdi>ESP32-CAM</bdi> על לוח ה-<bdi>MB</bdi>.</li><li>מחברים את ה-<bdi>MB</bdi> בכבל <bdi>USB</bdi> למחשב.</li><li>באתר ההתקנה לוחצים "התקן מצלמה".</li><li>בטלפון מתחברים לרשת <span class="ltr">DogCam-Setup</span>.</li><li>בוחרים את הוויי-פיי של הבית ושומרים.</li><li>במתקן: "הגדרות" ← "כתובת המצלמה" ← כותבים <span class="ltr">dogcam.local</span>.</li><li>לוחצים "שמור הגדרות".</li><li>במסך הראשי מופיע כרטיס "מצלמה".</li></ol><div class="tip">המצלמה צריכה רק חשמל (<bdi>5V</bdi> ו-<bdi>GND</bdi>). היא מדברת עם המתקן בוויי-פיי.</div></details>
<details><summary><span>יחידה חיצונית (לא חובה)</span></summary><ol class="how"><li>מנתקים את הסוללה של היחידה.</li><li>מחברים את ה-<bdi>C3</bdi> בכבל <bdi>USB-C</bdi> למחשב.</li><li>באתר ההתקנה לוחצים "התקן יחידה חיצונית".</li><li>מחזירים את הסוללה ושמים את היחידה בחוץ, קרוב לחלון.</li><li>במתקן, "הגדרות": מסמנים "מיקרופון חיצוני".</li></ol><div class="tip">היחידה מדברת ישר עם המתקן, בלי ראוטר. במסך הראשי כתוב "יחידה חיצונית: מחוברת" כשהיא נשמעת.</div></details>
<details><summary><span>להחליף וויי-פיי</span></summary><ol class="how"><li>במסך הראשי: "הגדרות" ← "החלף וויי-פיי".</li><li>מאשרים.</li><li>המתקן נדלק מחדש ופותח שוב את <span class="ltr">DogTreat-Setup</span>.</li><li>ממשיכים כמו ב"חיבור ראשון לוויי-פיי".</li></ol></details>
<details><summary><span>עדכון תוכנה</span></summary><ol class="how"><li>במחשב (לא בטלפון) פותחים בכרום את אתר ההתקנה: <span class="ltr">nitay-feeder-kit.sites.tab.bot</span>.</li><li>מנתקים את המטען של המתקן.</li><li>מחברים את לוח ה-<bdi>ESP32</bdi> בכבל <bdi>USB-C</bdi> למחשב.</li><li>לוחצים "התקן" ובוחרים את היציאה (משהו כמו <bdi>USB-SERIAL CH340</bdi>).</li><li><bdi>Install</bdi> ← <bdi>Next</bdi>. <b>לא</b> מסמנים <bdi>Erase</bdi>.</li><li>מחכים בערך 2 דקות עד "<bdi>Installation complete</bdi>".</li><li>מנתקים מהמחשב ומחזירים את המטען.</li></ol><div class="tip">בלי <bdi>Erase</bdi> הוויי-פיי וההגדרות נשמרים. עם <bdi>Erase</bdi> הכול נמחק ומתחילים מ"חיבור ראשון".</div></details>
<details><summary><span>בדיקת חיבורים</span></summary><p>בודקת כל חלק לבד: מיקרופון, חיישנים, רמקול, נורה, מנוע ומצלמה. בחלק מהבדיקות צריך לגעת בחיישן או להקשיב.</p><p><a class="btn" href="/check">לבדיקת חיבורים</a></p></details>
</section>
<section class="card"><h2>משהו לא עובד?</h2><p class="mut">המתקן בודק את עצמו ומסביר מה לא עובד, למה, ומה לעשות.</p><button class="btn dark" onclick="tab(5)">מה לא עובד?</button></section>
</div>
<div class="page" id="pg5">
<header class="face v"><div class="pgtop"><button class="back" onclick="tab(0)">→ חזרה</button><button class="back" onclick="tab(4)">הוראות</button></div>
<div class="verdict" id="dgVerdict">בודק…</div><p class="mut" id="dgSub">המתקן בודק כל חלק שהוא יכול לבדוק לבד.</p><button class="btn hb2" onclick="loadDiag(1)">בדוק שוב</button></header>
<div id="dgList"></div>
<section class="card"><h2>תקין</h2><ul class="okl" id="dgOk"></ul></section>
<section class="card" id="dgInfoC"><h2>לידיעה</h2><ul class="okl" id="dgInfo"></ul></section>
<section class="card"><p class="mut">יש חלקים שהמתקן לא יכול לבדוק לבד (רמקול, זמזם, נורה, מנוע). בשבילם: <a href="/check">בדיקת חיבורים</a>.</p></section>
</div>
</main>
<nav class="dock"><div class="bar"><button class="tb on" id="tb0" onclick="tab(0)">ראשי</button><button class="tb" id="tb1" onclick="tab(1)">התקדמות</button><button class="tb" id="tb2" onclick="tab(2)">משקל</button><button class="tb" id="tb3" onclick="tab(3)">צלילים</button></div><button class="stop" onclick="stopAll()" aria-label="עצור הכול">STOP</button></nav>
<footer id="foot"></footer><div id="toast" role="status"></div>
<script>
function isNum(t){return t&&t.tagName=='INPUT'&&t.type=='number'}
function shake(e){e.classList.remove('shk');void e.offsetWidth;e.classList.add('shk');setTimeout(()=>e.classList.remove('shk'),400)}
document.addEventListener('focusin',e=>{if(isNum(e.target))e.target._old=e.target.value},true);
document.addEventListener('keydown',e=>{if(e.key=='Enter'&&isNum(e.target))e.target.blur()},true);
document.addEventListener('change',e=>{const t=e.target;if(!isNum(t))return;const v=parseFloat(String(t.value).replace(',','.'));
 if(isNaN(v)){t.value=t._old==null?'':t._old;shake(t);e.stopPropagation();return}
 const mn=t.min===''?-1e9:+t.min,mx=t.max===''?1e9:+t.max;if(v<mn||v>mx){t.value=Math.min(mx,Math.max(mn,v));shake(t)}t._old=t.value},true);
function stp(id,d){const e=document.getElementById(id),st=+(e.step||1)||1,mn=e.min===''?-1e9:+e.min,mx=e.max===''?1e9:+e.max;
 let v=Math.round(((parseFloat(e.value)||0)+d*st)/st)*st;v=+v.toFixed(2);if(v<mn||v>mx){v=Math.min(mx,Math.max(mn,v));shake(e)}e.value=v;
 clearTimeout(e._t);e._t=setTimeout(()=>{e._t=0;e.dispatchEvent(new Event('change',{bubbles:true}))},400)}
function busy(id){const e=document.getElementById(id);return document.activeElement===e||!!e._t}

const $=id=>document.getElementById(id);let S={},cfg={},W={list:[]};
const F=['askBand','dropWaitMs','retries','emptyAfter','agitateSteps','trainStep','trainVolMax','trainPassPct','trainQuietS','trainGapMinS','trainGapMaxS','trainMaxDay','cmbPhone','cmbKey','eventQuietS','motionCooldownS','outdoorMinDb','outdoorMinMs','outdoorCooldownS','token','camHost','barkWindowMin','noiseDb','barkDb','barkMaxMs','quietAfterNoiseS','barkCooldownS','minGapS','postTreatIgnoreS','aloneMinS','aloneMaxS','stepsPerTreat','stepUs','ntfyTopic','ntfyBarks','dailyFoodG','mealFloorPct','bellVol','bellVolMax'];
const CB=['clicker','reverseDir','srcIndoor','srcOutdoor','srcMotion','ntfyOnTreat','irFitted','weekly','treatFromMeal','pushOn','askPush'];
const ENG=[['לבד','difficulty'],['פעמון','lvlDoor'],['רעש ורחוב','lvlNoise'],['תנועה','lvlMotion']];
function toast(t){const e=$('toast');e.textContent=t;e.style.display='block';clearTimeout(e._t);e._t=setTimeout(()=>e.style.display='none',Math.max(2400,String(t).length*75))}
function post(u,body){const b=busyBtn();return fetch(u,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body||''}).then(r=>r.json()).then(j=>{doneBtn(b,j.ok!==false&&!j.error);return j},e=>{doneBtn(b,false);throw e})}
function setv(k,v){post('/api/settings',k+'='+encodeURIComponent(v)).then(c=>{cfg=c;fill();toast('נשמר')}).catch(()=>toast('לא נשמר. '+NOCONN))}
function saveAll(){const p=new URLSearchParams();F.forEach(k=>p.append(k,$(k).value));CB.forEach(k=>p.append(k,$(k).checked?1:0));
 post('/api/settings',p.toString()).then(c=>{cfg=c;fill();toast('ההגדרות נשמרו');camImgOk=null;camProbe=null}).catch(()=>toast('ההגדרות לא נשמרו. '+NOCONN))}
function stopAll(){post('/api/stop').then(()=>toast('הכול נעצר')).catch(()=>toast('STOP לא הגיע למתקן. '+NOCONN))}
function fmtS(s){s=Math.max(0,Math.round(s));return s>=60?Math.floor(s/60)+':'+String(s%60).padStart(2,'0')+' דק׳':s+' שנ׳'}
function lvlTo(i,v){setv(ENG[i][1],Math.min(10,Math.max(1,Math.round(+v)||1)))}
function lvlSet(i,d){const k=ENG[i][1],v=Math.min(10,Math.max(1,(+cfg[k]||1)+d));setv(k,v)}
function fill(){F.forEach(k=>{if(!busy(k))$(k).value=cfg[k]});
 CB.forEach(k=>$(k).checked=!!cfg[k]);['spkFitted','voiceOnTreat','autoDiff','enabled'].forEach(k=>$(k).checked=!!cfg[k]);
 if(!busy('volume'))$('volume').value=cfg.volume;if(!busy('trainVol'))$('trainVol').value=cfg.trainVol;$('trainSound').value=cfg.trainSound;camSetup();
 if(!busy('targetKg'))$('targetKg').value=cfg.targetKg;
 [0,1,2,3,4].forEach(i=>$('m'+i).className=cfg.mode==i?'on':'');[0,1,2].forEach(i=>$('bs'+i).className=cfg.barkSens==i?'on':'');
 $('bsHelp').textContent=['קפדני: נביחה רק כשבטוחים (פחות טעויות, אבל נביחה שקטה עלולה להיות "לא בטוח")','רגיל: מומלץ להתחלה','רגיש: גם נביחה רחוקה או שקטה נספרת (יותר רעשים ייחשבו נביחה)'][cfg.barkSens]||'';
 $('doorRow').style.display=cfg.mode==0?'flex':'none';askBandTxt();topicTxt();
 const m=1+(cfg.difficulty-1)*0.5;$('diffHelp').textContent='ברמה '+cfg.difficulty+' עכשיו: חטיף כל '+fmtS(cfg.aloneMinS*m)+' עד '+fmtS(cfg.aloneMaxS*m)+' של שקט';modeHelp()}
function modeHelp(){const q=S.qHome!=null?S.qHome:cfg.quietAfterNoiseS;
 $('modeHelp').textContent=[
  'כשיש רעש (או משהו בחוץ) והיא נשארת שקטה '+q+' שניות, היא מקבלת חטיף. נביחה = אין חטיף עד '+cfg.barkCooldownS+' שניות של שקט. מתאים כשאתם בבית.',
  'כל עוד היא שקטה, חטיף מגיע בזמן אקראי. נביחה מתחילה את הספירה מחדש. מתאים כשאין אף אחד בבית.',
  'לא נותן חטיפים בכלל (גם לא ידני), רק סופר נביחות ורעשים. מתאים לשבוע הראשון, כדי שיהיה למה להשוות במסך ההתקדמות.',
  'המתקן משמיע בשקט צלצול או נביחה. אם היא שקטה '+cfg.trainQuietS+' שניות אחרי, חטיף, והעוצמה עולה קצת כל יום. מתאים אחרי שהיא רגועה בפעמון = דבר טוב.',
  'המתקן משמיע צלצול חלש מאוד. אם היא לא נובחת, חטיף מיד. השלב הראשון לכלבה שנבהלת מהפעמון. ההגדרות בלשונית צלילים.'][cfg.mode]||''}
function loadCfg(){fetch('/api/settings').then(r=>r.json()).then(c=>{cfg=c;fill()});loadAsk()}
function treat(){post('/api/treat').then(r=>toast(r.ok?'חטיף בדרך':'אין חטיף: '+whyTxt(r))).catch(()=>toast(NOCONN))}
function door(){post('/api/doorbell').then(r=>toast(r.status=='waiting for quiet'?'אם היא תישאר שקטה, תקבל חטיף':r.status=='cooldown'?'כבר נרשם צלצול לפני רגע':'נרשם')).catch(()=>toast(NOCONN))}
function tab(i){[0,1,2,3,4,5].forEach(k=>{$('pg'+k).className='page'+(k==i?' on':'');const b=$('tb'+k);if(b)b.className='tb'+(k==i?' on':'')});if(i==1)loadDays();if(i==2)loadW();if(i==5)loadDiag(1);scrollTo(0,0)}
function playV(){post('/api/play','slot=voice').then(r=>toast(r.speaker?'משמיע':'קליק בזמזם (אין רמקול או הקלטה)'))}
function delSnd(s){post('/api/sound-del','slot='+s).then(()=>toast('חזר לצליל המובנה'))}
function calib(){toast('שקט בבקשה… 5 שניות');post('/api/calibrate')}
function pill(t,c){return '<span class="pill'+(c?' '+c:'')+'">'+t+'</span>'}
function poll(){fetch('/api/status').then(r=>r.json()).then(s=>{S=s;
 $('sub').textContent='מחובר · '+s.ip+(s.clock?'':' · השעון עוד לא סונכרן');
 $('lvl').textContent=s.level.toFixed(0)+' dB';$('base').textContent='רקע: '+s.base.toFixed(0)+' dB · מעל הרקע: '+s.above.toFixed(0);
 const lo=30,hi=100,pct=v=>Math.min(100,Math.max(0,(v-lo)/(hi-lo)*100));
 $('fill').style.width=pct(s.level)+'%';$('mN').style.left=pct(s.base+cfg.noiseDb)+'%';$('mB').style.left=pct(s.base+cfg.barkDb)+'%';
 $('tT').textContent=s.treats;$('tB').textContent=s.barks;$('tG').textContent=Math.round(s.treatG);
 // food
 $('leftG').textContent=s.leftG;$('foodG').textContent=s.foodG;$('foodSplit').textContent=s.mealG+' · '+Math.round(s.treatG)+' ג׳';
 const tot=Math.max(s.foodG,s.mealG+s.treatG)||1;$('fbM').style.width=(s.mealG/tot*100)+'%';$('fbT').style.width=(s.treatG/tot*100)+'%';
 $('nextMeal').textContent='ארוחה הבאה: '+s.nextMeal+' ג׳'+(s.nextMeal<s.mealSize?' (במקום '+s.mealSize+', כי '+(s.mealSize-s.nextMeal)+' ג׳ כבר ניתנו כחטיפים)':'')+(s.treatG>s.foodG*0.1?' · החטיפים היום מעל 10% מהאוכל, והם יורדים מהארוחות.':'');
 // state
 let st='';if(s.stop>0)st=pill('עצור (STOP)','bad');else if(s.calibrating)st=pill('מכייל…');
 else if(!s.enabled)st=pill('כבוי');
 else if(s.cooldown>0)st=pill('נבחה, מחכה לשקט ('+s.cooldown+' שנ׳)','bad');
 else if(s.burst)st=pill('שומע קול…');
 else if(s.ext)st=pill(({5:'תנועה (מצלמה)',6:'תנועה',7:'קול ברחוב',33:'צלצול בדלת'}[s.ext]||'אירוע')+' בחוץ. אם תישאר שקטה עוד '+s.extLeft+' שנ׳ תקבל חטיף','ok');
 else if(s.mode==2)st=pill('רק מדידה · רושם בלי חטיפים');
 else if(s.mode==3)st=pill('אימון לרעשים · עוצמה '+s.trainVol+'% · היום '+s.tPass+'/'+s.tTrials,'ok');
 else if(s.mode==4)st=pill('פעמון = דבר טוב · עוצמה '+s.bellVol+'% · היום '+s.bellP+'/'+s.bellT+' רגועה'+(s.bgState==1?' · מצלצל…':s.bgState==2?' · מקשיב…':s.bgNext>=0?' · הבא בעוד '+fmtS(s.bgNext):''),'ok');
 else if(s.mode==0)st=s.pending?pill('רעש בחוץ. אם תישאר שקטה תקבל חטיף','ok'):pill('שקט · מחכה לרעש מבחוץ','ok');
 else st=pill('שקט · חטיף הבא בעוד '+fmtS(s.nextAlone),'ok');
 $('state').innerHTML='<p style="margin:8px 0 0">'+st+'</p>';modeHelp();
 // levels
 if(!$('lvBox').contains(document.activeElement))$('lvBox').innerHTML=ENG.map((e,i)=>'<span>'+e[0]+' <span class="mut">('+s.ring[i][0]+'/'+s.ring[i][1]+' רגועה)</span></span><button class="btn" onclick="lvlSet('+i+',-1)" aria-label="פחות">−</button><input type="number" inputmode="numeric" min="1" max="10" step="1" class="num" id="lvIn'+i+'" aria-label="רמה '+e[0]+'" value="'+s.lv[i]+'" onchange="lvlTo('+i+',this.value)"><button class="btn" onclick="lvlSet('+i+',1)" aria-label="יותר">+</button>').join('');
 $('diffMsg').textContent=s.diffMsg||'';
 $('treatWarn').textContent=(s.sinceBark>=0&&s.sinceBark<10)?'היא נבחה לפני '+s.sinceBark+' שניות. כדאי לחכות שתשתוק.':'';
 $('fastStat').textContent=s.staged?'חטיף מהיר מוכן'+(s.lat?' · אחרון: '+(s.lat/1000).toFixed(1)+' שנ׳ מהקליק':''):(s.lat?'חטיף אחרון: '+(s.lat/1000).toFixed(1)+' שנ׳ מהקליק':'');
 $('barkStat').innerHTML=s.barkWin>0?'<span style="color:var(--bad)">נבחה '+s.barkWin+' פעמים</span> ב-'+s.barkWinMin+' הדקות האחרונות':'<span style="color:var(--ok)">לא נבחה</span> ב-'+s.barkWinMin+' הדקות האחרונות';
 $('outStat').textContent=s.outdoorAge>=0?('יחידה חיצונית: '+(s.outdoorAge<90?'מחוברת':'לא נשמעה '+fmtS(s.outdoorAge))+(s.outdoorLevel>0?' · רחוב '+s.outdoorLevel.toFixed(0)+' dB':'')):'יחידה חיצונית: עוד לא נשמעה';
 $('stopBox').style.display=s.stop>0?'block':'none';$('stopLeft').textContent=fmtS(s.stop);
 $('payBox').style.display=s.payHand?'block':'none';
 $('emptyBox').style.display=s.outOfTreats?'block':'none';
 $('cleanBox').style.display=s.cleaning?'block':'none';if(s.cleaning)$('cleanTxt').textContent=s.cleanSt?'הגלגלים מתרוקנים…':'המנוע משוחרר, אפשר להוציא את הגלגלים.';
 $('dropStat').textContent=(cfg.irFitted?'חיישן מגלשה: '+(s.ir?'חסום או חטיף עובר':'פנוי'):'חיישן מגלשה: כבוי')+(s.jams?' · תקיעות היום: '+s.jams:'')+(s.disp?' · מוציא חטיף…':'');
 $('treatBtn').disabled=s.mode==2||s.cleaning;
 $('voiceStat').textContent=(s.spkOk?'':'הרמקול לא אותחל · ')+(s.fs?'':'אין זיכרון קבצים · ')+(s.hasVoice?'יש הקלטה שלך':'עוד אין הקלטה. בלי הקלטה יש רק קליק.');
 $('trainStat').innerHTML='<p>'+(s.mode==3?pill('פעיל · היום '+s.tPass+'/'+s.tTrials+' הצלחות'+(s.tState==1?' · משמיע…':s.tState==2?' · מקשיב…':s.tNext>=0?' · ניסיון הבא בעוד '+fmtS(s.tNext):''),'ok'):pill('כבוי · כדי להתחיל בחר "אימון לרעשים" במסך הראשי'))+'</p>';
 $('bellStat').innerHTML='<p>'+(s.mode==4?pill('פעיל · היום '+s.bellP+'/'+s.bellT+' רגועה · עוצמה '+s.bellVol+'%','ok'):pill('כבוי · כדי להתחיל בחר "פעמון = דבר טוב" במסך הראשי'))+'</p>';
 $('foot').textContent='תוכנה 2.9.9 · פעיל '+fmtS(s.uptime);if(NC>=4){NC=0;dgLast='';renderDiag()}else NC=0}).catch(()=>{$('sub').textContent='אין חיבור למתקן…';if(++NC==4){dgLast='';renderDiag()}})}
const TN=['נביחה','רעש בחדר','חטיף (אוטומטי)','חטיף (ידני)','קול חזק וארוך','תנועה (מצלמה)','תנועה (חיישן)','קול ברחוב','חטיף: שקטה אחרי אירוע בחוץ','נבחה אחרי אירוע בחוץ, אין חטיף','אירוע בחוץ, דילוג (צינון)','תקיעה: החטיף לא נפל','נגמרו החטיפים?','נפלו 2 חטיפים','אימון: הושמע צליל','אימון: שקטה ← חטיף','אימון: נבחה ← אין חטיף','חיישן מגלשה חסום','מילאתי חטיפים','לא בטוח, בלי חטיף','נביחה הוקלטה (למד את הכלב)','סימנת: לא היה נביחה','סימנת: כן נביחה','ארוחה','','','','STOP','חטיף מהיר: השקע היה ריק בקליק','רמת קושי השתנתה','פעמון טוב: צלצול','פעמון טוב: רגועה ← חטיף','פעמון טוב: נבחה ← אין חטיף','צלצלו בדלת (סימנת)','משקל נשמר','הקליק לא שולם: תן ביד'];
const DOT={0:'b',4:'b',9:'b',16:'b',19:'b',32:'b',2:'t',3:'t',8:'t',15:'t',31:'t',23:'t',11:'b',12:'b',27:'b',35:'b'},SRC={5:'מצלמה',6:'חיישן',7:'רחוב',33:'פעמון'};
function loadStats(){fetch('/api/stats').then(r=>r.json()).then(d=>{draw(d.barks,d.treats);
 $('hist').innerHTML=d.hist.length?d.hist.map(h=>{const s=String(h[0]);return s.slice(6)+'/'+s.slice(4,6)+': '+h[1]+' נביחות, '+h[2]+' חטיפים'}).join('<br>'):'אין עדיין';
 $('log').innerHTML=d.log.filter(e=>!$('onlyBarks').checked||[0,4,9,16,19,32].includes(e[1])).map(e=>{let t;if(d.clock&&e[0]>1e9){const x=new Date(e[0]*1000);t=x.toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}else t=fmtS(e[0]);
 return '<div><span class="dot '+(DOT[e[1]]||'')+'"></span>'+t+' · '+(TN[e[1]]||('אירוע '+e[1]))+(e[1]<2||e[1]==4||e[1]==7||e[1]==19?' (+'+e[2].toFixed(0)+' dB)':'')+(e[3]!=null&&e[3]<=100&&e[1]!=29&&e[1]!=28?(e[1]==7?' · כלב נובח בחוץ? '+e[3]+'%':' · ביטחון '+e[3]+'%'):'')+(e[1]==20?' ('+e[2].toFixed(0)+' נביחות)':'')+(e[1]==14||e[1]==30?' ('+e[2].toFixed(0)+'%)':'')+(e[1]==23?' ('+e[2].toFixed(0)+' גרם)':'')+(e[1]==34?' ('+e[2].toFixed(1)+' ק״ג)':'')+(e[1]==29?' ('+(ENG[e[3]]||['?'])[0]+' → '+e[2].toFixed(0)+')':'')+(e[1]==28?' (זווית '+e[2].toFixed(0)+'%)':'')+(e[1]>=8&&e[1]<=10&&SRC[e[2]]?' · '+SRC[e[2]]:'')+'</div>'}).join('')||'<div>אין אירועים עדיין</div>'})}
const C={bad:'#3F5A78',ok:'#2D6A43',acc:'#3E6B52',ink:'#1F3B2D',mut:'#4E5F55',lt:'#F4A988',gr:'#B9C2B5',pink:'#9DB0C6'};
function draw(b,t){const c=$('ch'),x=c.getContext('2d'),W=c.width,H=c.height;x.clearRect(0,0,W,H);
 const mx=Math.max(4,...b,...t),bw=W/24;x.font='11px sans-serif';
 for(let h=0;h<24;h++){const X=h*bw,bh=b[h]/mx*(H-22),th=t[h]/mx*(H-22);
  x.fillStyle=C.bad;x.fillRect(X+2,H-16-bh,bw/2-2,bh);x.fillStyle=C.ok;x.fillRect(X+bw/2,H-16-th,bw/2-2,th);
  if(h%3==0){x.fillStyle=C.mut;x.fillText(h,X+4,H-3)}}}
let live=false,camT=null;
function camBase(){return 'http://'+cfg.camHost}
function camErr(){if(!$('camImg').getAttribute('src'))return;camImgOk=false;$('camNote').innerHTML='אין תמונה מהמצלמה. <a href="#diag" onclick="tab(5);return false">למה?</a>'}
function camOk(){if(camImgOk===false&&!live)$('camNote').textContent='תמונה מתעדכנת כל 3 שניות';camImgOk=true}
function camSetup(){if(!cfg.camHost){$('camCard').style.display='none';return}$('camCard').style.display='block';if(!live&&!camT){snap();camT=setInterval(snap,3000)}}
function snap(){if(!live)$('camImg').src=camBase()+'/jpg?t='+Date.now()}
function toggleLive(){live=!live;if(live){clearInterval(camT);camT=null;$('camImg').src=camBase()+':81/stream';$('liveBtn').textContent='עצור שידור';$('camNote').textContent='שידור חי'}else{$('camImg').src='';$('liveBtn').textContent='שידור חי';$('camNote').textContent='תמונה מתעדכנת כל 3 שניות';camSetup()}}
// ---------- progress
let D=[],RANGE=14;
// day row: [key,barks,episodes,triggers,reactions,treats,calmSumS,calmN,quietMaxS,jams,doubles,tTrials,tPass,modeMask,tVol,
//           treatDg,mealG,trigDoor,reactDoor,passDoor,trigNoise,reactNoise,passNoise,trigMotion,reactMotion,passMotion,bellT,bellP,aloneTry,alonePass,lvA,lvD,lvN,lvM,spills]
function loadDays(){fetch('/api/days').then(r=>r.json()).then(d=>{D=d.days;D.today=d.today;renderProg()}).catch(()=>{$('verdict').textContent='אין חיבור'})}
function setRange(n){RANGE=n;$('r14').className=n==14?'on':'';$('r30').className=n==30?'on':'';renderProg()}
function dd(k){k=String(k);return k.slice(6)+'/'+k.slice(4,6)}
function avg(a){return a.length?a.reduce((x,y)=>x+y,0)/a.length:0}
function renderProg(){
 const full=D.filter(r=>r[0]!=D.today),n=full.length;let v,sub;$('verdict').style.color='#fff';
 if(n<7){v='צריך עוד ימים';sub='יש '+n+' ימים מלאים מתוך 7. ההשוואה תופיע אחרי שבוע (מומלץ שבוע ראשון במצב "רק מדידה").'}
 else{const f=avg(full.slice(0,7).map(r=>r[1])),l=avg(full.slice(-7).map(r=>r[1]));
  const p=f<0.5?0:Math.round((l-f)/f*100);
  if(f>=0.5&&p<=-15){v='משתפרת: '+(-p)+'% פחות נביחות';$('verdict').style.color='#F4A988'}
  else if((f>=0.5&&p>=15)||(f<0.5&&l>3)){v='מחמירה: '+(f<0.5?'':p+'% ')+'יותר נביחות';$('verdict').style.color='#BFD0E4'}
  else v='יציבה';
  sub='ממוצע '+l.toFixed(1)+' נביחות ליום ב-7 הימים האחרונים, מול '+f.toFixed(1)+' ב-7 הימים הראשונים'+(n<14?' (חלק מהימים חופפים, ההשוואה תתחדד עם הזמן)':'')+'.'}
 $('verdict').textContent=v;$('verdictSub').textContent=sub;
 const R=D.slice(-RANGE),sum=i=>R.reduce((x,r)=>x+(r[i]||0),0);
 const trig=sum(3),re=sum(4),cn=sum(7),cs=sum(6),qm=Math.max(0,...R.map(r=>r[8]));
 $('kpi').innerHTML='<div><b>'+(R.length?(sum(1)/R.length).toFixed(1):'–')+'</b>נביחות ליום</div><div><b>'+(R.length?(sum(2)/R.length).toFixed(1):'–')+'</b>התקפים ליום</div>'+
  '<div><b>'+(trig?Math.round(re*100/trig)+'%':'–')+'</b>תגובה לאירועים ('+re+'/'+trig+')</div><div><b>'+(cn?Math.round(cs/cn)+' שנ׳':'–')+'</b>זמן הרגעה ממוצע</div>'+
  '<div><b>'+(qm?fmtS(qm):'–')+'</b>רצף שקט הכי ארוך לבד</div><div><b>'+sum(5)+'</b>חטיפים'+(sum(9)?' · '+sum(9)+' תקיעות':'')+'</div>'+
  '<div><b>'+(R.length?Math.round(sum(15)/10/R.length):'–')+' ג׳</b>חטיפים ליום</div><div><b>'+(sum(26)?Math.round(sum(27)*100/sum(26))+'%':'–')+'</b>פעמון טוב: רגועה ('+sum(27)+'/'+sum(26)+')</div>';
 const T=[['פעמון',17],['רעש ורחוב',20],['תנועה',23]];
 $('trigT').innerHTML='<tr><th>טריגר</th><th>פעמים</th><th>נבחה</th><th>הרוויחה</th></tr>'+T.map(t=>{const a=sum(t[1]),b=sum(t[1]+1),c=sum(t[1]+2);return '<tr><td>'+t[0]+'</td><td class="num">'+a+'</td><td class="num">'+(a?Math.round(b*100/a)+'%':'–')+'</td><td class="num">'+c+'</td></tr>'}).join('');
 bars('cB',R,[[r=>r[1],C.bad],[r=>r[2],C.pink]]);
 bars('cR',R,[[r=>r[3]?Math.round(r[4]*100/r[3]):0,C.acc]],100);
 bars('cC',R,[[r=>r[7]?Math.round(r[6]/r[7]):0,C.ink]]);
 bars('cG',R,[[r=>Math.round((r[15]||0)/10),C.acc]],0,(cfg.dailyFoodG||300)*0.1);
 bars('cT',R,[[r=>Math.round(r[8]/60),C.ink]]);
 bars('cL',R,[[r=>r[30]||0,C.ink],[r=>r[31]||0,C.acc],[r=>r[32]||0,C.lt],[r=>r[33]||0,C.gr]],10);
}
function bars(id,R,series,fixMax,ref){const c=$(id),x=c.getContext('2d'),W=c.width,H=c.height;x.clearRect(0,0,W,H);
 x.font='11px sans-serif';if(!R.length){x.fillStyle=C.mut;x.fillText('אין עדיין נתונים',W/2-40,H/2);return}
 const vals=series.map(s=>R.map(s[0])),mx=fixMax||Math.max(4,ref||0,...vals.flat()),n=RANGE,bw=W/n,sw=(bw-3)/series.length;
 x.fillStyle=C.mut;x.fillText(String(Math.round(mx)),2,10);
 if(ref){const y=H-16-ref/mx*(H-26);x.fillStyle=C.gr;x.fillRect(0,y,W,1.5)}
 R.forEach((r,i)=>{const X=W-(R.length-i)*bw;series.forEach((s,j)=>{const h=vals[j][i]/mx*(H-26);x.fillStyle=s[1];x.fillRect(X+1+j*sw,H-16-h,sw,h)});
  if(n<=14||i%3==0){x.fillStyle=C.mut;x.fillText(dd(r[0]),X+1,H-3)}})}
// ---------- weight
function loadW(){fetch('/api/weight').then(r=>r.json()).then(w=>{W=w;wRender()}).catch(()=>{})}
function kd(k){k=String(k);return new Date(+k.slice(0,4),+k.slice(4,6)-1,+k.slice(6))}
function wSave(){const kg=parseFloat($('wKg').value);if(!(kg>1&&kg<150)){toast('הקלד משקל בק״ג');return}
 const d=$('wDate').value.replace(/-/g,'');post('/api/weight','kg='+kg+(d?'&date='+d:'')).then(w=>{if(w.list){W=w;wRender();toast('נשמר')}else toast(WERR[w.error]||'לא נשמר: '+(w.error||'המתקן לא אישר'))}).catch(()=>toast('לא נשמר. '+NOCONN))}
const WERR={'no file system':'לא נשמר: זיכרון הקבצים של המתקן לא עובד. ראה "מה לא עובד?"','bad weight or date (clock not set?)':'לא נשמר: המשקל או התאריך לא תקינים. לא בחרת תאריך? השעון של המתקן עוד לא מסונכרן, אז בחר תאריך ידנית'};
function wDel(k){if(confirm('למחוק את השקילה מ-'+dd(k)+'?'))post('/api/weight','del='+k).then(w=>{W=w;wRender()})}
function wRender(){const L=W.list||[],t=W.target||25;$('wTarget').textContent=t.toFixed(1)+' ק״ג';
 if(!busy('targetKg'))$('targetKg').value=t;
 if(!$('wDate').value){const n=new Date();$('wDate').value=n.getFullYear()+'-'+String(n.getMonth()+1).padStart(2,'0')+'-'+String(n.getDate()).padStart(2,'0')}
 if(!L.length){$('wNow').textContent='--';$('wSub').textContent='עוד אין שקילות';$('wTrend').textContent='';$('wList').textContent='אין עדיין';wDraw([],t);return}
 const last=L[L.length-1];$('wNow').textContent=last[1].toFixed(1);$('wSub').textContent='ק״ג · '+dd(last[0])+' · עוד '+Math.max(0,last[1]-t).toFixed(1)+' ק״ג ליעד';
 let tr='';const old=L.filter(r=>(kd(last[0])-kd(r[0]))/864e5>=6);
 if(old.length){const o=old[old.length-1],wk=(kd(last[0])-kd(o[0]))/864e5/7,ch=(last[1]-o[1])/wk;
  tr=(ch<=0?'יורדת ':'עולה ')+Math.abs(ch).toFixed(2)+' ק״ג בשבוע (מאז '+dd(o[0])+').';
  if(-ch>last[1]*0.02)tr+=' זה מהר מדי: כדאי להוסיף קצת אוכל ולשאול וטרינר.';
  else if(ch<0&&last[1]>t){const w=(last[1]-t)/-ch;tr+=' בקצב הזה: יעד בעוד בערך '+Math.ceil(w)+' שבועות.'}}
 else tr='צריך שתי שקילות בהפרש של שבוע לפחות כדי לראות קצב.';
 $('wTrend').textContent=tr;
 $('wList').innerHTML='<table class="t"><tr><th>תאריך</th><th>ק״ג</th><th></th></tr>'+L.slice().reverse().map(r=>'<tr><td>'+dd(r[0])+'/'+String(r[0]).slice(2,4)+'</td><td class="num">'+r[1].toFixed(1)+'</td><td><button class="btn" onclick="wDel('+r[0]+')">מחק</button></td></tr>').join('')+'</table>';
 wDraw(L,t)}
function wDraw(L,t){const c=$('cW'),x=c.getContext('2d'),Wd=c.width,H=c.height;x.clearRect(0,0,Wd,H);x.font='11px sans-serif';
 const vs=L.map(r=>r[1]).concat([t]),lo=Math.floor(Math.min(...vs)-1),hi=Math.ceil(Math.max(...vs)+1),y=v=>H-18-(v-lo)/(hi-lo)*(H-30);
 x.fillStyle=C.mut;x.fillText(hi+' ק״ג',Wd-44,12);x.fillText(lo+' ק״ג',Wd-44,H-20);
 x.strokeStyle=C.ok;x.setLineDash([6,4]);x.beginPath();x.moveTo(0,y(t));x.lineTo(Wd,y(t));x.stroke();x.setLineDash([]);x.fillStyle=C.ok;x.fillText('יעד '+t,4,y(t)-4);
 if(!L.length){x.fillStyle=C.mut;x.fillText('אין עדיין שקילות',Wd/2-40,H/2);return}
 const t0=kd(L[0][0]),t1=kd(L[L.length-1][0]),span=Math.max(1,(t1-t0)/864e5),X=k=>Wd-12-((kd(k)-t0)/864e5)/span*(Wd-60);
 x.strokeStyle=C.acc;x.lineWidth=2;x.beginPath();L.forEach((r,i)=>{i?x.lineTo(X(r[0]),y(r[1])):x.moveTo(X(r[0]),y(r[1]))});x.stroke();x.lineWidth=1;
 x.fillStyle=C.acc;L.forEach(r=>{x.beginPath();x.arc(X(r[0]),y(r[1]),3.5,0,7);x.fill()});
 x.fillStyle=C.mut;x.fillText(dd(L[0][0]),Wd-40,H-3);if(L.length>1)x.fillText(dd(L[L.length-1][0]),4,H-3)}
// ---------- recording
// Chrome only allows the microphone on https pages. dogtreat.local is http, so the page tries the
// direct recorder first and falls back to the phone's own recorder app (file input with capture).
let mr=null,chunks=[];
async function rec(slot){
 const lim=slot=='voice'?5:4;
 if(mr){mr.stop();return}
 if(!(window.isSecureContext&&navigator.mediaDevices&&window.MediaRecorder)){
  const i=document.createElement('input');i.type='file';i.accept='audio/*';i.setAttribute('capture','');i.onchange=()=>pickFile(i,slot);i.click();
  $('recNote').textContent='הדפדפן לא מאפשר מיקרופון בדף לא מאובטח, אז נפתחת אפליקציית ההקלטה של הטלפון. הקלט, שמור, והקובץ יעלה לבד.';return}
 try{const st=await navigator.mediaDevices.getUserMedia({audio:true});chunks=[];mr=new MediaRecorder(st);
  mr.ondataavailable=e=>chunks.push(e.data);
  mr.onstop=()=>{st.getTracks().forEach(t=>t.stop());const b=new Blob(chunks,{type:mr.mimeType});mr=null;if(slot=='voice')$('recBtn').textContent='הקלט "כלבה טובה" (עד 5 שנ׳)';upload(b,slot)};
  mr.start();if(slot=='voice')$('recBtn').textContent='עצור הקלטה';toast('מקליט… דבר עכשיו');setTimeout(()=>{if(mr)mr.stop()},lim*1000)}
 catch(e){toast('אין גישה למיקרופון')}}
function pickFile(inp,slot){if(inp.files&&inp.files[0])upload(inp.files[0],slot)}
async function toWav(blob,maxS){const AC=window.AudioContext||window.webkitAudioContext,ac=new AC();
 const buf=await ac.decodeAudioData(await blob.arrayBuffer());if(ac.close)ac.close();
 const SR=16000,n=Math.min(Math.ceil(buf.duration*SR),maxS*SR),oc=new OfflineAudioContext(1,n,SR),src=oc.createBufferSource();
 src.buffer=buf;src.connect(oc.destination);src.start();const d=(await oc.startRendering()).getChannelData(0);
 let pk=0;for(const v of d)pk=Math.max(pk,Math.abs(v));const th=pk*0.05;let a=0,b=d.length-1;while(a<b&&Math.abs(d[a])<th)a++;while(b>a&&Math.abs(d[b])<th)b--;
 a=Math.max(0,a-800);b=Math.min(d.length-1,b+1600);const g=pk>0?0.9/pk:1,N=b-a+1,ab=new ArrayBuffer(44+N*2),w=new DataView(ab);
 const s=(o,t)=>{for(let i=0;i<t.length;i++)w.setUint8(o+i,t.charCodeAt(i))};s(0,'RIFF');w.setUint32(4,36+N*2,true);s(8,'WAVE');s(12,'fmt ');
 w.setUint32(16,16,true);w.setUint16(20,1,true);w.setUint16(22,1,true);w.setUint32(24,SR,true);w.setUint32(28,SR*2,true);w.setUint16(32,2,true);w.setUint16(34,16,true);s(36,'data');w.setUint32(40,N*2,true);
 for(let i=0;i<N;i++){const v=Math.max(-1,Math.min(1,d[a+i]*g));w.setInt16(44+i*2,v*32767,true)}
 return {wav:new Blob([ab],{type:'audio/wav'}),sec:N/SR}}
async function upload(blob,slot){try{toast('ממיר…');const r=await toWav(blob,slot=='voice'?5:4);const fd=new FormData();fd.append('f',r.wav,slot+'.wav');
 const res=await fetch('/api/sound?slot='+slot,{method:'POST',body:fd});const j=await res.json();
 toast(j.ok?'נשמר ('+r.sec.toFixed(1)+' שנ׳)':(S.fs===false?'לא נשמר: זיכרון הקבצים של המתקן לא עובד':'לא נשמר: הקובץ גדול מדי למתקן. נסה הקלטה קצרה יותר'));if(j.ok)post('/api/play','slot='+slot)}catch(e){toast('לא הצלחתי לקרוא את הקובץ')}}
// ---------- bark recognition
const VN=['<span class="vb">נביחה</span>','<span class="vn">רעש (לא נביחה)</span>','<span class="vm">לא בטוח · בלי חטיף</span>','<span class="vb">נביחה רצופה (חזק וארוך)</span>','<span class="vb">הוקלטה כנביחה שלה</span>'];
let BM={};
function bml(a){post('/api/bark-learn','action='+a).then(d=>{BM=d;renderBursts();toast('בוצע')})}
function learn(){bml(BM.learn>=0?'stop':'start')}
function label(id,b){post('/api/bark-label','id='+id+'&bark='+b).then(d=>{BM=d;renderBursts();toast(b?'נוסף לנביחות שלה':'נוסף לרשימת "לא נביחה"')}).catch(()=>toast('האירוע כבר לא ברשימה'))}
function loadBursts(){fetch('/api/bursts').then(r=>r.json()).then(d=>{BM=d;renderBursts()}).catch(()=>{})}
function renderBursts(){const d=BM;if(!d.list)return;renderAsk();
 $('bmStat').innerHTML=(d.tplN>=d.tplMin?'מכויל לכלב שלך: '+d.tplN+' נביחות':'משתמש בהגדרות ברירת המחדל (עוד לא הקלטת נביחה)')+(d.negN?' · '+d.negN+' דוגמאות "לא נביחה"':'');
 const L=$('learnBtn');if(d.learn>=0){L.textContent='סיים הקלטה';$('learnStat').textContent='מקליט… '+d.learn+' שנ׳ · נקלטו '+d.learnN+' נביחות'}
 else{L.textContent='הקלט נביחה';$('learnStat').textContent=d.learnMsg=='saved'?'נשמר':d.learnMsg=='few'?'נקלטו רק '+d.learnN+', צריך לפחות '+d.tplMin+'. נסה שוב':''}
 $('bursts').innerHTML=d.list.length?d.list.map(e=>{let t;if(d.clock&&e.t>1e9){t=new Date(e.t*1000).toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}else t=fmtS(e.t);
  const conf=e.v==1?100-e.p:e.p;
  const fix=e.fixed==1?' <span class="mut">סומן: לא נביחה</span>':e.fixed==2?' <span class="mut">סומן: נביחה</span>':
   (e.v==1?'<button class="btn" onclick="label('+e.id+',1)">זו כן נביחה</button>':'<button class="btn" onclick="label('+e.id+',0)">זה לא היה נביחה</button>');
  return '<div class="bv"><div class="row"><span>'+VN[e.v]+' · '+conf+'%</span><span class="mut">'+t+'</span></div><div class="row"><span class="mut"><bdi dir="ltr">+'+e.db.toFixed(0)+' dB · '+e.ms+' ms</bdi>'+(e.rep?' · ברצף של '+(e.rep+1):'')+'</span>'+fix+'</div>'+
   '<details><summary>features</summary>'+d.names.map((n,i)=>n+'='+e.f[i]).join(' · ')+'</details></div>'}).join(''):'אין עדיין. קולות חזקים יופיעו כאן עם ההחלטה.'}

// ---- v2.9.6 help: button spinner -> success / shake (every action button that calls post())
let lastBtn=null,lastBtnT=0;document.addEventListener('pointerdown',e=>{const b=e.target.closest&&e.target.closest('button');if(b){lastBtn=b;lastBtnT=Date.now()}},true);
function busyBtn(){const b=lastBtn;lastBtn=null;if(!b||Date.now()-lastBtnT>800||b.classList.contains('stop')||b.closest('.stp')||b.classList.contains('tb'))return null;b.classList.add('wait');return b}
function doneBtn(b,ok){if(!b)return;b.classList.remove('wait');b.classList.add(ok?'okd':'nod');setTimeout(()=>b.classList.remove('okd','nod'),600)}
const NOCONN='אין חיבור למתקן. בדוק שהטלפון בוויי-פיי של הבית ושהמתקן בחשמל';
const WHY={meal:'יש עכשיו ארוחה. נסה שוב כשהיא תיגמר',cal:'כיול גרמים רץ עכשיו. חכה שיסתיים',treat:'חטיף קודם עוד יוצא. נסה שוב בעוד כמה שניות',
 motor:'המנוע מסובב עכשיו (סנכרון גלגלים או הכנת חטיף מהיר). נסה שוב בעוד כמה שניות',cleaning:'מצב ניקוי פעיל, אז אין חטיפים וארוחות. סיימת? "סיימתי לנקות"',
 emptying:'הגלגלים מתרוקנים עכשיו. חכה שיסתיימו',busy:'המתקן עסוק כרגע. נסה שוב בעוד כמה שניות'};
function whyTxt(r,dflt){return r.measure?'במצב "רק מדידה" לא נותנים חטיפים. אפשר להחליף מצב בכרטיס "מצב"':r.cleaning&&!r.why?WHY.cleaning:(WHY[r.why]||dflt||WHY.busy)}
// ---- v2.9.6 help: "what is not working" diagnostics (/api/diag + /api/status; every rule is explained in NOTES)
let NC=0,DG=null,DGerr=0,camProbe=null,camImgOk=null,dgLast='';
function loadDiag(cam){const b=cam?busyBtn():null;if(cam&&cfg.camHost)$('dgSub').textContent='בודק גם את המצלמה (עד 5 שניות)…';
 return fetch('/api/diag'+(cam&&cfg.camHost?'?cam=1':'')).then(r=>r.json()).then(d=>{DG=d;DGerr=0;if(d.cam&&d.cam.probe)camProbe=d.cam.probe;doneBtn(b,true);renderDiag()})
 .catch(()=>{DGerr++;doneBtn(b,false);renderDiag()})}
function ago(s){return s>=3600?Math.floor(s/3600)+' שע׳':s>=120?Math.floor(s/60)+' דק׳':s+' שנ׳'}
const Lr=t=>'\u2066'+t+'\u2069';
function diagEval(){const d=DG,s=S||{},P=[],OK=[],INF=[];
 const add=(sev,t,why,todo,btn)=>P.push({sev,t,why,todo:todo||[],btn});
 if(!d||NC>=4){if(DGerr||NC>=4)add('bad','אין חיבור למתקן','הטלפון לא מקבל תשובה מהמתקן. או שהמתקן כבוי, או שהטלפון לא באותו וויי-פיי.',['בדוק שהמתקן מחובר לחשמל','בדוק שהטלפון מחובר לוויי-פיי של הבית (לא לנתונים סלולריים)','רענן את הדף','עדיין לא? נתק את המתקן מהחשמל, חבר שוב וחכה דקה']);return {P,OK,INF}}
 const wifiTodo=['קרב את המתקן לראוטר (או את הראוטר למתקן)','אפשר גם מגדיל טווח (Extender)','לחץ "בדוק שוב"'];
 if(d.rssi<=-80)add('warn','הוויי-פיי חלש מאוד ('+Lr(d.rssi+' dBm')+')','המתקן רחוק מהראוטר או שיש קירות בדרך. הדף נטען לאט ומתנתק, והתראות לא תמיד מגיעות.',wifiTodo);
 else if(d.rssi<=-72)add('warn','הוויי-פיי חלש ('+Lr(d.rssi+' dBm')+')','המתקן די רחוק מהראוטר. לפעמים הדף יתקע או יתנתק.',wifiTodo);
 else OK.push('וויי-פיי: '+(d.rssi>-60?'חזק':'בסדר')+' ('+Lr(d.rssi+' dBm')+')'+(d.ssid?' · '+Lr(d.ssid):''));
 if(!d.clock){if(d.up<90)INF.push('השעון מסתנכרן מהאינטרנט (כמה שניות אחרי הדלקה)');
  else add('warn','השעון לא מסונכרן','המתקן לוקח את השעה מהאינטרנט ועוד לא הצליח. בלי שעה אין ארוחות לפי שעון, אין סיכום שבועי, והגרפים לפי שעה לא מדויקים.',['בדוק שיש אינטרנט בבית (נסה אתר בטלפון)','נתק את המתקן מהחשמל וחבר שוב','חכה דקה ולחץ "בדוק שוב"'])}
 else OK.push('שעון: מסונכרן');
 const micW=['נתק את המתקן מהחשמל','חוט SCK של המיקרופון: לבורג 26','חוט WS: לבורג 25','חוט SD: לבורג 33','VDD: למחבר 3V3','GND ו-L/R: ל-GND','חבר לחשמל ולחץ "בדוק שוב" אחרי דקה'];
 if(!d.mic.init)add('bad','המיקרופון לא הופעל','הלוח לא הצליח להפעיל את המיקרופון (INMP441) בהדלקה. בלי מיקרופון המתקן לא שומע נביחות ורעשים.',micW);
 else if(d.mic.win<0)INF.push('מיקרופון: נבדק בדקה הראשונה אחרי הדלקה');
 else if(d.mic.win==0)add('bad','לא מגיע קול מהמיקרופון','בדקה האחרונה לא הגיע שום מידע מהמיקרופון. כנראה חוט SCK או WS לא מחובר, או שאין לו חשמל.',micW);
 else if(d.mic.zero>=d.mic.win*0.9)add('bad','המיקרופון שולח רק אפסים','המידע מגיע אבל הוא ריק. כנראה חוט הנתונים SD (בורג 33) לא מחובר, או שהמיקרופון לא מקבל 3V3.',micW);
 else if(d.mic.same>=d.mic.win*0.9)add('warn','המיקרופון תקוע על אותו ערך','המיקרופון שולח את אותו מספר כל הזמן, כאילו הוא לא שומע כלום. כנראה חוט רופף או מיקרופון פגום.',micW);
 else OK.push('מיקרופון: שומע ('+Math.round(d.mic.db)+' dB עכשיו)');
 const ir=d.ir;
 if(!ir.fit)INF.push('חיישן הנפילה כבוי בהגדרות. ככה המתקן לא יודע אם חטיף באמת נפל (אין זיהוי של תקיעה או מיכל ריק). חיברת חיישן IR לבורג 32? "הגדרות" ← "חיישן IR במגלשה מחובר" ← "שמור הגדרות"');
 else{
  if(ir.blocked&&ir.blockedS>=30)add('bad','חיישן הנפילה חסום כל הזמן','החיישן במגלשה (FC-51, בורג 32) רואה משהו מולו כבר '+ago(ir.blockedS)+'. חטיף תקוע, לכלוך על החיישן, או שהוא רגיש מדי ורואה את הקיר של המגלשה. כשהוא חסום המתקן לא יכול לספור חטיפים.',
   ['לחץ STOP','הסתכל במגלשה: יש חטיף תקוע? הוצא אותו','נגב את שתי העיניים של החיישן','הנורה על החיישן עדיין דולקת? סובב את הבורג הקטן על החיישן לאט נגד כיוון השעון עד שהיא כבה','לחץ "בדוק שוב"']);
  if(ir.emptyT)add('bad','נגמרו החטיפים או שהגלגל תקוע','היו '+ir.after+' ניסיונות ברצף בלי שחיישן הנפילה ראה חטיף. עד שתלחץ "מילאתי" אין חטיפים אוטומטיים.',
   ['מלא חטיפים בצד TREATS (שמאל)','יש חטיפים? הם אולי גדולים מדי לשקע, או שהגלגל תקוע: "ארוחות וכיול" ← "התחל ניקוי" ובדוק את הגלגל','לחץ "מילאתי"'],['מילאתי','/api/refilled','מעולה, ממשיכים']);
  else if(ir.streak>0&&!(ir.seen==0&&ir.miss>0))add('warn','חטיף לא נפל לאחרונה',ir.streak+' ניסיונות ברצף בלי שחיישן הנפילה ראה חטיף. אחרי '+ir.after+' המתקן יחשוב שהמיכל ריק.',['בדוק שיש חטיפים בצד TREATS (שמאל)','בדוק שהגלגל מסתובב: "זרוק חטיף" והסתכל']);
  if(!ir.emptyT&&ir.seen==0&&ir.miss>0)add('bad','חיישן הנפילה עוד לא ראה אף חטיף','מאז ההדלקה היו '+ir.miss+' ניסיונות והחיישן לא ראה אף נפילה. או שהמיכל ריק, או שהחיישן לא מחובר או לא מכוון למגלשה.',
   ['בדוק שיש חטיפים','"בדיקת חיבורים" ← חיישן נפילה: שים אצבע מול החיישן ובדוק שהוא מגיב','חוטי החיישן: OUT לבורג 32','VCC: למחבר 3V3','GND: ל-GND']);
  if(ir.emptyF)add('bad','צד האוכל ריק או תקוע','בארוחה האחרונה חיישן הנפילה לא ראה אוכל נופל, אז הארוחה נעצרה.',['מלא אוכל בצד ימין (F)','לחץ "מילאתי"','בדוק את גלגל האוכל: "ארוחות וכיול" ← "התחל ניקוי"'],['מילאתי','/api/refilled','מעולה, ממשיכים']);
  if(!(ir.blocked&&ir.blockedS>=30)&&!ir.emptyT&&!ir.streak&&!(ir.seen==0&&ir.miss>0)){
   if(ir.seen>0)OK.push('חיישן נפילה: ראה '+ir.seen+' נפילות מאז ההדלקה');else INF.push('חיישן נפילה: עוד לא היה חטיף מאז ההדלקה, אז אי אפשר לדעת אם הוא עובד. אחרי החטיף הראשון זה יופיע כאן');}
  if(ir.jams>0&&!ir.streak&&!ir.emptyT)INF.push('היו היום '+ir.jams+' תקיעות (חטיף לא נפל), ואחר כך זה עבד שוב');}
 const p=d.pir;
 if(p.on){if(p.high&&p.highS>=300)add('warn','חיישן התנועה בבית דולק כל הזמן','החיישן (HC-SR501, בורג 27) מראה תנועה כבר '+ago(p.highS)+' בלי הפסקה. בדרך כלל: הוא מכוון לחלון, למזגן או לשמש, או שבורר הזמן שלו על הכי ארוך.',
   ['סובב את החיישן מהחלון ומהמזגן','על החיישן: סובב את הבורג Tx (זמן) נגד כיוון השעון עד הסוף','אין לך חיישן כזה? "הגדרות" ← בטל "חיישן תנועה / מצלמה" ← "שמור הגדרות"']);
  else if(p.rises==0)INF.push('חיישן תנועה בבית: לא ראה תנועה מאז ההדלקה. זה בסדר אם לא חיברת אותו (הוא לא חובה)');
  else OK.push('חיישן תנועה בבית: ראה '+p.rises+' תנועות מאז ההדלקה');}
 const o=d.out;
 if(o.on){
  if(o.bad>0||(o.age<0&&o.badAll>0))add('bad','היחידה החיצונית משדרת עם קוד שונה','היחידה שולחת "token" שונה מזה שבהגדרות של המתקן, אז המתקן מתעלם ממנה.',['"הגדרות" ← "קוד סודי (token, לא חובה)"','מחק אותו (שדה ריק), או כתוב בדיוק את הקוד שהתקנת ביחידה','לחץ "שמור הגדרות"']);
  else if(o.age<0)INF.push('יחידה חיצונית: עוד לא נשמעה מאז ההדלקה. עוד לא בנית אותה? "הגדרות" ← בטל "מיקרופון חיצוני" והשורה הזו תיעלם');
  else if(o.age>120)add('warn','היחידה החיצונית לא משדרת','היא שולחת "אני כאן" כל 30 שניות, והאחרון הגיע לפני '+ago(o.age)+'. כנראה נגמרה לה הסוללה, או שהיא רחוקה מדי מהמתקן.',['בדוק שיש לה חשמל (סוללה טעונה או כבל USB-C)','קרב אותה לחלון הקרוב למתקן','נתק את הסוללה, חכה 5 שניות וחבר שוב']);
  else OK.push('יחידה חיצונית: מחוברת (נשמעה לפני '+ago(o.age)+')');
  if(o.pir10>=40)add('warn','חיישן התנועה בחוץ מדווח כל הזמן',o.pir10+' תנועות ב-10 הדקות האחרונות. חיישן AM312 שמכוון לכביש, לעצים שזזים או לשמש ישירה "רואה" תנועה כל הזמן.',['כוון את החיישן של היחידה לשביל ולא לכביש','שים את היחידה בצל','או הגדל ב"הגדרות" את "תנועה: התעלמות מחזרה (שניות)"']);
  else if(o.age>=0&&o.age<=120)OK.push('תנועה בחוץ: '+o.pir10+' ב-10 הדקות האחרונות');}
 const sp=d.spk;
 if(sp.fit&&!sp.ok)add('bad','הרמקול לא הופעל','הלוח לא הצליח להפעיל את מגבר הרמקול (MAX98357A). בלי רמקול אין "כלבה טובה" בקול שלך, אין פעמון ואין אימון לרעשים. יש רק קליק בזמזם.',['נתק מהחשמל','חוט BCLK של המגבר: לבורג 14','חוט LRC: לבורג 21','חוט DIN: לבורג 22','VIN: למחבר 5V','GND: ל-GND','חבר לחשמל ובדוק: "בדיקת חיבורים" ← רמקול']);
 else if(!sp.fit&&(d.mode==3||d.mode==4))add('warn','המצב הזה צריך רמקול','"אימון לרעשים" ו"פעמון = דבר טוב" משמיעים צלילים, אבל בהגדרות כתוב שאין רמקול.',['חיברת רמקול? "צלילים" ← סמן "רמקול מחובר"','לא? בחר מצב "בית" או "לבד"']);
 else OK.push(sp.fit?'רמקול: מוכן':'רמקול: מסומן כלא מחובר (יש רק קליק בזמזם)');
 if(!d.fs)add('bad','זיכרון הקבצים לא עובד','המתקן לא הצליח לפתוח את הזיכרון הפנימי (LittleFS). בלי זה אין גרפי התקדמות, אין שקילות, ואין הקלטות שלך.',['נתק מהחשמל וחבר שוב','חוזר? התקן מחדש מאתר ההתקנה עם Erase (זה מוחק גם וויי-פיי והגדרות)']);
 else OK.push('זיכרון קבצים: עובד');
 const host=d.cam.host,cp=camProbe;
 if(!host)INF.push('מצלמה: לא הוגדרה (היא לא חובה). איך מוסיפים: "הוראות" ← "מצלמה"');
 else{const camTodo=['בדוק שהמצלמה מחוברת לחשמל','רואים בטלפון רשת DogCam-Setup? התחבר אליה ובחר את הוויי-פיי של הבית','עדיין לא? חפש באפליקציה של הראוטר את "dogcam" וכתוב את המספר שלו ב"כתובת המצלמה" במקום '+Lr(host)];
  if(cp&&cp.st=='mdns')add('warn','לא מוצא את המצלמה ברשת','כתבת "'+Lr(host)+'" אבל אף מכשיר בוויי-פיי לא ענה לשם הזה. המצלמה כבויה, לא מחוברת לאותו וויי-פיי, או שעוד לא סיימה את ההגדרה.',camTodo);
  else if(cp&&cp.st=='nohttp')add('warn','המצלמה לא עונה','בכתובת '+Lr(cp.ip||host)+' אף אחד לא החזיר תמונה. המצלמה כבויה, נתקעה, או שהכתובת לא נכונה.',['נתק את המצלמה מהחשמל, חכה 5 שניות וחבר שוב','בדוק את "כתובת המצלמה" בהגדרות','לחץ "בדוק שוב"']);
  else if(cp&&cp.st=='http')add('warn','המצלמה ענתה בשגיאה ('+cp.code+')','בכתובת הזו עונה משהו, אבל הוא לא נותן תמונה. אולי זו הכתובת של מכשיר אחר.',['בדוק את "כתובת המצלמה" בהגדרות (בדרך כלל dogcam.local)','נתק את המצלמה מהחשמל וחבר שוב']);
  else if(cp&&cp.st=='notjpg')add('warn','בכתובת הזו אין מצלמה','משהו ענה, אבל מה שחזר הוא לא תמונה. כנראה זו הכתובת של מכשיר אחר בבית.',['בדוק את "כתובת המצלמה" בהגדרות (בדרך כלל dogcam.local)']);
  else if(cp&&cp.st=='ok'&&camImgOk===false)add('warn','המתקן רואה את המצלמה, אבל הטלפון לא','המצלמה עונה למתקן, אבל הטלפון לא מצליח לפתוח את '+Lr(host)+'. בהרבה טלפוני אנדרואיד כתובות כמו '+Lr(host)+' לא נפתחות.',['"הגדרות" ← "כתובת המצלמה": כתוב '+Lr(cp.ip)+' במקום '+Lr(host),'לחץ "שמור הגדרות"']);
  else if(cp&&cp.st=='ok')OK.push('מצלמה: עונה ושולחת תמונה');
  else if(camImgOk===false)add('warn','התמונה מהמצלמה לא נטענת','הטלפון לא מצליח לקבל תמונה מ-'+Lr(host)+'. לחץ "בדוק שוב" כדי שהמתקן יבדוק למה.',camTodo);
  else if(cp&&cp.st=='busy')INF.push('מצלמה: לא נבדקה, המנוע עבד באותו רגע. לחץ "בדוק שוב"');
  else if(camImgOk)OK.push('מצלמה: התמונה נטענת');
  else INF.push('מצלמה: עוד לא נבדקה. לחץ "בדוק שוב"');}
 if(!d.clutch&&!d.motor&&!d.cleaning)add('warn','הגלגלים לא מסונכרנים','המתקן לא בטוח איפה המצמדים של הגלגלים (למשל אחרי ניתוק חשמל באמצע סיבוב). הוא מסנכרן לבד בכל הדלקה.',['נתק את המתקן מהחשמל וחבר שוב','חכה כמה שניות עד שהמנוע מפסיק לזוז']);
 if(d.cleaning)add('warn','מצב ניקוי פעיל',(d.cleanSt?'הגלגלים מתרוקנים עכשיו. ':'המנוע משוחרר ואפשר להוציא את הגלגלים. ')+'בזמן ניקוי אין ארוחות ואין חטיפים.',['מחזירים את מחסנית הגלגלים','לוחצים "סיימתי לנקות" (או לחיצה קצרה על BOOT)'],['סיימתי לנקות','/api/clean-done','חזרנו לעבודה']);
 if(d.stop>0)add('warn','המתקן עצור (STOP)','לחצת STOP. חטיפים אוטומטיים, אימון וארוחות ממתינים עוד '+fmtS(d.stop)+'.',['חכה, זה נגמר לבד','או לחץ "המשך עכשיו"'],['המשך עכשיו','/api/resume','ממשיכים']);
 if(!d.enabled)add('warn','המתקן כבוי','כשהמתקן כבוי אין חטיפים אוטומטיים. "זרוק חטיף" עדיין עובד.',['במסך הראשי לחץ על "המתקן כבוי" כדי להדליק']);
 if(d.payHand)add('warn','קליק לא שולם','המתקן הקליק אבל החטיף לא נפל. היא מחכה לחטיף.',['תן לה חטיף ביד עכשיו','בדוק את גלגל החטיפים'],['נתתי ביד','/api/paid','תודה']);
 if(d.mode==2)INF.push('מצב "רק מדידה": אין חטיפים בכלל, גם לא בכפתור. זה בכוונה');
 if(!d.mealsOn)INF.push('ארוחות אוטומטיות כבויות. להדליק: "ארוחות וכיול" ← "ארוחות אוטומטיות" ← "שמור"');
 if(!d.ntfy)INF.push('התראות לטלפון כבויות (הגדרות ← התראות לטלפון)');
 if(d.heap<20000)add('warn','הזיכרון של הלוח כמעט מלא','המתקן עובד הרבה זמן ונשאר לו מעט זיכרון. זה יכול לגרום לדף להיתקע.',['נתק מהחשמל וחבר שוב']);
 return {P,OK,INF}}
function esc(t){return String(t).replace(/[0-9A-Za-z](?:[0-9A-Za-z.\/:_-]*[0-9A-Za-z])?(?:\s+[0-9A-Za-z](?:[0-9A-Za-z.\/:_-]*[0-9A-Za-z])?)*/g,m=>/[A-Za-z]/.test(m)?'\u0001'+m+'\u0002':m)
 .replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])).replace(/\u0001/g,'<bdi>').replace(/\u0002/g,'</bdi>')}
function renderDiag(){const R=diagEval(),n=R.P.filter(x=>x.sev!='info').length,b=$('hBadge');
 b.className='hbadge'+(n?' bad':'');$('hBadgeT').textContent=(!DG&&DGerr)||NC>=4?'אין חיבור למתקן':!DG?'בודק את החלקים…':n?(n==1?'בעיה אחת':n+' בעיות'):'הכל תקין';
 $('hBadgeS').textContent=n?'מה לא עובד? ←':'בדיקת מצב';
 $('dgVerdict').textContent=NC>=4?'אין חיבור':!DG&&!DGerr?'בודק…':n?(n==1?'בעיה אחת':n+' בעיות'):'הכל תקין';
 $('dgSub').textContent=n?'לכל בעיה: מה קרה, למה, ומה לעשות, צעד אחרי צעד.':'כל מה שהמתקן יכול לבדוק לבד עובד.';
 const ord={bad:0,warn:1};R.P.sort((a,c)=>ord[a.sev]-ord[c.sev]);
 const h=R.P.map(x=>'<div class="dg '+x.sev+'"><span class="chip">'+(x.sev=='bad'?'לא עובד':'שים לב')+'</span><h3>'+esc(x.t)+'</h3><p class="why"><b>למה: </b>'+esc(x.why)+'</p>'+
  (x.todo.length?'<p class="why"><b>מה לעשות:</b></p><ol class="how">'+x.todo.map(t=>'<li>'+esc(t)+'</li>').join('')+'</ol>':'')+
  (x.btn?'<button class="btn dark" onclick="dgAct(\''+x.btn[1]+'\',\''+esc(x.btn[2])+'\')">'+esc(x.btn[0])+'</button>':'')+'</div>').join('')
  +'|'+R.OK.map(t=>'<li>'+esc(t)+'</li>').join('')+'|'+R.INF.map(t=>'<li class="i">'+esc(t)+'</li>').join('');
 if(h==dgLast)return;dgLast=h;const q=h.split('|');$('dgList').innerHTML=q[0];$('dgOk').innerHTML=q[1]||'<li class="i">עוד אין</li>';$('dgInfo').innerHTML=q[2];$('dgInfoC').style.display=q[2]?'block':'none'}
function dgAct(u,ok){post(u).then(r=>{toast(r.ok===false?whyTxt(r):ok);setTimeout(()=>loadDiag(0),400)}).catch(()=>toast(NOCONN))}
function showModes(){tab(0);const d=document.querySelector('details.diff');if(d){d.open=true;setTimeout(()=>d.scrollIntoView({block:'start'}),50)}}
// ---- v2.9.7 "כשהוא לא בטוח": question card, header badge, phone notifications (ntfy)
let AS={};
function askKey(e){return e.id+':'+e.t}
function askSkipped(){try{return JSON.parse(localStorage.getItem('askSkip')||'[]')}catch(e){return[]}}
function askSkipAdd(k){const s=askSkipped();s.push(k);try{localStorage.setItem('askSkip',JSON.stringify(s.slice(-40)))}catch(e){}}
function askPend(){const d=BM;if(!d||!d.list)return[];const s=askSkipped();return d.list.filter(e=>e.v==2&&!e.fixed&&s.indexOf(askKey(e))<0)}
function agoTxt(e){let a=null;if(BM.clock&&e.t>1e9)a=Date.now()/1000-e.t;else if(S.uptime!=null)a=S.uptime-e.t;if(a==null||a<0)return'';a=Math.round(a);return a<60?'לפני רגע':a<3600?'לפני '+Math.round(a/60)+' דק׳':'לפני '+Math.floor(a/3600)+' שע׳'}
function renderAsk(){const P=askPend(),c=$('askCard'),q=$('qBadge');if(!P.length){c.hidden=true;q.hidden=true;return}
 const e=P[0];c.hidden=false;q.hidden=false;c.dataset.id=e.id;c.dataset.k=askKey(e);
 $('askInfo').textContent=[agoTxt(e),'ציון נביחה '+e.p+'%','\u2066'+e.ms+' ms\u2069'].filter(Boolean).join(' · ')+(P.length>1?' · עוד '+(P.length-1)+' מחכים':'');
 $('qBadgeT').textContent=P.length==1?'שאלה אחת מחכה לך':P.length+' שאלות מחכות לך'}
function askAns(b){const c=$('askCard'),id=c.dataset.id,k=c.dataset.k;
 post('/api/bark-label','id='+id+'&bark='+b).then(d=>{if(!d||!d.list){askSkipAdd(k);renderAsk();toast('הקול הזה כבר לא ברשימה (נשמרים 20 קולות אחרונים)');return}
  BM=d;renderBursts();toast(b?'תודה! נשמר כנביחה שלה':'תודה! נשמר כ"לא נביחה"')}).catch(()=>toast('התשובה לא נשמרה. '+NOCONN))}
function askSkip(){askSkipAdd($('askCard').dataset.k);renderAsk();toast('דילגתי. הקול נשאר ברשימה "קולות אחרונים"')}
function askGo(){tab(0);$('askCard').scrollIntoView({behavior:'smooth',block:'start'})}
function helpAt(id){tab(4);const e=$(id);e.open=true;e.scrollIntoView()}
function askBandTxt(){const t=Math.round(([0.65,0.5,0.35][cfg.barkSens]||0.5)*100),b=Math.round(+cfg.askBand||0),lo=Math.max(0,t-b);
 $('askBandHelp').textContent=b?'עכשיו: ציון נביחה '+lo+'%–'+(t-1)+'% = "לא בטוח": אין חטיף, והוא שואל אותך. '+t+'% ומעלה = נביחה. פחות מ-'+lo+'% = רעש. 0 = לא שואל אף פעם.':'0: לא שואל אף פעם. כל קול מתחת ל-'+t+'% נחשב רעש.'}
function topicTxt(){const t=cfg.ntfyTopic||'--';$('topicShow').textContent=t;$('topicIn').textContent=t}
function copyTopic(){const t=cfg.ntfyTopic||'',ok=()=>toast('הועתק: '+t),fb=()=>{const i=document.createElement('textarea');i.value=t;document.body.appendChild(i);i.select();try{document.execCommand('copy');ok()}catch(e){toast(t)}i.remove()};
 if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(t).then(ok,fb);else fb()}
const ASKW={notopic:'אין שם ערוץ. השאר את השם ריק ושמור את ההגדרות, והמתקן ייצור אחד',nowifi:'המתקן לא מחובר לוויי-פיי של הבית, אז אין איך לשלוח',busy:'התראה אחרת נשלחת עכשיו. נסה שוב בעוד כמה שניות'};
function codeTxt(c){return c==200?'נשלח':c==429?'יותר מדי התראות לערוץ הזה. נסה שוב בעוד כמה דקות':c<0?'המתקן לא הצליח להגיע ל-ntfy.sh (אין אינטרנט בבית?)':'שרת ההתראות ענה '+c}
function askTest(){post('/api/ask-test').then(r=>{if(!r.ok){$('askTestS').textContent='';toast('לא נשלח: '+(ASKW[r.why]||r.why));return}$('askTestS').textContent='שולח…';askWatch(Date.now(),0)}).catch(()=>toast('לא נשלח. '+NOCONN))}
function askWatch(t0,sent){fetch('/api/ask').then(r=>r.json()).then(a=>{AS=a;askStateTxt();const el=(Date.now()-t0)/1000;
 if(!sent){if(a.busy&&el<15)return setTimeout(()=>askWatch(t0,0),700);
  if(a.code!=200){$('askTestS').textContent='לא נשלח: '+codeTxt(a.code);return}
  $('askTestS').textContent='נשלח ✅ עכשיו לחץ "כן" או "לא" בהתראה בטלפון';sent=1}
 if(a.pingAgo>=0){$('askTestS').textContent='הטלפון הגיע למתקן ✅ (לחצת "'+(a.pingAns?'כן':'לא')+'"). הכפתורים עובדים';toast('הכפתורים בהתראה עובדים ✅');return}
 if(el<120)setTimeout(()=>askWatch(t0,1),1500);else $('askTestS').textContent='נשלח, אבל לחיצה מהטלפון לא הגיעה. הטלפון בוויי-פיי של הבית?'}).catch(()=>{})}
const SKIPT=['','ההתראות כבויות','אין וויי-פיי','עברו פחות מ-2 דקות מהקודמת','כבר נשלחו 20 היום','המתקן היה עסוק'];
function askStateTxt(){const a=AS;if(a.today==null)return;let t='היום נשלחו '+a.today+' מתוך '+a.max+' שאלות לטלפון.';if(a.skip)t+=' השאלה האחרונה לא נשלחה: '+SKIPT[a.skip]+'.';if(!a.wifi)t+=' המתקן לא מחובר לוויי-פיי, אז התראות לא יוצאות.';$('askStateT').textContent=t}
function loadAsk(){fetch('/api/ask').then(r=>r.json()).then(a=>{AS=a;askStateTxt()}).catch(()=>{})}
// ---- v2.9.8 "שליטה מרחוק": switch, pairing code (text + QR), new code
// tiny QR encoder (byte mode, ECC L, versions 1-10, best mask) — after Project Nayuki's QR Code generator (MIT)
function qrMake(text){const data=Array.from(new TextEncoder().encode(text));
 const ECC=[0,7,10,15,20,26,18,20,24,30,18],NB=[0,1,1,1,1,1,2,2,2,2,4];
 const raw=v=>{let r=(16*v+128)*v+64;if(v>=2){const n=Math.floor(v/7)+2;r-=(25*n-10)*n-55;if(v>=7)r-=36}return r};
 let ver=1;for(;ver<=10;ver++){const cap=Math.floor(raw(ver)/8)-ECC[ver]*NB[ver];if(4+(ver<10?8:16)+data.length*8<=cap*8)break}if(ver>10)return null;
 const dcw=Math.floor(raw(ver)/8)-ECC[ver]*NB[ver],bits=[],put=(v,n)=>{for(let i=n-1;i>=0;i--)bits.push(v>>>i&1)};
 put(4,4);put(data.length,ver<10?8:16);data.forEach(b=>put(b,8));put(0,Math.min(4,dcw*8-bits.length));put(0,(8-bits.length%8)%8);
 for(let p=0xEC;bits.length<dcw*8;p^=0xEC^0x11)put(p,8);
 const cw=[];for(let i=0;i<bits.length;i+=8){let b=0;for(let j=0;j<8;j++)b=b<<1|bits[i+j];cw.push(b)}
 // Reed-Solomon over GF(256)/0x11D
 const mul=(x,y)=>{let z=0;for(let i=7;i>=0;i--){z=(z<<1)^((z>>>7)*0x11D);z^=((y>>>i)&1)*x}return z&255};
 const deg=ECC[ver],gen=new Array(deg).fill(0);gen[deg-1]=1;let root=1;
 for(let i=0;i<deg;i++){for(let j=0;j<deg;j++){gen[j]=mul(gen[j],root);if(j+1<deg)gen[j]^=gen[j+1]}root=mul(root,2)}
 const rs=d=>{const r=new Array(deg).fill(0);d.forEach(b=>{const f=b^r.shift();r.push(0);gen.forEach((g,i)=>r[i]^=mul(g,f))});return r};
 const nb=NB[ver],tot=Math.floor(raw(ver)/8),nShort=nb-tot%nb,shortLen=Math.floor(tot/nb),blocks=[];
 for(let i=0,k=0;i<nb;i++){const dl=shortLen-deg+(i<nShort?0:1),d=cw.slice(k,k+dl);k+=dl;const e=rs(d);if(i<nShort)d.push(0);blocks.push(d.concat(e))}
 const all=[];for(let i=0;i<blocks[0].length;i++)blocks.forEach((b,j)=>{if(i!=shortLen-deg||j>=nShort)all.push(b[i])});
 const N=ver*4+17,M=[],F=[];for(let i=0;i<N;i++){M.push(new Array(N).fill(0));F.push(new Array(N).fill(0))}
 const set=(x,y,d)=>{M[y][x]=d?1:0;F[y][x]=1};
 for(let i=0;i<N;i++){set(6,i,i%2==0);set(i,6,i%2==0)}
 const finder=(x,y)=>{for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++){const d=Math.max(Math.abs(dx),Math.abs(dy)),xx=x+dx,yy=y+dy;if(xx>=0&&xx<N&&yy>=0&&yy<N)set(xx,yy,d!=2&&d!=4)}};
 finder(3,3);finder(N-4,3);finder(3,N-4);
 if(ver>1){const n=Math.floor(ver/7)+2,step=Math.ceil((ver*4+4)/(n*2-2))*2,pos=[6];for(let p=ver*4+10;pos.length<n;p-=step)pos.splice(1,0,p);
  pos.forEach((a,i)=>pos.forEach((b,j)=>{if(!((i==0&&j==0)||(i==0&&j==n-1)||(i==n-1&&j==0)))for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++)set(a+dx,b+dy,Math.max(Math.abs(dx),Math.abs(dy))!=1)}))}
 const fmt=mask=>{const d=1<<3|mask;let r=d;for(let i=0;i<10;i++)r=(r<<1)^((r>>>9)*0x537);const b=(d<<10|r)^0x5412;
  for(let i=0;i<=5;i++)set(8,i,b>>>i&1);set(8,7,b>>>6&1);set(8,8,b>>>7&1);set(7,8,b>>>8&1);for(let i=9;i<15;i++)set(14-i,8,b>>>i&1);
  for(let i=0;i<8;i++)set(N-1-i,8,b>>>i&1);for(let i=8;i<15;i++)set(8,N-15+i,b>>>i&1);set(8,N-8,1)};
 fmt(0);
 if(ver>=7){let r=ver;for(let i=0;i<12;i++)r=(r<<1)^((r>>>11)*0x1F25);const b=ver<<12|r;for(let i=0;i<18;i++){const bt=b>>>i&1,a=N-11+i%3,c=Math.floor(i/3);set(a,c,bt);set(c,a,bt)}}
 let i=0;for(let r=N-1;r>=1;r-=2){if(r==6)r=5;for(let v=0;v<N;v++)for(let j=0;j<2;j++){const x=r-j,up=((r+1)&2)==0,y=up?N-1-v:v;
  if(!F[y][x]&&i<all.length*8){M[y][x]=all[i>>>3]>>>(7-(i&7))&1;i++}}}
 const MF=[(x,y)=>(x+y)%2==0,(x,y)=>y%2==0,(x,y)=>x%3==0,(x,y)=>(x+y)%3==0,(x,y)=>(Math.floor(x/3)+Math.floor(y/2))%2==0,(x,y)=>x*y%2+x*y%3==0,(x,y)=>(x*y%2+x*y%3)%2==0,(x,y)=>((x+y)%2+x*y%3)%2==0];
 const app=m=>{for(let y=0;y<N;y++)for(let x=0;x<N;x++)if(!F[y][x]&&MF[m](x,y))M[y][x]^=1};
 const pen=()=>{let p=0,dark=0;const line=get=>{let run=1;for(let k=1;k<=N;k++){const c=k<N?get(k):-1;if(c==get(k-1))run++;else{if(run>=5)p+=run-2;run=1}}
};
  for(let y=0;y<N;y++)line(x=>M[y][x]);for(let x=0;x<N;x++)line(y=>M[y][x]);
  for(let y=0;y<N-1;y++)for(let x=0;x<N-1;x++){const c=M[y][x];if(c==M[y][x+1]&&c==M[y+1][x]&&c==M[y+1][x+1])p+=3}
  for(let y=0;y<N;y++)for(let x=0;x<N;x++){dark+=M[y][x];
   if(x+6<N&&M[y][x]&&!M[y][x+1]&&M[y][x+2]&&M[y][x+3]&&M[y][x+4]&&!M[y][x+5]&&M[y][x+6])p+=40;
   if(y+6<N&&M[y][x]&&!M[y+1][x]&&M[y+2][x]&&M[y+3][x]&&M[y+4][x]&&!M[y+5][x]&&M[y+6][x])p+=40}
  return p+Math.floor(Math.abs(dark*20-N*N*10)/(N*N))*10};
 let best=0,bp=1e9;for(let m=0;m<8;m++){app(m);fmt(m);const p=pen();if(p<bp){bp=p;best=m}app(m)}
 app(best);fmt(best);return M}
function qrDraw(cv,text){const M=qrMake(text);if(!M)return;const N=M.length,q=4,s=Math.floor(cv.width/(N+2*q))||1,c=cv.getContext('2d');
 c.fillStyle='#fff';c.fillRect(0,0,cv.width,cv.height);c.fillStyle='#000';const o=Math.floor((cv.width-s*N)/2);
 for(let y=0;y<N;y++)for(let x=0;x<N;x++)if(M[y][x])c.fillRect(o+x*s,o+y*s,s,s)}
let RM={};
const RMERR={sig:'הגיעה פקודה עם קוד ישן. פתח את האפליקציה בבית כדי שתתחבר שוב.',time:'הגיעה פקודה עם שעה לא נכונה. בדוק שהשעון בטלפון נכון.',replay:'הגיעה פקודה כפולה, והיא לא בוצעה.'};
function rmFill(r){if(!r||!r.topic)return;RM=r;$('rmOn').checked=!!r.on;const c=JSON.stringify({topic:r.topic,key:r.key});if($('rmCode').textContent!=c){$('rmCode').textContent=c;qrDraw($('rmQr'),c)}
 let t=r.last>0?'פקודה אחרונה מהאפליקציה: '+new Date(r.last*1000).toLocaleString('he-IL',{day:'numeric',month:'numeric',hour:'2-digit',minute:'2-digit'}):'עוד לא הגיעה פקודה מהאפליקציה.';
 if(r.api>0)t+=' בקשות מרחוק היום: '+r.api+' מתוך 150.';if(r.on&&r.clock===false)t+=' השעון של המתקן עוד לא מכוון, אז פקודות לא מתקבלות.';if(r.err&&RMERR[r.err])t+=' '+RMERR[r.err];$('rmLast').textContent=t}
function loadRemote(){fetch('/api/remote').then(r=>r.json()).then(rmFill).catch(()=>{})}
function rmSet(on){post('/api/remote','on='+(on?1:0)).then(r=>{rmFill(r);toast(on?'שליטה מרחוק דלוקה':'שליטה מרחוק כבויה')}).catch(()=>{$('rmOn').checked=!on;toast('לא נשמר. '+NOCONN)})}
function rmReset(){if(!confirm('ליצור קוד חדש? הקוד הישן יפסיק לעבוד, והאפליקציה תצטרך להתחבר שוב בבית.'))return;post('/api/remote-reset').then(r=>{rmFill(r);toast('נוצר קוד חדש')}).catch(()=>toast('לא נוצר. '+NOCONN))}
function rmCopy(){const t=$('rmCode').textContent,ok=()=>toast('הקוד הועתק'),fb=()=>{const i=document.createElement('textarea');i.value=t;document.body.appendChild(i);i.select();try{document.execCommand('copy');ok()}catch(e){toast(t)}i.remove()};
 if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(t).then(ok,fb);else fb()}
loadCfg();poll();loadStats();loadBursts();loadRemote();setInterval(()=>{if(!document.hidden&&$('rmOn').offsetParent)loadRemote()},10000);setInterval(poll,500);loadDiag(0);setInterval(()=>{if(!document.hidden)loadDiag(0)},5000);function hashTab(){if(location.hash=='#ask')setTimeout(askGo,600);else if(location.hash=='#help')tab(4);else if(location.hash=='#diag')tab(5)}hashTab();addEventListener('hashchange',hashTab);setInterval(loadStats,10000);let bmTick=0;setInterval(()=>{bmTick++;if(BM.learn>=0||(bmTick%3==0&&$('pg0').className.includes('on')))loadBursts()},1000);
</script></body></html>
)HTMLPAGE";
