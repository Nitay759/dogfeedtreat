#pragma once
// v2.9.6: the /meal page (meals, fast-treat calibration, grams calibration, cleaning). Hebrew RTL.
// UI redesign: same IDs/endpoints; the fast-treat angle slider is now a stepper (− number +, typeable).
static const char MEAL_HTML[] PROGMEM = R"HTML(<!doctype html><html dir="rtl" lang="he"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ארוחות וכיול</title><meta name="theme-color" content="#F3F1EA">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Crect x='8' y='8' width='184' height='184' rx='56' fill='%23F4A988'/%3E%3Cg fill='%231F3B2D'%3E%3Cellipse cx='100' cy='122' rx='36' ry='30'/%3E%3Cellipse cx='58' cy='84' rx='14' ry='18'/%3E%3Cellipse cx='84' cy='60' rx='14' ry='19'/%3E%3Cellipse cx='116' cy='60' rx='14' ry='19'/%3E%3Cellipse cx='142' cy='84' rx='14' ry='18'/%3E%3C/g%3E%3C/svg%3E">
<style>
@font-face{font-family:Suez;src:url(/f.woff2) format("woff2");font-display:swap}
:root{--paper:#F3F1EA;--card:#FBFAF5;--ink:#1F3B2D;--ink2:#2E4A3B;--mut:#4E5F55;--line:#DDD8CA;--soft:#E9E6DB;--ball:#F4A988;--ballD:#EC9470;--peachT:#FBE0D2;--olive:#3E6B52;--bark:#3F5A78;--barkbg:#E1E7EE;--ok:#2D6A43;--bad:#3F5A78;--okbg:#E2EBDF;--stop:#D7263D;--stopD:#A8172B;--warn:#F6C85F;--fsoft:#D6DED8;--fmut:#C9D3CB;--ftrack:#36533F;--disp:Suez,"Arial Hebrew","Noto Sans Hebrew",system-ui,sans-serif}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI","Noto Sans Hebrew","Arial Hebrew",Arial,sans-serif;background:var(--paper);color:var(--ink);font-size:16px;line-height:1.5;padding-bottom:calc(112px + env(safe-area-inset-bottom))}
p,li{text-wrap:pretty}a{color:inherit}
h1,h2,.d{font-family:var(--disp);font-weight:400;letter-spacing:0}
h2{font-size:25px;line-height:1.15;margin:0 0 10px}
h3{font-size:16px;font-weight:700;margin:22px 0 6px;padding-top:14px;border-top:1px solid var(--line)}
.mut{color:var(--mut);font-size:14.5px}.num{font-variant-numeric:tabular-nums}.ltr{direction:ltr;unicode-bidi:isolate}
main{max-width:640px;margin:auto}
.card{padding:22px 18px 24px;border-top:1px solid var(--line)}
.card:first-child{border-top:0}
.big{font-family:var(--disp);font-size:46px;line-height:1;font-variant-numeric:tabular-nums}
.row{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:10px 0}
button,.btn,label.btn{-webkit-tap-highlight-color:transparent;transition:transform .12s ease-out,background-color .12s,box-shadow .12s;cursor:pointer}
button:active,.btn:active{transform:scale(.96)}
.btn{display:inline-flex;align-items:center;justify-content:center;min-height:44px;border:2px solid var(--ink);background:var(--card);color:var(--ink);border-radius:18px;padding:8px 14px;font:inherit;font-size:15px;font-weight:700;text-decoration:none}
.btn:active{background:var(--soft)}.btn.dark{background:var(--ink);color:#fff}.btn.dark:active{background:#142A1F}
.btn.rec{background:var(--bark);border-color:var(--bark);color:#fff}
.stp{display:flex;align-items:center;gap:6px;flex:none}
.stp button{width:48px;height:48px;border:2px solid var(--ink);background:var(--card);color:var(--ink);border-radius:50%;font:inherit;font-size:26px;font-weight:700;line-height:1;padding:0}
.stp button:active{background:var(--ball)}
.stp input[type=number]{width:84px;height:52px;border:0;border-bottom:3px dotted var(--ink2);border-radius:14px 14px 0 0;background:none;text-align:center;font-family:var(--disp);font-size:34px;color:var(--ink);padding:0;-moz-appearance:textfield}
.stp input::-webkit-inner-spin-button,.stp input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}
.stp input[type=number]:focus{outline:0;border-bottom-color:var(--ink);background:var(--ball)}
.unit{font-size:14px;color:var(--mut);font-weight:600;min-width:1.2em}
.sw{position:relative;width:30px;height:30px;flex:none;display:inline-block}.sw input{position:absolute;opacity:0;width:0;height:0}
.sw span{position:absolute;inset:0;border:2px solid var(--ink);border-radius:10px;background:var(--card);transition:background-color .15s}
.sw span:before{content:"";position:absolute;width:7px;height:14px;left:9px;top:3px;border:solid var(--ball);border-width:0 3px 3px 0;transform:rotate(45deg) scale(0);transition:transform .15s}
.sw input:checked+span{background:var(--ink)}.sw input:checked+span:before{transform:rotate(45deg) scale(1)}
.sw input:focus-visible+span{outline:3px solid var(--ballD);outline-offset:2px}
input[type=number],input[type=text],input[type=date],input[type=time],select{width:96px;min-height:44px;padding:6px 8px;border:0;border-bottom:2px solid var(--ink2);border-radius:12px 12px 4px 4px;background:var(--soft);font:inherit;font-size:17px;font-weight:600;text-align:center;color:var(--ink);font-variant-numeric:tabular-nums}
input[type=text]{width:160px;direction:ltr}input[type=time]{width:150px}input[type=date]{width:160px}select{width:auto;text-align:start}
input:focus,select:focus{outline:0;border-bottom-color:var(--ink);background:var(--peachT)}
.pill{display:inline-block;padding:4px 12px;border-radius:999px;font-size:14.5px;font-weight:600;background:var(--soft)}
.pill.ok{background:var(--okbg);color:#1E4D30}.pill.bad{background:var(--barkbg);color:#2C4560}
.banner{padding:16px 18px;font-weight:700;font-size:17px;margin:12px 12px 0;border-radius:22px}
.banner.bad{background:var(--stop);color:#fff}.banner.warn{background:var(--warn);color:var(--ink)}
.banner .btn{margin-top:10px;border-color:currentColor;background:transparent;color:inherit}
#toast{position:fixed;top:calc(12px + env(safe-area-inset-top));left:50%;transform:translateX(-50%);background:var(--ink);color:#fff;padding:12px 20px;border-radius:999px;display:none;z-index:40;max-width:90vw;font-weight:600;box-shadow:0 10px 30px rgba(31,59,45,.28)}
nav.dock{position:fixed;left:12px;right:12px;bottom:calc(14px + env(safe-area-inset-bottom));z-index:30;display:flex;align-items:center;gap:10px;max-width:616px;margin:auto}
.bar{flex:1;display:flex;gap:2px;padding:5px;border-radius:999px;background:rgba(31,59,45,.96);border:1px solid rgba(243,241,234,.14);box-shadow:0 10px 28px rgba(31,59,45,.2),0 1px 2px rgba(31,59,45,.1)}
@supports ((-webkit-backdrop-filter:blur(1px)) or (backdrop-filter:blur(1px))){.bar{background:rgba(31,59,45,.8);-webkit-backdrop-filter:blur(18px) saturate(1.7);backdrop-filter:blur(18px) saturate(1.7)}}
.bar .tb,.bar a{flex:1;min-height:46px;border:0;border-radius:999px;background:none;color:var(--ink2);font:inherit;font-size:15px;font-weight:600;padding:0 4px;display:flex;align-items:center;justify-content:center;text-decoration:none;white-space:nowrap;color:#EEF0EA}
.bar .tb.on,.bar a.on{background:var(--ball);color:var(--ink);font-weight:800}
.stop{flex:none;width:66px;height:66px;border-radius:50%;border:3px solid #fff;background:var(--stop);color:#fff;font:inherit;font-size:16px;font-weight:800;letter-spacing:.02em;box-shadow:0 6px 18px rgba(20,30,25,.32),0 0 0 1px rgba(31,59,45,.12)}
.stop:active{background:var(--stopD);transform:scale(.92)}
footer{text-align:center;color:var(--mut);font-size:13px;padding:16px 18px}

.ph{padding:20px 18px 6px}.ph a{font-size:14.5px;font-weight:600;text-decoration:underline;text-decoration-color:var(--ballD);text-decoration-thickness:2px;text-underline-offset:5px}
.ph h1{font-size:38px;line-height:1.05;margin:8px 0 0}.logo{display:inline-flex;vertical-align:-4px;margin-inline-end:8px}.logo svg{width:34px;height:34px;display:block}
.st{background:var(--ink);color:#EEF0EA;padding:18px 20px;font-size:15.5px;line-height:1.7;margin:14px 12px 0;border-radius:22px}
.st b{font-family:var(--disp);font-weight:400;font-size:30px;color:var(--ball);line-height:1;vertical-align:-3px}.st .mut{color:var(--fmut)}
label{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0;font-size:16px;min-height:44px}
.ck{position:relative;width:30px;height:30px;flex:none}.ck input{position:absolute;opacity:0;width:0;height:0;margin:0}
.ck span{position:absolute;inset:0;border:2px solid var(--ink);border-radius:10px;background:var(--card);transition:background-color .15s}
.ck span:before{content:"";position:absolute;width:7px;height:14px;left:9px;top:3px;border:solid var(--ball);border-width:0 3px 3px 0;transform:rotate(45deg) scale(0);transition:transform .15s}
.ck input:checked+span{background:var(--ink)}.ck input:checked+span:before{transform:rotate(45deg) scale(1)}
.ck input:focus-visible+span{outline:3px solid var(--ballD);outline-offset:2px}
button.b{display:flex;align-items:center;justify-content:center;width:100%;min-height:52px;margin:8px 0;padding:10px 14px;border:2px solid var(--ink);border-radius:18px;background:var(--card);color:var(--ink);font:inherit;font-size:16px;font-weight:700}
button.b:active{background:var(--soft)}
button.p{border:0;background:var(--ball);font-family:var(--disp);font-weight:400;font-size:24px;min-height:68px;border-radius:22px;box-shadow:inset 0 -5px 0 rgba(31,59,45,.16)}
button.p:active{background:var(--ballD)}
button.d{background:var(--ink);color:#fff}button.d:active{background:#142A1F}
.pair{display:grid;grid-template-columns:1fr 1fr;gap:8px}.pair button.b{margin:0;font-size:15px;line-height:1.3}
ol.how{margin:10px 0;padding-inline-start:22px;font-size:15px;color:var(--ink2)}ol.how li{margin:6px 0;padding-inline-start:4px}ol.how li::marker{font-family:var(--disp);color:var(--ink)}
#sSt{background:var(--peachT);padding:12px 16px;margin:10px 0;border-radius:16px;font-size:15px;color:var(--ink2)}
.banner{margin:12px 12px 0}
@keyframes shk{0%,100%{transform:none}20%,60%{transform:translateX(-7px)}40%,80%{transform:translateX(7px)}}.shk{animation:shk .36s;border-bottom-color:var(--stop)!important}

/* v2.9.6 help: toast with the reason, spinner -> success / shake */
#toast{position:fixed;top:calc(12px + env(safe-area-inset-top));left:50%;transform:translateX(-50%);background:var(--ink);color:#fff;padding:12px 20px;border-radius:22px;display:none;z-index:40;max-width:90vw;width:max-content;font-weight:600;text-align:center;box-shadow:0 10px 30px rgba(31,59,45,.28)}
button.wait{position:relative;color:transparent!important;pointer-events:none}
button.wait:after{content:"";position:absolute;inset:0;margin:auto;width:20px;height:20px;border-radius:50%;border:3px solid var(--ink);border-top-color:transparent;animation:spn .7s linear infinite}
.b.d.wait:after,.b.p.wait:after{border-color:currentColor}
button.okd{animation:pop .4s ease}button.nod{animation:shk .4s}
@keyframes spn{to{transform:rotate(1turn)}}@keyframes pop{50%{transform:scale(1.04)}}
.ph .hl{margin-inline-start:18px}
</style></head><body>
<div class="ph"><a href="/">חזרה למתקן</a><a class="hl" href="/#help">הוראות</a><h1><span class="logo"><svg viewBox="0 0 200 200" aria-hidden="true"><rect x="8" y="8" width="184" height="184" rx="56" fill="#F4A988"/><g fill="#1F3B2D"><ellipse cx="100" cy="122" rx="36" ry="30"/><ellipse cx="58" cy="84" rx="14" ry="18"/><ellipse cx="84" cy="60" rx="14" ry="19"/><ellipse cx="116" cy="60" rx="14" ry="19"/><ellipse cx="142" cy="84" rx="14" ry="18"/></g></svg></span>ארוחות וכיול</h1></div>
<main>
<div class="banner bad" id="stopBox" style="display:none">הכול עצור. ארוחות וחטיפים אוטומטיים ממתינים עוד <span id="stopLeft"></span> דק׳.<br><button class="b" style="width:auto;display:inline-flex;color:#fff;border-color:#fff;background:transparent" onclick="post('/api/resume')">המשך עכשיו</button></div>
<section class="st" id="st">...</section>
<section class="card"><button class="b p" onclick="post('/api/meal-now')">ארוחה עכשיו</button>
<button class="b" onclick="post('/api/treat')">חטיף עכשיו (שקע אחד מגלגל החטיפים)</button><button class="b" onclick="post('/api/meal-stop')">עצור ארוחה</button></section>
<section class="card"><h2>ארוחות</h2><label for="on">ארוחות אוטומטיות <span class="ck"><input type="checkbox" id="on"><span></span></span></label>
<label for="g">גרם לארוחה <div class="stp"><button type="button" onclick="stp('g',-1)" aria-label="פחות">−</button><input type="number" inputmode="numeric" id="g" min="0" max="1000" step="5"><button type="button" onclick="stp('g',1)" aria-label="יותר">+</button><span class="unit">ג׳</span></div></label><label for="t1">ארוחה 1 <input id="t1" type="time"></label><label for="t2">ארוחה 2 <input id="t2" type="time"></label>
<p class="mut">החטיפים של היום נספרים בגרמים ויורדים מהארוחה הבאה, אבל ארוחה אף פעם לא יורדת מתחת ל-<span id="fl"></span>% מהגודל שלה. אוכל ליום והאחוז: במסך הראשי, הגדרות.</p>
<h3>כיול גלגלים</h3>
<label for="gpt">גרם לשקע, גלגל חטיפים <input id="gpt" type="number" inputmode="decimal" step="0.01"></label><label for="gpb">גרם לשקע, גלגל אוכל <input id="gpb" type="number" inputmode="decimal" step="0.01"></label>
<label for="cs">מרווח מצמד (חצאי צעד) <input id="cs" type="number" inputmode="numeric"></label><button class="b d" onclick="save()">שמור</button></section>
<section class="card"><h2>חטיף מהיר</h2>
<p class="mut">בין חטיף לחטיף גלגל החטיפים מחכה כמעט עד הסוף של השקע (למשל 85%), כך שאחרי הקליק נשאר רק סיבוב קטן והחטיף נופל תוך פחות משנייה. זווית גדולה מדי = החטיף נופל עוד לפני הקליק.</p>
<label for="sOn">חטיף מהיר פועל <span class="ck"><input type="checkbox" id="sOn" onchange="stg('on='+(this.checked?1:0))"><span></span></span></label>
<label for="sPct">זווית המתנה <div class="stp"><button type="button" onclick="stp('sPct',-1)" aria-label="פחות">−</button><input type="number" inputmode="numeric" id="sPct" min="40" max="95" step="1" onchange="stg('pct='+this.value)"><button type="button" onclick="stp('sPct',1)" aria-label="יותר">+</button><span class="unit">%</span></div></label>
<div id="sSt"></div>
<ol class="how"><li>מלא חטיפים.</li><li>לחץ "סובב למצב מוכן" וחכה 10 שניות. נפל חטיף? לחץ "נפל לפני הקליק" (הזווית יורדת 3%) ונסה שוב.</li><li>לחץ "קליק + חטיף" כמה פעמים ובדוק שהזמן מתחת לשנייה. ארוך? הגדל את הזווית ב-2–3%.</li></ol>
<button class="b p" onclick="post('/api/treat').then(()=>setTimeout(sload,2500))">קליק + חטיף (בדיקה)</button>
<div class="pair"><button class="b" onclick="stg('act=now')">סובב למצב מוכן</button><button class="b" onclick="stg('act=spill')">נפל לפני הקליק</button></div></section>
<section class="card"><h2>כיול גרמים</h2><p class="mut">פעם אחת לכל גלגל. הכיול נשמר לגלגל שרץ אחרון.</p>
<ol class="how"><li>הוצא את המגש ושים כוס מתחת לפתח.</li><li>לחץ "הפעל 20 שקעים" של הגלגל.</li><li>שקול את מה שבכוס (בלי הכוס) והקלד גרמים.</li></ol>
<div class="pair"><button class="b" onclick="post('/api/meal-cal?troughs=20&wheel=0')">הפעל 20 שקעים, חטיפים</button><button class="b" onclick="post('/api/meal-cal?troughs=20&wheel=1')">הפעל 20 שקעים, אוכל</button></div><label for="cg">גרמים בכוס <input id="cg" type="number" inputmode="decimal" step="0.1"></label><button class="b d" onclick="post('/api/meal-cal?grams='+$('cg').value)">שמור כיול</button></section>
<section class="card"><h2>מצב ניקוי</h2><p class="mut">הגלגלים מסתובבים לאט ומרוקנים למגש את מה שנשאר (קודם חטיפים, אחר כך אוכל), ואז המנוע משתחרר ואפשר להרים את מחסנית הגלגלים החוצה ולשטוף בכיור. בזמן הניקוי אין ארוחות ואין חטיפים. אפשר גם: לחיצה ארוכה (5 שניות) על כפתור BOOT, ולחיצה קצרה = סיימתי.</p>
<div class="pair"><button class="b" onclick="post('/api/clean-start')">התחל ניקוי</button><button class="b d" onclick="post('/api/clean-done')">סיימתי לנקות</button></div></section>
</main><div id="toast" role="status"></div>
<nav class="dock"><div class="bar"><a href="/">מתקן</a><a class="on" href="/meal">ארוחות</a><a href="/check">בדיקה</a></div><button class="stop" onclick="post('/api/stop')" aria-label="עצור הכול">STOP</button></nav>
<script>
function isNum(t){return t&&t.tagName=='INPUT'&&t.type=='number'}
function shake(e){e.classList.remove('shk');void e.offsetWidth;e.classList.add('shk');setTimeout(()=>e.classList.remove('shk'),400)}
document.addEventListener('focusin',e=>{if(isNum(e.target))e.target._old=e.target.value},true);
document.addEventListener('keydown',e=>{if(e.key=='Enter'&&isNum(e.target))e.target.blur()},true);
document.addEventListener('change',e=>{const t=e.target;if(!isNum(t))return;const v=parseFloat(String(t.value).replace(',','.'));
 if(isNaN(v)){t.value=t._old==null?'':t._old;shake(t);e.stopPropagation();return}
 const mn=t.min===''?-1e9:+t.min,mx=t.max===''?1e9:+t.max;if(v<mn||v>mx){t.value=Math.min(mx,Math.max(mn,v));shake(t)}t._old=t.value},true);
function stp(id,d){const e=document.getElementById(id),st=+(e.step||1)||1,mn=e.min===''?-1e9:+e.min,mx=e.max===''?1e9:+e.max;
 let v=Math.round(((parseFloat(e.value)||0)+d*st)/st)*st;v=+v.toFixed(2);if(v<mn||v>mx){v=Math.min(mx,Math.max(mn,v));shake(e)}e.value=v;
 clearTimeout(e._t);e._t=setTimeout(()=>{e._t=0;e.dispatchEvent(new Event('change',{bubbles:true}))},400)}
function busy(id){const e=document.getElementById(id);return document.activeElement===e||!!e._t}
const $=i=>document.getElementById(i);let f=0;
 function show(d){$('st').innerHTML=(d.clean?(d.cleanSt?'מצב ניקוי: מרוקן את '+(d.cleanSt==1?'גלגל החטיפים':'גלגל האוכל')+'…':'מצב ניקוי: המנוע משוחרר, אפשר להוציא את הגלגלים. בסוף: "סיימתי לנקות"')+'<br>':'')+(d.busy?(d.cal?'כיול רץ: '+d.done+' שקעים':'ארוחה רצה: <b class="num">'+d.served+'</b> / '+d.target+' גרם'):'מוכן')
 +'<br>היום: ארוחות <b class="num">'+d.today+'</b> ג׳ · חטיפים <b class="num">'+Math.round(d.treatG)+'</b> ג׳ מתוך '+d.foodG
 +'<br>ארוחה הבאה: '+d.nextMeal+' ג׳'+(d.nextMeal<d.g?' (במקום '+d.g+', בגלל חטיפים)':'')+' · ארוחה מלאה = '+d.troughs+' מנות'
 +(d.calWaiting?'<br>הכיול רץ ('+d.calDone+' שקעים): שקול והקלד גרמים':'')+(d.emptyF?'<br>צד האוכל ריק או תקוע?':'')+(d.emptyT?'<br>צד החטיפים ריק או תקוע?':'')+'<br><span class="mut">'+d.last+' · מצמד: '+d.clutch+'</span>';
 $('fl').textContent=d.floor;$('stopBox').style.display=d.stop>0?'block':'none';$('stopLeft').textContent=Math.ceil(d.stop/60);
 if(!f){f=1;$('on').checked=d.on;$('g').value=d.g;$('t1').value=d.t1;$('t2').value=d.t2;$('gpt').value=d.gpt;$('gpb').value=d.gpb;$('cs').value=d.cs}}
 function sshow(s){$('sOn').checked=s.on;if(!busy('sPct'))$('sPct').value=s.pct;
 $('sSt').innerHTML=(s.staging?'מסובב למצב מוכן…':s.staged?'מוכן: הגלגל מחכה ב-'+s.pos+'% של השקע':'לא מוכן כרגע (יתכונן 2 שניות אחרי החטיף הבא)')+'<br>זמן מהקליק לנפילה, חטיף אחרון: '+(s.lat?(s.lat/1000).toFixed(2)+' שנ׳':'עוד אין')+' · היום השקע היה ריק בקליק: '+s.spills+(s.ir?'':'<br>בלי חיישן IR אי אפשר למדוד זמן או לגלות נפילה מוקדמת.')}
 function load(){fetch('/api/meal').then(r=>r.json()).then(show)}
 function sload(){fetch('/api/stage').then(r=>r.json()).then(sshow)}
 function stg(q){const b=busyBtn();fetch('/api/stage?'+q,{method:'POST'}).then(r=>r.json()).then(s=>{doneBtn(b,true);sshow(s)}).catch(()=>{doneBtn(b,false);toast(NOCONN)})}
 let lastBtn=null,lastBtnT=0;document.addEventListener('pointerdown',e=>{const b=e.target.closest&&e.target.closest('button');if(b){lastBtn=b;lastBtnT=Date.now()}},true);
 function busyBtn(){const b=lastBtn;lastBtn=null;if(!b||Date.now()-lastBtnT>800||b.classList.contains('stop')||b.closest('.stp'))return null;b.classList.add('wait');return b}
 function doneBtn(b,ok){if(!b)return;b.classList.remove('wait');b.classList.add(ok?'okd':'nod');setTimeout(()=>b.classList.remove('okd','nod'),600)}
 function toast(t){const e=$('toast');e.textContent=t;e.style.display='block';clearTimeout(e._t);e._t=setTimeout(()=>e.style.display='none',Math.max(2400,String(t).length*75))}
 const NOCONN='אין חיבור למתקן. בדוק שהטלפון בוויי-פיי של הבית ושהמתקן בחשמל';
 const WHY={meal:'כבר רצה ארוחה. אפשר "עצור ארוחה"',cal:'כיול גרמים רץ עכשיו. חכה שיסתיים',treat:'חטיף עוד יוצא. נסה שוב בעוד כמה שניות',
  motor:'המנוע מסובב עכשיו (סנכרון גלגלים או הכנת חטיף מהיר). נסה שוב בעוד כמה שניות',cleaning:'מצב ניקוי פעיל. קודם "סיימתי לנקות"',
  emptying:'הגלגלים כבר מתרוקנים. חכה שיסתיימו',busy:'המתקן עסוק כרגע. נסה שוב בעוד כמה שניות'};
 const OKM={'/api/meal-now':'הארוחה התחילה','/api/treat':'חטיף בדרך','/api/meal-stop':'הארוחה נעצרה','/api/clean-start':'מצב ניקוי: הגלגלים מתרוקנים','/api/clean-done':'חזרנו לעבודה','/api/meal-cal':'הכיול התחיל','/api/stop':'הכול נעצר','/api/resume':'ממשיכים'};
 function failTxt(u,j){const k=u.split('?')[0];
  if(k=='/api/meal-cal'&&j.error)return 'הכיול לא נשמר: קודם לחץ "הפעל 20 שקעים", חכה שיסיים, ואז הקלד גרמים';
  if(k=='/api/treat'&&j.measure)return 'אין חטיף: במצב "רק מדידה" לא נותנים חטיפים';
  return (k=='/api/treat'?'אין חטיף: ':k=='/api/meal-now'?'הארוחה לא התחילה: ':k=='/api/clean-start'?'הניקוי לא התחיל: ':k=='/api/meal-cal'?'הכיול לא התחיל: ':'')+(WHY[j.why]||(j.cleaning?WHY.cleaning:WHY.busy))}
 function post(u){const b=busyBtn();return fetch(u,{method:'POST'}).then(r=>r.json()).then(j=>{const ok=j.ok!==false;doneBtn(b,ok);
  if(!ok)toast(failTxt(u,j));else{const k=u.split('?')[0];toast(k=='/api/meal-cal'&&u.includes('grams')?'הכיול נשמר':OKM[k]||'בוצע')}
  setTimeout(load,300);return j}).catch(()=>{doneBtn(b,false);toast(NOCONN)})}
 function save(){const b=busyBtn();f=0;fetch('/api/meal?on='+($('on').checked?1:0)+'&g='+$('g').value+'&t1='+$('t1').value+'&t2='+$('t2').value+'&gpt='+$('gpt').value+'&gpb='+$('gpb').value+'&cs='+$('cs').value,{method:'POST'}).then(r=>r.json()).then(d=>{doneBtn(b,true);show(d);toast('נשמר')}).catch(()=>{doneBtn(b,false);toast('לא נשמר. '+NOCONN)})}
 load();sload();setInterval(load,2000);setInterval(sload,2000)</script></body></html>)HTML";
