#pragma once
// v2.9.5: "בדיקת חיבורים" wizard page, served at /check. Hebrew RTL, phone-first. UI redesign 2.9.6: restyled only.
const char CHECK_HTML[] PROGMEM = R"CHKPAGE(
<!DOCTYPE html>
<html lang="he" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>בדיקת חיבורים</title>
<meta name="theme-color" content="#F3F1EA">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Crect x='8' y='8' width='184' height='184' rx='56' fill='%23F4A988'/%3E%3Cg fill='%231F3B2D'%3E%3Cellipse cx='100' cy='122' rx='36' ry='30'/%3E%3Cellipse cx='58' cy='84' rx='14' ry='18'/%3E%3Cellipse cx='84' cy='60' rx='14' ry='19'/%3E%3Cellipse cx='116' cy='60' rx='14' ry='19'/%3E%3Cellipse cx='142' cy='84' rx='14' ry='18'/%3E%3C/g%3E%3C/svg%3E">
<style>
@font-face{font-family:Suez;src:url(/f.woff2) format("woff2");font-display:swap}
:root{--paper:#F3F1EA;--card:#FBFAF5;--ink:#1F3B2D;--ink2:#2E4A3B;--mut:#4E5F55;--line:#DDD8CA;--soft:#E9E6DB;--ball:#F4A988;--ballD:#EC9470;--peachT:#FBE0D2;--olive:#3E6B52;--bark:#3F5A78;--barkbg:#E1E7EE;--ok:#2D6A43;--bad:#3F5A78;--okbg:#E2EBDF;--stop:#D7263D;--stopD:#A8172B;--warn:#F6C85F;--fsoft:#D6DED8;--fmut:#C9D3CB;--ftrack:#36533F;--disp:Suez,"Arial Hebrew","Noto Sans Hebrew",system-ui,sans-serif}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI","Noto Sans Hebrew","Arial Hebrew",Arial,sans-serif;background:var(--paper);color:var(--ink);font-size:16px;line-height:1.5;padding-bottom:calc(112px + env(safe-area-inset-bottom))}
p,li{text-wrap:pretty}a{color:inherit}
h1,h2,.d{font-family:var(--disp);font-weight:400;letter-spacing:0}
h2{font-size:25px;line-height:1.15;margin:0 0 10px}
h3{font-size:16px;font-weight:700;margin:22px 0 6px;padding-top:14px;border-top:1px solid var(--line)}
.mut{color:var(--mut);font-size:14.5px}.num{font-variant-numeric:tabular-nums}.ltr{direction:ltr;unicode-bidi:isolate}
main{max-width:640px;margin:auto}
.card{padding:22px 18px 24px;border-top:1px solid var(--line)}
.card:first-child{border-top:0}
.big{font-family:var(--disp);font-size:46px;line-height:1;font-variant-numeric:tabular-nums}
.row{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:10px 0}
button,.btn,label.btn{-webkit-tap-highlight-color:transparent;transition:transform .12s ease-out,background-color .12s,box-shadow .12s;cursor:pointer}
button:active,.btn:active{transform:scale(.96)}
.btn{display:inline-flex;align-items:center;justify-content:center;min-height:44px;border:2px solid var(--ink);background:var(--card);color:var(--ink);border-radius:18px;padding:8px 14px;font:inherit;font-size:15px;font-weight:700;text-decoration:none}
.btn:active{background:var(--soft)}.btn.dark{background:var(--ink);color:#fff}.btn.dark:active{background:#142A1F}
.btn.rec{background:var(--bark);border-color:var(--bark);color:#fff}
.stp{display:flex;align-items:center;gap:6px;flex:none}
.stp button{width:48px;height:48px;border:2px solid var(--ink);background:var(--card);color:var(--ink);border-radius:50%;font:inherit;font-size:26px;font-weight:700;line-height:1;padding:0}
.stp button:active{background:var(--ball)}
.stp input[type=number]{width:84px;height:52px;border:0;border-bottom:3px dotted var(--ink2);border-radius:14px 14px 0 0;background:none;text-align:center;font-family:var(--disp);font-size:34px;color:var(--ink);padding:0;-moz-appearance:textfield}
.stp input::-webkit-inner-spin-button,.stp input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}
.stp input[type=number]:focus{outline:0;border-bottom-color:var(--ink);background:var(--ball)}
.unit{font-size:14px;color:var(--mut);font-weight:600;min-width:1.2em}
.sw{position:relative;width:30px;height:30px;flex:none;display:inline-block}.sw input{position:absolute;opacity:0;width:0;height:0}
.sw span{position:absolute;inset:0;border:2px solid var(--ink);border-radius:10px;background:var(--card);transition:background-color .15s}
.sw span:before{content:"";position:absolute;width:7px;height:14px;left:9px;top:3px;border:solid var(--ball);border-width:0 3px 3px 0;transform:rotate(45deg) scale(0);transition:transform .15s}
.sw input:checked+span{background:var(--ink)}.sw input:checked+span:before{transform:rotate(45deg) scale(1)}
.sw input:focus-visible+span{outline:3px solid var(--ballD);outline-offset:2px}
input[type=number],input[type=text],input[type=date],input[type=time],select{width:96px;min-height:44px;padding:6px 8px;border:0;border-bottom:2px solid var(--ink2);border-radius:12px 12px 4px 4px;background:var(--soft);font:inherit;font-size:17px;font-weight:600;text-align:center;color:var(--ink);font-variant-numeric:tabular-nums}
input[type=text]{width:160px;direction:ltr}input[type=time]{width:150px}input[type=date]{width:160px}select{width:auto;text-align:start}
input:focus,select:focus{outline:0;border-bottom-color:var(--ink);background:var(--peachT)}
.pill{display:inline-block;padding:4px 12px;border-radius:999px;font-size:14.5px;font-weight:600;background:var(--soft)}
.pill.ok{background:var(--okbg);color:#1E4D30}.pill.bad{background:var(--barkbg);color:#2C4560}
.banner{padding:16px 18px;font-weight:700;font-size:17px;margin:12px 12px 0;border-radius:22px}
.banner.bad{background:var(--stop);color:#fff}.banner.warn{background:var(--warn);color:var(--ink)}
.banner .btn{margin-top:10px;border-color:currentColor;background:transparent;color:inherit}
#toast{position:fixed;top:calc(12px + env(safe-area-inset-top));left:50%;transform:translateX(-50%);background:var(--ink);color:#fff;padding:12px 20px;border-radius:999px;display:none;z-index:40;max-width:90vw;font-weight:600;box-shadow:0 10px 30px rgba(31,59,45,.28)}
nav.dock{position:fixed;left:12px;right:12px;bottom:calc(14px + env(safe-area-inset-bottom));z-index:30;display:flex;align-items:center;gap:10px;max-width:616px;margin:auto}
.bar{flex:1;display:flex;gap:2px;padding:5px;border-radius:999px;background:rgba(31,59,45,.96);border:1px solid rgba(243,241,234,.14);box-shadow:0 10px 28px rgba(31,59,45,.2),0 1px 2px rgba(31,59,45,.1)}
@supports ((-webkit-backdrop-filter:blur(1px)) or (backdrop-filter:blur(1px))){.bar{background:rgba(31,59,45,.8);-webkit-backdrop-filter:blur(18px) saturate(1.7);backdrop-filter:blur(18px) saturate(1.7)}}
.bar .tb,.bar a{flex:1;min-height:46px;border:0;border-radius:999px;background:none;color:var(--ink2);font:inherit;font-size:15px;font-weight:600;padding:0 4px;display:flex;align-items:center;justify-content:center;text-decoration:none;white-space:nowrap;color:#EEF0EA}
.bar .tb.on,.bar a.on{background:var(--ball);color:var(--ink);font-weight:800}
.stop{flex:none;width:66px;height:66px;border-radius:50%;border:3px solid #fff;background:var(--stop);color:#fff;font:inherit;font-size:16px;font-weight:800;letter-spacing:.02em;box-shadow:0 6px 18px rgba(20,30,25,.32),0 0 0 1px rgba(31,59,45,.12)}
.stop:active{background:var(--stopD);transform:scale(.92)}
footer{text-align:center;color:var(--mut);font-size:13px;padding:16px 18px}

body{font-size:17px}
.ph{padding:20px 18px 6px}.ph a{font-size:14.5px;font-weight:600;text-decoration:underline;text-decoration-color:var(--ballD);text-decoration-thickness:2px;text-underline-offset:5px}
.ph h1{font-size:38px;line-height:1.05;margin:8px 0 0}.logo{display:inline-flex;vertical-align:-4px;margin-inline-end:8px}.logo svg{width:34px;height:34px;display:block}
main{padding:0}
.card{padding:22px 18px 24px}
.card h2{font-size:28px}
.big{display:block;width:100%;min-height:72px;border:0;border-radius:22px;padding:12px 16px;font-family:var(--disp);font-size:28px;line-height:1.1;background:var(--ball);color:var(--ink);margin-top:12px;box-shadow:inset 0 -5px 0 rgba(31,59,45,.16)}
.big:active{background:var(--ballD)}
.btns{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}
.btns button{flex:1 1 40%;min-height:58px;border:2px solid var(--ink);border-radius:18px;padding:12px 8px;font:inherit;font-size:18px;font-weight:700}
.y{background:var(--ok);border-color:var(--ok)!important;color:#fff}.n{background:var(--bark);border-color:var(--bark)!important;color:#fff}.o{background:var(--card);color:var(--ink)}.btns button.y:only-child{background:var(--ball);border-color:var(--ball)!important;color:var(--ink);font-family:var(--disp);font-weight:400;font-size:22px}
.live{margin-top:12px;padding:12px 14px;background:var(--ink);color:#EEF0EA;font-size:15px;direction:rtl;border-radius:16px}
.prog{height:10px;background:var(--line);overflow:hidden;margin:14px 18px 0;border-radius:999px}.prog div{height:100%;background:var(--ink);width:0;transition:width .3s}
.res{display:flex;gap:12px;align-items:flex-start;padding:12px 0;border-top:1px solid var(--line)}.res:first-child{border-top:0}
.ic{flex:none;min-width:56px;text-align:center;font-size:13px;font-weight:800;padding:4px 8px;border-radius:999px;background:var(--soft)}
.ic.ok{background:var(--okbg);color:#1E4D30}.ic.bad{background:var(--barkbg);color:#2C4560}.ic.warn{background:#FBEBC4;color:#5C3D00}.ic.skip{color:var(--mut)}
.res b{display:block}.fix{margin-top:8px;background:var(--barkbg);padding:10px 14px;font-size:14.5px;border-radius:14px}
.fix.w{background:#FBEBC4}.fix table{width:100%;border-collapse:collapse;margin-top:4px}.fix td{padding:4px 2px;border-top:1px solid #0001;vertical-align:top}
.dot{display:inline-block;width:12px;height:12px;border-radius:50%;border:1px solid #0003;vertical-align:middle;margin-left:4px}
.again{margin-top:8px;min-height:44px;border:2px solid var(--ink);background:var(--card);border-radius:18px;padding:8px 14px;font:inherit;font-size:15px;font-weight:700}
.lr{direction:ltr;unicode-bidi:isolate}
</style></head><body>
<div class="ph"><a href="/">חזרה למתקן</a><h1><span class="logo"><svg viewBox="0 0 200 200" aria-hidden="true"><rect x="8" y="8" width="184" height="184" rx="56" fill="#F4A988"/><g fill="#1F3B2D"><ellipse cx="100" cy="122" rx="36" ry="30"/><ellipse cx="58" cy="84" rx="14" ry="18"/><ellipse cx="84" cy="60" rx="14" ry="19"/><ellipse cx="116" cy="60" rx="14" ry="19"/><ellipse cx="142" cy="84" rx="14" ry="18"/></g></svg></span>בדיקת חיבורים</h1></div>
<nav class="dock"><div class="bar"><a href="/">מתקן</a><a href="/meal">ארוחות</a><a class="on" href="/check">בדיקה</a></div><button class="stop" onclick="fetch('/api/stop',{method:'POST'})" aria-label="עצור הכול">STOP</button></nav>
<main>
<div class="prog"><div id="pg"></div></div>
<div class="card" id="box"></div>
<div class="card" id="resBox" style="display:none"></div>
</main>
<script>
// ---- cables from the wiring table (WIRING_he v2.9). type MF = נקבה על החלק, זכר במסוף הברג של לוח ה-ESP32
const MF='זכר-נקבה (נקבה על החלק, זכר במסוף הבורג)', MFW='זכר-נקבה (נקבה על החלק, זכר ב-WAGO)', FF='נקבה-נקבה';
const COL={'אדום':'#d32f2f','שחור':'#222','כתום':'#f08a24','צהוב':'#f2c80f','ירוק':'#2e9d4a','כחול':'#1e5fd0','סגול':'#7b3fb5','אפור':'#8d8d8d','לבן':'#fff','חום':'#7a4a24','ורוד':'#f06aa5'};
const W={
 mic:{t:'מיקרופון פנימי INMP441',c:[[19,'SCK','GPIO26',MF,'צהוב'],[20,'WS','GPIO25',MF,'ירוק'],[21,'SD','GPIO33',MF,'כחול'],['22א','L/R','GND',MF,'שחור'],['22ב','GND','GND',MF,'שחור'],[23,'VDD','3V3',MF,'כתום']]},
 spk:{t:'רמקול + מגבר MAX98357A',c:[[15,'BCLK','GPIO14',MF,'צהוב'],[16,'LRC','GPIO21',MF,'ירוק'],[17,'DIN','GPIO22',MF,'חום'],['18א','VIN','WAGO "5V"',MFW,'אדום'],['18ב','GND','WAGO "GND B"',MFW,'שחור'],[14,'רמקול + / −','מסוף הבורג במגבר','החוטים של הרמקול','אדום / שחור']]},
 buz:{t:'באזר',c:[[29,'I/O','GPIO23',MF,'ורוד'],['30א','VCC','3V3',MF,'כתום'],['30ב','GND','GND',MF,'שחור']]},
 ledr:{t:'נורה – אדום',c:[[26,'R','GPIO4',MF,'אדום'],[27,'− (GND)','GND',MF,'שחור']]},
 ledg:{t:'נורה – ירוק',c:[['28א','G','GPIO13',MF,'ירוק'],[27,'− (GND)','GND',MF,'שחור']]},
 ledb:{t:'נורה – כחול',c:[['28ב','B','GPIO5',MF,'כחול'],[27,'− (GND)','GND',MF,'שחור']]},
 ir:{t:'חיישן IR במגלשה',c:[[24,'OUT','GPIO32',MF,'לבן'],['25א','VCC','3V3',MF,'כתום'],['25ב','GND','WAGO "GND B"',MFW,'שחור']]},
 motA:{t:'מנוע – גלגל חטיפים (כיוון A)',c:[[7,'תקע המנוע','שקע לבן ב-ULN2003','התקע הלבן של המנוע','צבעי המנוע'],[8,'IN1','GPIO19',MF,'כחול'],[9,'IN2','GPIO18',MF,'סגול'],[10,'IN3','GPIO17',MF,'אפור'],[11,'IN4','GPIO16',MF,'לבן'],[12,'+ ב-ULN2003','WAGO "5V"',MFW,'אדום'],[13,'− ב-ULN2003','WAGO "GND B"',MFW,'שחור']]},
 cam:{t:'מצלמה ESP32-CAM',c:[[5,'5V במצלמה','WAGO "5V"',MFW,'אדום'],[6,'GND במצלמה','WAGO "GND A"',MFW,'שחור']]},
 out:{t:'יחידה חיצונית ESP32-C3',c:[[34,'CN3791 יציאה + / −','5V / GND ב-C3','PH2.0 + דופונט','אדום / שחור'],[33,'CN3791 BAT+ / BAT−','תושבת 18650','PH2.0','אדום / שחור']]},
 outmic:{t:'מיקרופון חיצוני INMP441',c:[['35א','SCK / WS / SD','GPIO4 / GPIO5 / GPIO6',FF,'צהוב / ירוק / כחול'],['35ב','L/R + GND / VDD','GND / 3V3',FF,'שחור / כתום']]},
 outpir:{t:'חיישן תנועה חיצוני AM312',c:[[36,'OUT / + / −','GPIO3 / 3V3 / GND',FF,'לבן / כתום / שחור']]},
 pir:{t:'חיישן תנועה במתקן HC-SR501',c:[['חדש','OUT','GPIO27',MF,'צהוב'],['חדש','VCC','5V (מחבר לחיצה פנוי)',MFW,'אדום'],['חדש','GND','WAGO "GND B"',MFW,'שחור']]},
 board:{t:'לוח ESP32 + וויי-פיי',c:[[3,'WAGO "5V"','VIN / 5V בלוח','קצה זכר ב-WAGO, חוט חשוף / נקבה על פין בלוח','אדום'],[4,'WAGO "GND A"','GND בלוח','כמו 3','שחור']]}
};
const R={};            // results: id -> {s:'ok'|'bad'|'warn'|'skip', why:'', tip:''}
const box=document.getElementById('box');
const sl=ms=>new Promise(r=>setTimeout(r,ms));
async function st(){const r=await fetch('/api/check/state');return r.json()}
async function post(u){try{const r=await fetch(u,{method:'POST'});let j={};try{j=await r.json()}catch(e){}j.http=r.status;return j}catch(e){return{ok:false,err:'net'}}}
function show(title,html,live){box.innerHTML='<h2>'+title+'</h2><div>'+html+'</div>'+(live?'<div class="live" id="lv">…</div>':'')+'<div class="btns" id="bt"></div>'}
function lv(t){const e=document.getElementById('lv');if(e)e.innerHTML=t}
function ask(btns){return new Promise(res=>{const b=document.getElementById('bt');b.innerHTML='';btns.forEach(([k,label,cls])=>{const x=document.createElement('button');x.className=cls||'o';x.textContent=label;x.onclick=()=>res(k);b.appendChild(x)})})}
let skipFlag=false;
function skipBtn(){const b=document.getElementById('bt');b.innerHTML='';skipFlag=false;const x=document.createElement('button');x.className='o';x.textContent='דלג על החלק הזה';x.onclick=()=>{skipFlag=true};b.appendChild(x)}
async function waitFor(fn,ms,tick){const t0=Date.now();while(Date.now()-t0<ms){if(skipFlag)return 'skip';let s;try{s=await st()}catch(e){await sl(500);continue}const left=Math.ceil((ms-(Date.now()-t0))/1000);if(tick)tick(s,left);if(fn(s))return s;await sl(400)}return null}
function set(id,s,why,tip){R[id]={s,why:why||'',tip:tip||''}}

// ---------------------------------------------------------------- the tests
async function tBoard(){const s=await st();set('board','ok','הדף נטען מהלוח, אז הלוח דולק ומחובר לוויי-פיי'+(s.fs?'':' (אבל הזיכרון הפנימי לא עלה – הקלטות והתקדמות לא יישמרו)'));}
async function tMic(){
 show('מיקרופון פנימי','רגע של שקט… הלוח בודק שהמיקרופון שולח נתונים אמיתיים.',true);skipBtn();
 await post('/api/check/reset?what=mic');await sl(2500);if(skipFlag)return set('mic','skip');
 let s=(await st()).mic;
 if(s.win==0)return set('mic','bad','לא הגיעו נתונים מהמיקרופון בכלל','בדוק SCK (GPIO26) ו-WS (GPIO25). אם הם בסדר, כבה והדלק את המתקן.');
 if(s.zero>=s.win*0.9)return set('mic','bad','המיקרופון מחזיר רק אפסים = לא מחובר או בלי חשמל','בדוק קודם VDD ל-3V3 (לא 5V) ו-GND, אחר כך SD (GPIO33) ו-L/R ל-GND.');
 if(s.same>=s.win*0.9)return set('mic','bad','המיקרופון מחזיר את אותו מספר כל הזמן','בדוק SD (GPIO33) ו-WS (GPIO25).');
 if(s.avg>100)return set('mic','bad','מגיע רק "רעש" לא הגיוני (חוט רופף?)','בדוק שכל 5 החוטים יושבים טוב, במיוחד WS ו-SCK.');
 const base=s.avg;
 show('מיקרופון פנימי','המיקרופון שולח נתונים.<br><b>עכשיו מחא כף חזק פעמיים ליד המתקן.</b>',true);skipBtn();
 await post('/api/check/reset?what=mic');
 const r=await waitFor(x=>x.mic.max-base>=15,10000,(x,l)=>lv('רמה עכשיו: <span class="ltr">'+x.mic.db.toFixed(0)+' dB</span> · מחכה למחיאה ('+l+' שנ׳)'));
 if(r==='skip')return set('mic','warn','שולח נתונים, אבל דילגת על בדיקת המחיאה');
 if(r)return set('mic','ok','שולח נתונים ושמע את המחיאה (+'+(r.mic.max-base).toFixed(0)+' dB)');
 show('מיקרופון פנימי','לא שמעתי מחיאה. לנסות שוב?');
 const a=await ask([['again','נסה שוב','y'],['no','לא, המשך','o']]);
 if(a==='again')return tMic();
 set('mic','warn','שולח נתונים, אבל לא שמע מחיאה','אולי החור במיקרופון מכוסה, או שהמיקרופון הפוך (החור צריך לפנות החוצה דרך החור בקיר).');
}
async function quietBase(){await post('/api/check/reset?what=mic');await sl(1500);return (await st()).mic.avg}
async function tSpk(){
 const micOk=R.mic&&R.mic.s==='ok';
 show('רמקול','מנגן צלצול מהרמקול…');
 const base=micOk?await quietBase():0;
 await post('/api/check/reset?what=mic');
 const p=await post('/api/check/beep?dev=spk');
 if(p.err==='i2s')return set('spk','bad','הלוח לא הצליח להפעיל את יציאת הקול (I2S)','כבה והדלק. אם חוזר – בדוק BCLK/LRC/DIN.');
 await sl(2500);const s=await st();const heard=micOk&&(s.mic.max-base)>=10;
 show('רמקול','<b>שמעת צלצול מהרמקול?</b>'+(heard?'<div class="mut">(המיקרופון קלט קול חזק בזמן הצלצול)</div>':''));
 const a=await ask([['y','כן','y'],['n','לא','n'],['again','נגן שוב','o']]);
 if(a==='again')return tSpk();
 if(a==='y')return set('spk','ok','שמעת את הצלצול');
 set('spk','bad','לא שמעת צלצול',heard?'המיקרופון כן קלט משהו: כנראה המגבר עובד – בדוק את חוטי הרמקול במסוף הבורג של המגבר (כבל 14).':'בדוק קודם חשמל למגבר (כבל 18), אחר כך BCLK/LRC/DIN, ואז את חוטי הרמקול.');
}
async function tBuz(){
 show('באזר','מצפצף 3 פעמים מהבאזר…');await post('/api/check/beep?dev=buz');await sl(1700);
 show('באזר','<b>שמעת 3 צפצופים מהבאזר?</b>');
 const a=await ask([['y','כן','y'],['n','לא','n'],['again','שוב','o']]);
 if(a==='again')return tBuz();
 if(a==='y')return set('buz','ok','שמעת את הצפצופים');
 set('buz','bad','לא שמעת צפצוף','אם הבאזר מצפצף כל הזמן מרגע ההדלקה – VCC מחובר ל-5V במקום 3V3.');
}
async function tLed(id,c,name,css){
 show('נורה','הנורה מהבהבת עכשיו… <br><b>היא מהבהבת ב<span class="dot" style="background:'+css+'"></span>'+name+'?</b>');
 await post('/api/check/led?c='+c);
 const a=await ask([['y','כן','y'],['n','לא','n'],['again','שוב','o']]);
 await post('/api/check/led?c=off');
 if(a==='again')return tLed(id,c,name,css);
 if(a==='y')return set(id,'ok','ראית '+name);
 set(id,'bad','לא ראית '+name,'אם אף צבע לא נדלק – בדוק קודם את ה-GND של הנורה (כבל 27).');
}
async function tIr(){
 show('חיישן IR במגלשה','',true);skipBtn();
 let s=await st();
 if(s.ir.blocked){lv('החיישן אומר "חסום" כבר עכשיו. הוצא כל דבר שמול החיישן…');
  const c=await waitFor(x=>!x.ir.blocked,10000,(x,l)=>lv('החיישן אומר "חסום". הוצא כל דבר שמולו ('+l+' שנ׳)'));
  if(c==='skip')return set('ir','skip');
  if(!c)return set('ir','bad','החיישן אומר "חסום" כל הזמן','סובב את הבורג הקטן (הפוטנציומטר) על החיישן נגד כיוון השעון, ובדוק VCC ל-3V3.');}
 await post('/api/check/reset?what=ir');
 box.querySelector('div').innerHTML='<b>שים אצבע או פיסת נייר מול החיישן במגלשה (2–3 ס״מ), ואז הורד.</b><div class="mut">כשהוא מרגיש, נדלקת עליו נורית קטנה.</div>';
 const r=await waitFor(x=>x.ir.seen,20000,(x,l)=>lv('עכשיו: '+(x.ir.blocked?'חסום':'פנוי')+' · מחכה ('+l+' שנ׳)'));
 if(r==='skip')return set('ir','skip');
 if(r)return set('ir','ok','הלוח הרגיש את החסימה');
 show('חיישן IR במגלשה','לא הרגשתי חסימה. לנסות שוב?');
 const a=await ask([['again','נסה שוב','y'],['no','לא, המשך','o']]);
 if(a==='again')return tIr();
 set('ir','bad','הלוח לא הרגיש חסימה','אם הנורית על החיישן נדלקת אבל הלוח לא מרגיש – בדוק OUT (GPIO32). אם הנורית לא נדלקת – בדוק VCC/GND וסובב את הבורג הקטן.');
}
async function tMot(id,w){
 const name=w?'גלגל האוכל (ימין)':'גלגל החטיפים (שמאל)';
 let s=await st();
 if(s.cleaning){show('מנוע','המתקן במצב ניקוי, אז המנוע נעול. לסיים ניקוי?');const a=await ask([['y','סיים ניקוי','y'],['n','דלג','o']]);if(a==='n')return set(id,'skip','המתקן היה במצב ניקוי');await post('/api/clean-done');await sl(1500)}
 show('מנוע – '+name,'המנוע יסובב את '+name+' חצי סיבוב (כ-6–10 שניות).<div class="mut">אם יש אוכל/חטיפים במיכל, תיפול מנה אחת – זה בסדר. אם המתקן עוד לא מורכב, תסתכל על הציר של המנוע ועל 4 הנורות האדומות בלוח ה-ULN2003.</div>',true);
 const b=await waitFor(x=>!x.busy,20000,(x,l)=>lv('מחכה שהמנוע יתפנה…'));
 if(!b||b==='skip')return set(id,'warn','המנוע היה עסוק, לא נבדק','נסה שוב בעוד דקה.');
 const p=await post('/api/check/motor?w='+w);
 if(!p.ok)return set(id,'warn','המתקן סירב להזיז את המנוע ('+(p.err||p.http)+')','נסה שוב בעוד דקה.');
 const d0=p.drops||0;
 const e=await waitFor(x=>!x.busy,30000,(x,l)=>lv('המנוע מסתובב…'));
 const drops=e&&e.ir?e.ir.drops-d0:0;
 show('מנוע – '+name,'<b>ראית את '+name+' (או את ציר המנוע) מסתובב?</b>'+(drops>0?'<div class="mut">(החיישן במגלשה גם ראה '+drops+' נפילות)</div>':''));
 let a=await ask([['y','כן','y'],['n','לא','n'],['again','שוב','o']]);
 if(a==='again')return tMot(id,w);
 if(a==='y')return set(id,'ok','ראית אותו מסתובב');
 show('מנוע','<b>ראית את 4 הנורות האדומות הקטנות על לוח ה-ULN2003 מהבהבות?</b>');
 a=await ask([['y','כן, הבהבו','y'],['n','לא','n']]);
 if(a==='y')return set(id,'bad','הדרייבר קיבל פקודות אבל המנוע לא זז','בדוק את התקע הלבן של המנוע (כבל 7) שנכנס עד הסוף, ושגלגלי השיניים לא תקועים.'+(w&&R.motA&&R.motA.s==='ok'?' כיוון A עבד, אז החשמל בסדר – כנראה בעיה במצמד של גלגל האוכל.':''));
 set(id,'bad','הדרייבר לא קיבל פקודות','בדוק חשמל ל-ULN2003 (כבלים 12, 13) ואז IN1–IN4 (כבלים 8–11).');
}
async function tCam(){
 show('מצלמה','שואל את המצלמה בוויי-פיי לתמונה אחת…');
 let r;try{r=await (await fetch('/api/check/cam')).json()}catch(e){r={ok:false}}
 if(r.err==='nohost')return set('cam','skip','לא הוזנה כתובת מצלמה בהגדרות','בדף הראשי → הגדרות → כתובת מצלמה (למשל dogcam.local). אחרי שהמצלמה צרובה ומחוברת לוויי-פיי, הרץ שוב.');
 if(r.ok)return set('cam','ok','המצלמה ענתה עם תמונה ('+Math.round(r.bytes/1024)+' KB)');
 set('cam','bad','המצלמה לא ענתה (כתובת: '+(r.host||'?')+')','בדוק שהנורה האדומה הקטנה במצלמה דולקת (חשמל, כבלים 5–6), שהמצלמה צרובה ומחוברת לאותו וויי-פיי, ושהכתובת בהגדרות נכונה.');
}
async function tOut(){
 show('יחידה חיצונית','היחידה החיצונית (ESP32-C3 במרפסת) כבר מחוברת ודולקת?');
 const a=await ask([['y','כן, בדוק','y'],['n','עוד לא – דלג','o']]);
 if(a==='n'){['out','outmic','outpir'].forEach(i=>set(i,'skip','דילגת – היחידה החיצונית עוד לא מחוברת'));return}
 await post('/api/check/reset?what=out');
 show('יחידה חיצונית','מחכה לאות מהיחידה החיצונית. היא שולחת "אני חי" כל 30 שניות (ואחרי הדלקה יש עוד 30 שניות חימום).',true);skipBtn();
 let s=await st();
 let r=(s.out.age>=0&&s.out.age<35)?s:await waitFor(x=>x.out.pkts>=1||x.out.badTok>0,75000,(x,l)=>lv('מחכה ('+l+' שנ׳)'));
 if(r==='skip'){['out','outmic','outpir'].forEach(i=>set(i,'skip'));return}
 if(!r){set('out','bad','לא הגיע שום אות מהיחידה החיצונית','בדוק שהסוללה טעונה והחשמל ל-C3 מגיע לפין 5V (כבל 34), ושהיחידה צרובה עם אותו טוקן. שים אותה קרוב לבדיקה.');set('outmic','skip','לא נבדק – אין אות מהיחידה');set('outpir','skip','לא נבדק – אין אות מהיחידה');return}
 if(r.out.pkts==0&&r.out.badTok>0){set('out','bad','היחידה החיצונית שולחת, אבל עם טוקן אחר','צריך לצרוב את היחידה החיצונית עם אותו טוקן שמופיע בהגדרות המתקן.');set('outmic','skip');set('outpir','skip');return}
 set('out','ok','הגיע אות מהיחידה החיצונית');
 lv('בודק את המיקרופון החיצוני – מחכה לעוד אות (עד 40 שנ׳)…');
 r=await waitFor(x=>x.out.pkts>=2,40000,(x,l)=>lv('בודק את המיקרופון החיצוני ('+l+' שנ׳)'))||await st();
 if(r!=='skip'){const o=r.out,hi=o.pkts?o.lvlMax:o.lvl,lo=o.pkts?o.lvlMin:o.lvl;
  if(hi<=15)set('outmic','bad','המיקרופון החיצוני מחזיר רק שקט מוחלט = לא מחובר','בדוק VDD ל-3V3 ו-GND, אחר כך SD (GPIO6).');
  else if(lo>100)set('outmic','bad','מהמיקרופון החיצוני מגיע רק רעש לא הגיוני','בדוק ש-SCK/WS/SD יושבים טוב.');
  else if(hi>20&&hi<100)set('outmic','ok','היחידה מדווחת רמת קול אמיתית ('+hi.toFixed(0)+' dB)');
  else set('outmic','warn','רמת הקול מהיחידה לא ברורה ('+hi.toFixed(0)+' dB)','הרץ שוב בעוד דקה.');
 } else set('outmic','skip');
 show('חיישן תנועה חיצוני','<b>נפנף יד מול חיישן התנועה של היחידה החיצונית.</b>',true);skipBtn();
 const p0=(await st()).out.pir;
 r=await waitFor(x=>x.out.pir>p0,30000,(x,l)=>lv('מחכה לתנועה ('+l+' שנ׳)'));
 if(r==='skip')return set('outpir','skip');
 if(r)return set('outpir','ok','הלוח קיבל "תנועה" מהיחידה החיצונית');
 set('outpir','bad','לא הגיע אות תנועה','בדוק OUT (GPIO3), + ל-3V3 ו-GND. אחרי הדלקה החיישן צריך כ-30 שניות חימום.');
}
async function tPir(){
 show('חיישן תנועה במתקן (HC-SR501, לא חובה)','חיברת חיישן תנועה HC-SR501 למתקן עצמו (GPIO27)? הוא לא חובה: הוא רק מוסיף "תנועה ליד המתקן" כטריגר. הוא לא בטבלת החיווט – רק אם הוספת.');
 const a=await ask([['y','כן, בדוק','y'],['n','לא חיברתי','o']]);
 if(a==='n')return set('pir','skip','לא חובר. זה בסדר, הוא לא חובה.');
 await post('/api/check/reset?what=pir');
 show('חיישן תנועה במתקן','<b>זוז מהחיישן, חכה 5 שניות, ואז נפנף מולו יד.</b><div class="mut">HC-SR501 צריך עד דקה חימום אחרי הדלקה.</div>',true);skipBtn();
 const r=await waitFor(x=>x.pir.seen,40000,(x,l)=>lv('עכשיו: '+(x.pir.high?'תנועה':'שקט')+' · מחכה ('+l+' שנ׳)'+(x.pir.up<60?' · עדיין בחימום':'')));
 if(r==='skip')return set('pir','skip');
 if(r)return set('pir','ok','הלוח הרגיש תנועה');
 set('pir','bad','הלוח לא הרגיש תנועה','סובב את בורג הזמן (Tx) למינימום, וודא שהג׳מפר על H.');
}

// ---------------------------------------------------------------- flow + results
const ORDER=[['board',tBoard],['mic',tMic],['spk',tSpk],['buz',tBuz],['ledr',()=>tLed('ledr','r','אדום','#e33')],['ledg',()=>tLed('ledg','g','ירוק','#2b5')],['ledb',()=>tLed('ledb','b','כחול','#36f')],['ir',tIr],['motA',()=>tMot('motA',0)],['motB',()=>tMot('motB',1)],['cam',tCam],['out',tOut],['pir',tPir]];
W.motB={t:'מנוע – גלגל אוכל (כיוון B)',c:W.motA.c};
const ALL=['board','mic','spk','buz','ledr','ledg','ledb','ir','motA','motB','cam','out','outmic','outpir','pir'];
function pg(i){document.getElementById('pg').style.width=Math.round(100*i/ORDER.length)+'%'}
async function runAll(){
 document.getElementById('resBox').style.display='none';
 for(let i=0;i<ORDER.length;i++){pg(i);const[id,fn]=ORDER[i];try{await fn()}catch(e){if(!R[id])set(id,'warn','הבדיקה נתקעה ('+e+')','רענן את הדף ונסה שוב.')}}
 pg(ORDER.length);await post('/api/check/reset?what=stop');results();
}
function bd(s){if(!/[\u0590-\u05FF]/.test(s))return '<bdi dir="ltr">'+s+'</bdi>';return '<bdi dir="rtl">'+s.replace(/[A-Za-z0-9"][A-Za-z0-9"+\-\/ .]*[A-Za-z0-9"]|[A-Za-z0-9]/g,m=>'<span class="lr">'+m+'</span>')+'</bdi>'}
function fixHtml(id){const w=W[id];if(!w)return'';let h='<table>';w.c.forEach(([n,fr,to,ty,co])=>{const cs=co.split('/')[0].trim();h+='<tr><td>'+(isNaN(n)?n:'#'+n)+'</td><td><b>'+bd(fr)+' ← '+bd(to)+'</b><br><span class="mut">'+ty+'</span></td><td>'+(COL[cs]?'<span class="dot" style="background:'+COL[cs]+'"></span>':'')+co+'</td></tr>'});return h+'</table>'}
function results(){
 const ic={ok:'עובד',bad:'לא עובד',warn:'לא בטוח',skip:'לא נבדק'};
 const n=k=>ALL.filter(i=>R[i]&&R[i].s===k).length;
 show(n('bad')?'יש '+n('bad')+' חלקים לבדוק':'סיימנו!', n('ok')+' עובד · '+n('bad')+' לא עובד · '+n('warn')+' לא בטוח · '+n('skip')+' לא נבדק<div class="mut">"עובד" רק מה שבאמת נבדק (על ידי הלוח או על ידך). צבעי הכבלים הם מהמדריך – אם השתמשת בצבעים אחרים, תסתכל על שם הפין.</div>');
 ask([['again','בדוק הכל מחדש','o']]).then(()=>{for(const k in R)delete R[k];runAll()});
 const rb=document.getElementById('resBox');rb.style.display='block';
 let h='';ALL.forEach(id=>{const r=R[id];if(!r)return;const w=W[id];
  h+='<div class="res"><div class="ic '+r.s+'">'+ic[r.s]+'</div><div style="flex:1"><b>'+w.t+'</b><span class="mut">'+r.why+'</span>';
  if(r.s==='bad'||r.s==='warn'){h+='<div class="fix'+(r.s==='warn'?' w':'')+'">'+(r.tip?'<div>'+r.tip+'</div>':'')+'<div style="margin-top:4px">כבלים לבדוק (בלי חשמל!):</div>'+fixHtml(id)+'</div>'}
  else if(r.s==='skip'&&r.tip){h+='<div class="fix w">'+r.tip+'</div>'}
  const t=ORDER.find(o=>o[0]===id||(id.startsWith('out')&&o[0]==='out'));
  if(r.s!=='ok'&&t)h+='<button class="again" onclick="retest(\''+t[0]+'\')">בדוק שוב את החלק הזה</button>';
  h+='</div></div>'});
 rb.innerHTML='<h2>תוצאות</h2>'+h;
}
async function retest(id){const t=ORDER.find(o=>o[0]===id);document.getElementById('resBox').style.display='none';window.scrollTo(0,0);await t[1]();await post('/api/check/reset?what=stop');results()}
function start(){
 show('בדיקת כל החיבורים','לפני שמתחילים:<ul><li>המתקן מחובר לחשמל ודולק</li><li>הטלפון באותו וויי-פיי</li><li>אתה ליד המתקן, כדי לשמוע, לראות ולנפנף יד</li><li>המגש במקום (אולי תיפול מנה)</li></ul>הבדיקה לוקחת בערך 3–5 דקות. חלק נבדק לבד, ובחלק תתבקש ללחוץ כן/לא.');
 ask([['go','התחל בדיקה','y']]).then(runAll);
}
start();
</script></body></html>
)CHKPAGE";
