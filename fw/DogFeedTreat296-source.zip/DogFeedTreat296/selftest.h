// ---------------------------------------------------------------- v2.9.5: "בדיקת חיבורים" connection self-test
// Page: /check (selftest_page.h). Everything here is additive: the normal feeder logic is untouched, except that while a
// self-test is open (any /api/check/* call in the last 120 s) claps, hand-waves and test beeps are NOT counted as barks or
// outside events, and the RGB LED / speaker / buzzer / motor are driven by the test.
// What the board can really know by itself:   mic data (I2S samples), outdoor node packets (ESP-NOW), camera JPEG over WiFi,
//                                              IR / PIR pin changes (only when YOU block the beam / wave a hand).
// What it cannot know (asks you):             speaker sound, buzzer sound, LED colours, motor/wheel movement.
#include "driver/gpio.h"
#include "selftest_page.h"

uint32_t stLastCallMs = 0;
bool stActive() { return stLastCallMs && (millis() - stLastCallMs) < 120000UL; }
// LED blink owned by the test
char     stLedC = 0;            // 'r' 'g' 'b' or 0
uint32_t stLedUntilMs = 0;
bool stLedBusy() { return stLedC && (int32_t)(stLedUntilMs - millis()) > 0; }
// PIR (main board, GPIO27, optional) and IR (GPIO32) watchers: a real change of the pin is the only proof
bool stPirArmed = false, stPirSawLow = false, stPirSeen = false;
bool stIrArmed = false,  stIrSawClear = false, stIrSeen = false; uint16_t stIrDrops0 = 0;
// buzzer pattern
uint8_t  stBuzLeft = 0; uint32_t stBuzNextMs = 0; bool stBuzOn = false;

void stTouch() { stLastCallMs = millis(); if (!stLastCallMs) stLastCallMs = 1; }

void stTick() {                                    // called from loop()
  uint32_t now = millis();
  if (stLedC) {
    if (stLedBusy()) { bool on = (now % 500) < 300; setRgb(on && stLedC == 'r', on && stLedC == 'g', on && stLedC == 'b'); }
    else { stLedC = 0; setRgb(false, false, false); }
  }
  if (stBuzLeft && (int32_t)(now - stBuzNextMs) >= 0) {
    if (!stBuzOn) { buzzerOn(); stBuzOn = true; stBuzNextMs = now + 250; }
    else { buzzerOff(); stBuzOn = false; stBuzLeft--; stBuzNextMs = now + 250; }
  }
  if (stPirArmed) {
    bool p = digitalRead(PIN_PIR);
    if (!p) stPirSawLow = true;
    else if (stPirSawLow) { stPirSeen = true; stPirArmed = false; }
  }
  if (stIrArmed) {
    bool blocked = digitalRead(PIN_IR) == LOW;
    if (!blocked) stIrSawClear = true;
    else if (stIrSawClear) { stIrSeen = true; stIrArmed = false; }
    if (stIrSawClear && irDrops != stIrDrops0) { stIrSeen = true; stIrArmed = false; }   // a fast block caught by the interrupt
  }
}

void stResetMic() { stMicWin = 0; stMicZeroWin = 0; stMicSameWin = 0; stMicMinDb = 999; stMicMaxDb = -999; stMicSumDb = 0; }
void stResetOut() { stOutPkts = 0; stOutBadTok = 0; stOutPir = 0; stOutLvlMin = 999; stOutLvlMax = -999; }

void handleCheckState() {
  stTouch();
  uint32_t now = millis();
  String j = "{\"ok\":true";
  j += ",\"mic\":{\"win\":" + String(stMicWin) + ",\"zero\":" + String(stMicZeroWin) + ",\"same\":" + String(stMicSameWin);
  j += ",\"db\":" + String(levelDb, 1) + ",\"min\":" + String(stMicMinDb, 1) + ",\"max\":" + String(stMicMaxDb, 1);
  j += ",\"avg\":" + String(stMicWin ? stMicSumDb / stMicWin : 0, 1) + "}";
  j += ",\"ir\":{\"blocked\":" + String(digitalRead(PIN_IR) == LOW ? "true" : "false") + ",\"armed\":" + String(stIrArmed ? "true" : "false");
  j += ",\"sawClear\":" + String(stIrSawClear ? "true" : "false") + ",\"seen\":" + String(stIrSeen ? "true" : "false") + ",\"drops\":" + String(irDrops) + "}";
  j += ",\"pir\":{\"high\":" + String(digitalRead(PIN_PIR) ? "true" : "false") + ",\"armed\":" + String(stPirArmed ? "true" : "false");
  j += ",\"sawLow\":" + String(stPirSawLow ? "true" : "false") + ",\"seen\":" + String(stPirSeen ? "true" : "false") + ",\"up\":" + String(now / 1000) + "}";
  j += ",\"out\":{\"age\":" + String(lastOutdoorSeenMs ? (int32_t)((now - lastOutdoorSeenMs) / 1000) : -1);
  j += ",\"pkts\":" + String(stOutPkts) + ",\"badTok\":" + String(stOutBadTok) + ",\"pir\":" + String(stOutPir);
  j += ",\"lvl\":" + String(outdoorLevel, 1) + ",\"lvlMin\":" + String(stOutLvlMin, 1) + ",\"lvlMax\":" + String(stOutLvlMax, 1) + "}";
  j += ",\"spkOk\":" + String(spkOk ? "true" : "false") + ",\"spkFitted\":" + String(cfg.spkFitted ? "true" : "false");
  j += ",\"fs\":" + String(fsOk ? "true" : "false") + ",\"cam\":" + String(cfg.camHost.length() ? "true" : "false");
  j += ",\"camHost\":\"" + jsonEsc(cfg.camHost) + "\"";
  j += ",\"cleaning\":" + String(cleanOn ? "true" : "false") + ",\"busy\":" + String((motorBusy() || dispBusy() || mealBusy()) ? "true" : "false");
  j += ",\"playing\":" + String(playing ? "true" : "false") + ",\"green\":" + String(PIN_LED_G >= 0 ? "true" : "false");
  j += ",\"fw\":\"2.9.9\",\"ip\":\"" + WiFi.localIP().toString() + "\",\"rssi\":" + String(WiFi.RSSI()) + "}";
  server.send(200, "application/json", j);
}

void handleCheckReset() {                          // POST /api/check/reset?what=mic|ir|pir|out
  stTouch();
  String w = server.arg("what");
  if (w == "mic") stResetMic();
  else if (w == "ir")  { stIrArmed = true; stIrSawClear = false; stIrSeen = false; stIrDrops0 = irDrops; }
  else if (w == "pir") { stPirArmed = true; stPirSawLow = false; stPirSeen = false; }
  else if (w == "out") stResetOut();
  else if (w == "stop") { stIrArmed = false; stPirArmed = false; stLedC = 0; setRgb(false, false, false); stBuzLeft = 0; buzzerOff(); }
  server.send(200, "application/json", "{\"ok\":true}");
}

void handleCheckBeep() {                           // POST /api/check/beep?dev=spk|buz
  stTouch();
  String d = server.arg("dev");
  if (d == "buz") { stBuzLeft = 3; stBuzOn = false; stBuzNextMs = millis(); server.send(200, "application/json", "{\"ok\":true}"); return; }
  // speaker: play the built-in bell even if "speaker fitted" is switched off in the settings (this is a wiring test)
  if (!spkOk || !playQ) { server.send(200, "application/json", "{\"ok\":false,\"err\":\"i2s\"}"); return; }
  PlayReq r; memset(&r, 0, sizeof(r)); strncpy(r.slot, "bell", sizeof(r.slot) - 1); r.vol = 90;
  playing = true;
  bool q = xQueueSend(playQ, &r, 0) == pdTRUE;
  if (!q) playing = false;
  server.send(200, "application/json", String("{\"ok\":") + (q ? "true" : "false") + "}");
}

void handleCheckLed() {                            // POST /api/check/led?c=r|g|b|off  -> blinks that colour for 10 s
  stTouch();
  String c = server.arg("c");
  if (c == "r" || c == "g" || c == "b") { stLedC = c[0]; stLedUntilMs = millis() + 10000; }
  else { stLedC = 0; setRgb(false, false, false); }
  server.send(200, "application/json", "{\"ok\":true}");
}

void handleCheckMotor() {                          // POST /api/check/motor?w=0 (treat wheel, direction A) | 1 (food wheel, direction B)
  stTouch();
  if (cleanOn) { server.send(409, "application/json", "{\"ok\":false,\"err\":\"cleaning\"}"); return; }
  if (motorBusy() || dispBusy() || mealBusy()) { server.send(409, "application/json", "{\"ok\":false,\"err\":\"busy\"}"); return; }
  int w = server.arg("w").toInt() == 1 ? 1 : 0;
#if !USE_SERVO
  activeWheel = w;
  startMotion(1);                                  // exactly one pocket of that wheel = half a turn (clutch model stays exact)
#else
  startMotion(1);
#endif
  server.send(200, "application/json", String("{\"ok\":true,\"drops\":") + irDrops + "}");
}

void handleCheckCam() {                            // GET /api/check/cam -> asks the ESP32-CAM for one photo over WiFi
  stTouch();
  if (cfg.camHost.length() == 0) { server.send(200, "application/json", "{\"ok\":false,\"err\":\"nohost\"}"); return; }
  size_t len = 0; uint8_t* b = grabSnapshot(len);
  bool jpg = b && len > 100 && b[0] == 0xFF && b[1] == 0xD8;
  if (b) free(b);
  server.send(200, "application/json", String("{\"ok\":") + (jpg ? "true" : "false") + ",\"bytes\":" + len + ",\"host\":\"" + jsonEsc(cfg.camHost) + "\"}");
}

void setupSelfTest() {
  gpio_pulldown_en((gpio_num_t)PIN_I2S_SD);        // a loose mic data wire now reads 0 (clear ❌) instead of floating noise
  server.on("/check", HTTP_GET, []() { server.send_P(200, "text/html; charset=utf-8", CHECK_HTML); });
  server.on("/api/check/state", HTTP_GET, handleCheckState);
  server.on("/api/check/reset", HTTP_POST, handleCheckReset);
  server.on("/api/check/beep", HTTP_POST, handleCheckBeep);
  server.on("/api/check/led", HTTP_POST, handleCheckLed);
  server.on("/api/check/motor", HTTP_POST, handleCheckMotor);
  server.on("/api/check/cam", HTTP_GET, handleCheckCam);
}
