#pragma once
// barkml.h — DogTreat v4 on-device bark classifier (candidate from bark-ml2). זיהוי נביחה לפי צורת הקול, לא רק לפי עוצמה.
// Drop-in for v3: same public structs/functions/signatures; shared by DogTreat (ESP32) and DogTreatOutdoor (ESP32-C3).
// No cloud, no libraries.
//
// Pipeline (identical to bark-ml2/barkfeat2.py, which the offline test runs):
//   16 kHz mono, DC-blocked samples, 50 ms windows of 800 samples.
//   Each LOUD window: 3 frames of 256 samples -> Hann -> 256-point FFT (62.5 Hz bins).
//   A burst (loud windows until 100 ms of quiet) accumulates the v3 features (unchanged, BarkFeat.f[0..9]):
//     band energies 300-700 / 700-1500 / 1500-3000 / 3000-6000 Hz (fractions of 125-8000 Hz),
//     bark-band ratio, spectral flatness, zero-crossing rate, onset sharpness, spectral centroid, duration,
//   plus 7 v4 extras from the SAME FFTs (BarkFeat.e[0..6]):
//     narrow-band shares 250-375 / 813-1000 / 1250-1563 / 2375-2938 Hz (log10), spread of flatness across windows,
//     largest frame-to-frame level DROP (dB), most tonal frame (log10 max/mean power, 312-6000 Hz).
//   Default score = tiny MLP (18 inputs -> 12 tanh -> 1 sigmoid, 241 weights) trained on ESC-50 + UrbanSound8K +
//   FSD50K (CC0/CC-BY clips) + rmarcosg/bark-detection bursts (see bark-ml2/NOTES.md).
//   "Learn my dog" template and "not a bark" negatives work on f[0..9] exactly as in v3 (BmTemplate unchanged).
//   Then blended with the template distance, pushed down near user-marked "not a bark" examples,
//   pushed up by repetition (2-5 bursts 0.2-1.5 s apart).
// Storage note: sizeof(BarkFeat) grew 40 -> 68 bytes. BmTemplate is unchanged (saved template survives).
//   Saved "not a bark" blobs from v3 are 24*40 bytes: load them with bmLoadNegs() (accepts both sizes).
#include <Arduino.h>
#include <math.h>

#define BM_NF 10           // v3 features per burst (template / negatives / featJson use these)
#define BM_NE 7            // v4 extra features per burst (default score only)
#define BM_FR 256          // FFT frame
#define BM_MAXNEG 24       // "זה לא היה נביחה" examples kept
#define BM_MAXLEARN 12     // bursts captured by one "הקלט נביחה" session

// feature order (keep in sync with barkfeat.NAMES / barkfeat2.EXT_NAMES)
// 0 log10(duration ms) · 1 b300_700 · 2 b700_1500 · 3 b1500_3000 · 4 b3000_6000 · 5 barkRatio
// 6 flatness · 7 zcr · 8 onset dB/16ms · 9 centroid kHz
static const char* const BM_NAMES[BM_NF] = {"logDur","b300_700","b700_1500","b1500_3000","b3000_6000","barkRatio","flatness","zcr","onsetDb","centroidKHz"};
// extras: 0 log m250_375 · 1 flatSd · 2 dropMaxDb · 3 log m813_1000 · 4 log m2375_2938 · 5 log m1250_1563 · 6 peakMax
static const char* const BM_ENAMES[BM_NE] = {"m250_375","flatSd","dropMaxDb","m813_1000","m2375_2938","m1250_1563","peakMax"};
static const uint8_t BM_MLO[4] = {4, 13, 38, 20};   // bin ranges [lo,hi) of the 4 narrow bands, in BarkFeat.e order 0,3,4,5
static const uint8_t BM_MHI[4] = {6, 16, 47, 25};

// ---- v4 default model (bark-ml2/train_eval.py; inputs = f[0..9], |logDur-BM_DURC|, e[0..6])
#define BM_NI 18
#define BM_NH 12
static const float BM_IMU[BM_NI] = {2.67354f, 0.239772f, 0.213119f, 0.160567f, 0.129943f, 0.613457f, 0.228632f, 0.20891f, 8.52522f, 1.63065f, 0.557371f, -1.73536f, 0.0573399f, 7.33784f, -1.62765f, -1.83194f, -1.61931f, 1.53665f};
static const float BM_ISD[BM_NI] = {0.600717f, 0.243188f, 0.223178f, 0.188826f, 0.186471f, 0.312676f, 0.15405f, 0.127144f, 8.42393f, 1.25261f, 0.355182f, 0.943627f, 0.0455425f, 4.52135f, 0.733379f, 0.699279f, 0.684774f, 0.25469f};
static const float BM_W1[BM_NI * BM_NH] = {-0.324163f, 0.0640658f, -0.359859f, -0.305073f, -0.26282f, 0.697263f, 0.512853f, -0.229204f, 0.0118928f, -0.0439809f, -0.0100518f, 0.95664f, 0.361874f, -0.0682161f, 0.00987421f, -0.102979f, 0.0373473f, -0.119898f, -0.114089f, 0.575082f, 0.208395f, 0.538611f, -0.173803f, -0.0273982f, 0.274821f, -0.0831309f, -0.0780019f, 0.203292f, 0.0570039f, -0.131503f, -0.162233f, -0.054556f, -0.298366f, -0.336812f, -0.0777596f, -0.108853f, 0.12001f, 0.024997f, -0.35449f, 0.0349149f, -0.00276681f, 0.0405134f, 0.22297f, 0.207247f, -0.261705f, -0.314428f, -0.0397308f, 0.0624081f, -0.432f, 0.208355f, -0.0425672f, 0.246959f, -0.0574405f, 1.08475f, 0.47401f, 0.084816f, -0.174332f, 0.284927f, -0.137702f, -0.186183f, 0.558828f, -0.106176f, -0.259397f, 0.0876714f, 0.0666951f, -0.175389f, -0.0702078f, 0.537997f, -0.195331f, -0.0381745f, -0.216665f, -0.0674754f, -0.371483f, 0.0209143f, 0.677597f, 0.0758317f, 0.822445f, -0.991081f, -0.225347f, -0.0165353f, 0.651256f, 0.330398f, 0.159411f, -0.110337f, -0.387268f, 0.393372f, 0.202782f, -0.188994f, 0.275939f, 0.832291f, -0.775982f, 0.368122f, 0.120142f, 0.4562f, -0.789887f, -0.0195308f, 0.125412f, -0.229747f, 0.437573f, -0.591397f, 0.506406f, -0.377305f, -0.345225f, -0.0331748f, 0.574206f, -0.175668f, 0.544388f, 0.0440739f, -0.202802f, 0.0639162f, 0.0132959f, 0.162047f, 0.34214f, 0.189734f, -0.39181f, -0.383224f, -0.387253f, 0.448668f, -0.440121f, 0.162078f, -0.434526f, -0.17372f, 0.260452f, -1.44045f, -0.130594f, -0.205604f, -0.211628f, 0.086565f, -0.0605321f, 0.0912822f, -0.445613f, -0.261751f, -0.123558f, 0.632312f, 0.065605f, 0.329452f, 0.541756f, 0.143132f, 0.273211f, -0.49144f, 0.978947f, 0.274862f, -0.0828054f, -0.354826f, -0.0148111f, -0.0516631f, -0.29079f, 0.0467441f, -0.0675647f, 0.178232f, -0.124963f, 0.168073f, -0.0863688f, -0.230077f, 0.0563079f, -0.562351f, 0.272068f, -0.145826f, -0.792809f, -0.396489f, 0.208814f, 0.182712f, -0.559964f, -0.476994f, 0.482512f, 0.245619f, 0.176819f, -1.26246f, 0.331582f, 0.040947f, -0.259411f, -0.195506f, 0.0926049f, -0.618415f, -0.0208854f, 0.0298526f, -0.245812f, 0.619195f, -0.434394f, -0.111626f, 0.0206782f, 0.534094f, 0.0530445f, -0.201406f, -0.183248f, 0.0705706f, 0.150376f, 0.227578f, 0.272142f, -0.403358f, -0.423685f, -0.115277f, 0.263979f, -1.03278f, 0.022933f, -0.0337578f, 0.258504f, 0.178115f, 0.33402f, -0.152555f, -0.290883f, -0.0540226f, -0.0404814f, 0.061237f, -0.199877f, -0.130736f, -0.809877f, 0.100844f, -0.483664f, 0.205913f, -0.202903f, 0.132461f, -0.205536f, -0.375959f, -0.0874615f, -0.196542f};   // row-major [input][hidden]
static const float BM_B1[BM_NH] = {-0.086641f, 1.32206f, 0.649281f, 0.257241f, -0.0758884f, 0.329489f, 1.40291f, -0.513095f, 0.302665f, -0.481205f, -0.306254f, -2.06948f};
static const float BM_W2[BM_NH] = {-0.989407f, -0.998729f, -0.670161f, 0.90597f, -0.84916f, -1.34933f, 1.1392f, 0.682868f, -1.05734f, 0.983474f, 0.605822f, -1.3225f};
static const float BM_B2 = -1.79316f;
static const float BM_DURC = 2.39794f;   // log10(250 ms), a typical single bark
// core-feature statistics (template floor, distances) — means/spreads of the v4 training bursts
static const float BM_MU[BM_NF]   = {2.67354f, 0.239772f, 0.213119f, 0.160567f, 0.129943f, 0.613457f, 0.228632f, 0.20891f, 8.52522f, 1.63065f};
static const float BM_SD[BM_NF]   = {0.600717f, 0.243188f, 0.223178f, 0.188826f, 0.186471f, 0.312676f, 0.15405f, 0.127144f, 8.42393f, 1.25261f};
static const float BM_BARKMEAN[BM_NF] = {2.54892f, 0.393589f, 0.350154f, 0.118267f, 0.0393978f, 0.86201f, 0.126025f, 0.154007f, 8.53112f, 1.0578f};
static const float BM_TPL_W = 0.6f;      // v4: weight of the default score when a template exists (v3: 0.4)
// v3 logistic model, kept for reference / A-B (not used by bmDefaultScore)
static const float BM_W[BM_NF]    = {-0.761816f, 0.36509f, 0.848588f, 0.133662f, 0.588863f, 1.02726f, -1.35729f, -1.20482f, -0.0622554f, 0.295938f};
static const float BM_WDUR        = -0.972995f;
static const float BM_B           = -1.70005f;

struct BarkFeat { float f[BM_NF]; float e[BM_NE]; };

// One classified burst for the main unit's event list (DogTreat). verdict: 0 bark · 1 noise · 2 maybe · 3 loud&long bark-like · 4 recorded while learning
struct BurstRec { uint16_t id; uint32_t t; uint8_t verdict; uint8_t pct; uint8_t rep; uint8_t fixed; float peak; uint16_t durMs; BarkFeat x; };

struct BmWin {              // one analysed 50 ms window
  float zcr, flat;
  float bands[6];           // b1..b4, total(125-8000), sum(k*P) for the centroid
  float fdb[3];             // frame levels, dB SPL (same scale as the level meter)
  float m[4];               // v4: narrow bands (BM_MLO/BM_MHI)
  float pkMax;              // v4: most tonal frame of the window, log10(max/mean)
};

struct BmBurst {
  float bands[6]; float fl, zc; uint16_t n; float onset; uint8_t onw; float prevDb;
  float m[4]; float flQ; float pkMax; float drop; uint8_t hasPrev;   // v4
};

// Template = running sums so new examples can be added (מוסיף נביחות בלי לאבד את הקודמות)
struct BmTemplate { uint16_t n; float sum[BM_NF]; float sumsq[BM_NF]; };
// ------------------------------------------------------------------ FFT (radix-2, in place)
static float bm_re[BM_FR], bm_im[BM_FR], bm_hann[BM_FR], bm_cos[BM_FR / 2], bm_sin[BM_FR / 2];
static bool bm_ready = false;
static void bmInit() {
  if (bm_ready) return;
  for (int i = 0; i < BM_FR; i++) bm_hann[i] = 0.5f - 0.5f * cosf(2.0f * PI * i / (BM_FR - 1));
  for (int i = 0; i < BM_FR / 2; i++) { bm_cos[i] = cosf(2.0f * PI * i / BM_FR); bm_sin[i] = -sinf(2.0f * PI * i / BM_FR); }
  bm_ready = true;
}
static void bmFft() {
  for (int i = 1, j = 0; i < BM_FR; i++) {                 // bit reversal
    int bit = BM_FR >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit;
    if (i < j) { float t = bm_re[i]; bm_re[i] = bm_re[j]; bm_re[j] = t; t = bm_im[i]; bm_im[i] = bm_im[j]; bm_im[j] = t; }
  }
  for (int len = 2; len <= BM_FR; len <<= 1) {
    int half = len >> 1, step = BM_FR / len;
    for (int i = 0; i < BM_FR; i += len)
      for (int k = 0; k < half; k++) {
        float wr = bm_cos[k * step], wi = bm_sin[k * step];
        float xr = bm_re[i + k + half] * wr - bm_im[i + k + half] * wi;
        float xi = bm_re[i + k + half] * wi + bm_im[i + k + half] * wr;
        bm_re[i + k + half] = bm_re[i + k] - xr; bm_im[i + k + half] = bm_im[i + k] - xi;
        bm_re[i + k] += xr; bm_im[i + k] += xi;
      }
  }
}

// level of one 256-sample frame, dB SPL on the firmware's scale (24-bit full scale = 120 dB)
static float bmFrameDb(const float* y) {
  double e = 0; for (int i = 0; i < BM_FR; i++) e += (double)y[i] * y[i];
  e /= BM_FR; if (e < 1.0) e = 1.0;
  return 10.0f * log10f((float)(e / (8388608.0 * 8388608.0))) + 120.0f;
}

// Analyse one window (n >= 768 samples). ~3 FFTs: about 1 ms on an ESP32, a few ms on a C3 (no FPU).
static void bmAnalyze(const float* y, int n, BmWin& w) {
  bmInit();
  int zc = 0; for (int i = 1; i < n; i++) if ((y[i] >= 0) != (y[i - 1] >= 0)) zc++;
  w.zcr = (float)zc / (n - 1);
  for (int b = 0; b < 6; b++) w.bands[b] = 0;
  for (int b = 0; b < 4; b++) w.m[b] = 0;
  w.flat = 0; w.pkMax = 0;
  for (int f = 0; f < 3; f++) {
    const float* s = y + f * BM_FR;
    w.fdb[f] = bmFrameDb(s);
    for (int i = 0; i < BM_FR; i++) { bm_re[i] = s[i] * bm_hann[i]; bm_im[i] = 0; }
    bmFft();
    double lsum = 0, psum = 0; float pmax = 0;
    for (int k = 2; k < 128; k++) {
      float P = bm_re[k] * bm_re[k] + bm_im[k] * bm_im[k] + 1.0f;
      if (k >= 5 && k < 12) w.bands[0] += P;
      else if (k >= 12 && k < 24) w.bands[1] += P;
      else if (k >= 24 && k < 48) w.bands[2] += P;
      else if (k >= 48 && k < 96) w.bands[3] += P;
      w.bands[4] += P; w.bands[5] += k * P;
      if (k >= 5 && k < 96) { lsum += logf(P); psum += P; if (P > pmax) pmax = P; }
      for (int b = 0; b < 4; b++) if (k >= BM_MLO[b] && k < BM_MHI[b]) w.m[b] += P;
    }
    const int nf = 96 - 5;
    w.flat += expf((float)(lsum / nf)) / (float)(psum / nf);
    float pk = log10f(pmax / (float)(psum / nf)); if (pk > w.pkMax) w.pkMax = pk;
  }
  w.flat /= 3.0f;
}

static void bmBurstStart(BmBurst& b, float prevFrameDb, bool continued = false) {
  memset(&b, 0, sizeof(b)); b.prevDb = prevFrameDb; b.onw = continued ? 2 : 0; b.hasPrev = 1;
}
static void bmBurstAdd(BmBurst& b, const BmWin& w) {
  for (int i = 0; i < 6; i++) b.bands[i] += w.bands[i];
  for (int i = 0; i < 4; i++) b.m[i] += w.m[i];
  b.fl += w.flat; b.flQ += w.flat * w.flat; b.zc += w.zcr; b.n++;
  if (w.pkMax > b.pkMax) b.pkMax = w.pkMax;
  if (b.onw < 2) {                                         // onset: first 100 ms of the burst
    float p = b.prevDb;
    for (int f = 0; f < 3; f++) { float r = w.fdb[f] - p; if (r > b.onset) b.onset = r; p = w.fdb[f]; }
    b.onw++;
  }
  { float p = b.prevDb;                                    // v4: largest frame-to-frame drop inside the burst
    for (int f = 0; f < 3; f++) { if (b.hasPrev) { float d = p - w.fdb[f]; if (d > b.drop) b.drop = d; } p = w.fdb[f]; b.hasPrev = 1; } }
  b.prevDb = w.fdb[2];
}
static void bmBurstFinish(const BmBurst& b, uint32_t durMs, BarkFeat& o) {
  float tot = b.bands[4] > 1 ? b.bands[4] : 1; float n = b.n ? b.n : 1;
  o.f[0] = log10f((float)(durMs < 50 ? 50 : durMs));
  o.f[1] = b.bands[0] / tot; o.f[2] = b.bands[1] / tot; o.f[3] = b.bands[2] / tot; o.f[4] = b.bands[3] / tot;
  o.f[5] = (b.bands[0] + b.bands[1] + b.bands[2]) / tot;
  o.f[6] = b.fl / n; o.f[7] = b.zc / n; o.f[8] = b.onset;
  o.f[9] = b.bands[5] / tot * 62.5f / 1000.0f;
  float mf = b.fl / n, v = b.flQ / n - mf * mf;
  o.e[0] = log10f(b.m[0] / tot + 1e-4f);
  o.e[1] = sqrtf(v > 0 ? v : 0);
  o.e[2] = b.drop;
  o.e[3] = log10f(b.m[1] / tot + 1e-4f);
  o.e[4] = log10f(b.m[2] / tot + 1e-4f);
  o.e[5] = log10f(b.m[3] / tot + 1e-4f);
  o.e[6] = b.pkMax;
}

// ------------------------------------------------------------------ scoring
static float bmSigmoid(float z) { return 1.0f / (1.0f + expf(-z)); }
static float bmDefaultScore(const BarkFeat& x) {
  float in[BM_NI];
  for (int i = 0; i < BM_NF; i++) in[i] = x.f[i];
  in[BM_NF] = fabsf(x.f[0] - BM_DURC);
  for (int i = 0; i < BM_NE; i++) in[BM_NF + 1 + i] = x.e[i];
  float h[BM_NH];
  for (int j = 0; j < BM_NH; j++) h[j] = BM_B1[j];
  for (int i = 0; i < BM_NI; i++) {
    float z = (in[i] - BM_IMU[i]) / BM_ISD[i];
    const float* w = BM_W1 + i * BM_NH;
    for (int j = 0; j < BM_NH; j++) h[j] += z * w[j];
  }
  float o = BM_B2;
  for (int j = 0; j < BM_NH; j++) o += tanhf(h[j]) * BM_W2[j];
  return bmSigmoid(o);
}
// v3 logistic score on f[0..9] (reference only)
static float bmLegacyScore(const BarkFeat& x) {
  static const float mu[BM_NF] = {2.56825f, 0.261498f, 0.213695f, 0.169888f, 0.139097f, 0.645082f, 0.21838f, 0.234975f, 12.7918f, 1.66671f}, sd[BM_NF] = {0.536799f, 0.243574f, 0.217959f, 0.188567f, 0.19445f, 0.291153f, 0.141349f, 0.123727f, 8.78641f, 1.20539f};
  float z = BM_B;
  for (int i = 0; i < BM_NF; i++) z += BM_W[i] * (x.f[i] - mu[i]) / sd[i];
  z += BM_WDUR * fabsf(x.f[0] - BM_DURC);
  return bmSigmoid(z);
}
static void bmTplStats(const BmTemplate& t, float* mean, float* sd) {
  for (int i = 0; i < BM_NF; i++) {
    float m = t.sum[i] / t.n, v = t.sumsq[i] / t.n - m * m;
    mean[i] = m; sd[i] = sqrtf(v > 0 ? v : 0);
    float floorSd = 0.35f * BM_SD[i];                     // a few examples must not make a razor-thin template
    if (sd[i] < floorSd) sd[i] = floorSd;
  }
}
static void bmTplAdd(BmTemplate& t, const BarkFeat& x) {
  for (int i = 0; i < BM_NF; i++) { t.sum[i] += x.f[i]; t.sumsq[i] += x.f[i] * x.f[i]; }
  t.n++;
}
static float bmDist(const BarkFeat& x, const float* mean, const float* sd) {
  float s = 0; for (int i = 0; i < BM_NF; i++) { float d = (x.f[i] - mean[i]) / sd[i]; s += d * d; }
  return sqrtf(s / BM_NF);
}
static const uint8_t BM_TPL_MIN = 3;    // template used from 3 recorded barks

// p0 = default score; returns the final bark probability 0..0.99
static float bmScore(const BarkFeat& x, float p0, const BmTemplate* tpl, const BarkFeat* negs, int negN, int rep) {
  float mean[BM_NF], sd[BM_NF]; float p = p0, dB;
  if (tpl && tpl->n >= BM_TPL_MIN) {
    bmTplStats(*tpl, mean, sd);
    dB = bmDist(x, mean, sd);
    p = BM_TPL_W * p0 + (1.0f - BM_TPL_W) * bmSigmoid(-1.5f * (dB - 2.0f));   // within ~2 spreads of your dog's bark -> high
  } else {
    for (int i = 0; i < BM_NF; i++) { mean[i] = BM_BARKMEAN[i]; sd[i] = BM_SD[i]; }
    dB = bmDist(x, mean, sd);
  }
  if (negs && negN > 0) {                                     // close to something you said was NOT a bark -> down
    float dN = 1e9f;
    for (int k = 0; k < negN; k++) { float d = bmDist(x, negs[k].f, sd); if (d < dN) dN = d; }
    float r = dN / (dN + dB + 1e-6f); float m = 2.0f * r; if (m > 1.0f) m = 1.0f;
    p *= m;
  }
  p += 0.07f * (rep > 3 ? 3 : rep);
  if (p < 0) p = 0; if (p > 0.99f) p = 0.99f;
  return p;
}

// Repetition: barks usually come in runs of 2-5, 0.2-1.5 s apart.
struct BmRep { uint32_t t[8]; float p[8]; uint8_t head; };
static int bmRepCount(const BmRep& r, uint32_t start) {
  int n = 0; uint32_t t = start;
  for (int k = 0; k < 8; k++) {
    int i = (r.head + 7 - k) % 8;
    if (!r.t[i]) break;
    uint32_t dt = t - r.t[i];
    if (dt > 1500) break;
    if (dt >= 200 && r.p[i] >= 0.4f) { n++; t = r.t[i]; }
  }
  return n;
}
static void bmRepPush(BmRep& r, uint32_t start, float p0) { r.t[r.head] = start ? start : 1; r.p[r.head] = p0; r.head = (r.head + 1) % 8; }

// sensitivity: 0 קפדני (strict) · 1 רגיל (normal) · 2 רגיש (sensitive)
static float bmThreshold(uint8_t sens) { return sens == 0 ? 0.65f : sens == 2 ? 0.35f : 0.50f; }
static float bmGateOffsetDb(uint8_t sens) { return sens == 0 ? 0.0f : sens == 2 ? -8.0f : -4.0f; }
static const float BM_MAYBE_BAND = 0.20f;   // [thr-0.2, thr): "maybe a bark" -> no treat, not counted

// v4: load saved "not a bark" examples written by v3 (24 x 40 bytes) or v4 (24 x 68 bytes).
// Usage in bmLoad():  size_t L = prefs.getBytesLength("neg"); uint8_t* tmp = (uint8_t*)malloc(L);
//   prefs.getBytes("neg", tmp, L); if (bmLoadNegs(tmp, L, bmNeg)) {...negN/negH...} free(tmp);
static bool bmLoadNegs(const uint8_t* buf, size_t len, BarkFeat* out) {
  if (len == sizeof(BarkFeat) * BM_MAXNEG) { memcpy(out, buf, len); return true; }
  if (len == sizeof(float) * BM_NF * BM_MAXNEG) {          // v3 blob: features only; extras unused for negatives
    for (int k = 0; k < BM_MAXNEG; k++) { memcpy(out[k].f, buf + k * sizeof(float) * BM_NF, sizeof(float) * BM_NF); for (int i = 0; i < BM_NE; i++) out[k].e[i] = 0; }
    return true;
  }
  return false;
}
