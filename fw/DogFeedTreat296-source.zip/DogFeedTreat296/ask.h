#pragma once
// ---------------------------------------------------------------- v2.9.7: "כשהוא לא בטוח" — the feeder asks you
// A burst whose bark score lands in the "לא בטוח" zone [bark threshold - askBand, bark threshold) gets NO treat and
// is not counted as a bark (same as the old "maybe" verdict 2). Now it also asks:
//   * web page: a card "שמעתי משהו — זו הייתה נביחה?" built from /api/bursts (verdict 2, not answered yet)
//   * phone (optional): one ntfy.sh push with כן / לא buttons that call the existing /api/bark-label
//     (כן -> adds the sound to the "learn my dog" template, לא -> adds it to the "not a bark" examples).
// The push is sent from its own short FreeRTOS task with 4 s timeouts, so sound, treats and meals never wait for it.
// Limits: one push per 2 minutes, 20 per day, only while connected to the home Wi-Fi. No account, no key:
// the topic is a random name made once on this board and kept in its settings (NVS).
// Kept outside barkml.h on purpose: barkml.h's public API is unchanged.

static const uint32_t ASK_GAP_MS  = 120000UL;   // at most one push per 2 minutes
static const uint8_t  ASK_MAX_DAY = 20;         // at most 20 pushes per day
uint32_t askLastPushMs = 0;                     // when the last question push started (0 = never)
uint8_t  askDayN = 0; int32_t askDayK = -2147483647;
volatile bool askBusy = false;                  // a push is being sent right now
volatile int  askLastCode = 0;                  // ntfy's HTTP answer to the last push (200 = sent; <0 = no connection)
volatile uint32_t askDoneMs = 0;                // when that answer came
uint8_t  askLastKind = 0;                       // 0 none · 1 question · 2 test
uint8_t  askLastSkip = 0;                       // why the last question was NOT pushed: 0 - · 1 off · 2 no Wi-Fi · 3 2-min gap · 4 day max · 5 busy/low memory
uint16_t askPendId = 0; uint8_t askPendPct = 0; // queued by classifyBurst, sent from loop()
uint32_t askPingMs = 0; uint8_t askPingAns = 0; // the test push's button reached the feeder (phone -> feeder works)
String   askJob;                                // JSON body for the push task

float askBandF() { return cfg.askBand / 100.0f; }

String askNewTopic() {
  const char* a = "abcdefghijkmnpqrstuvwxyz23456789";
  uint64_t mac = ESP.getEfuseMac();
  String t = "dogtreat-";
  for (int i = 0; i < 10; i++) { uint32_t r = esp_random() ^ (uint32_t)(mac >> (i * 4)) ^ (uint32_t)micros(); t += a[r % 32]; }
  return t;
}
// ntfy topics: letters, digits, - and _ (max 64). Anything else is dropped; empty -> a new random topic.
String askCleanTopic(const String& s) {
  String o; for (char c : s) if (isalnum((uint8_t)c) || c == '-' || c == '_') { if (o.length() < 64) o += c; }
  return o.length() ? o : askNewTopic();
}
void askEnsureTopic() { if (!cfg.ntfyTopic.length()) { cfg.ntfyTopic = askNewTopic(); saveSettings(); } }

String askJ(const String& s) {            // JSON string escape (quotes, backslash, newlines)
  String o = "\""; for (char c : s) { if (c == '"' || c == '\\') { o += '\\'; o += c; } else if (c == '\n') o += "\\n"; else if ((uint8_t)c >= 32) o += c; }
  return o + "\"";
}
bool askWifiOk() { return WiFi.status() == WL_CONNECTED && (WiFi.getMode() & WIFI_STA); }

void askTask(void*) {
  int code = -1;
  {
    WiFiClientSecure c; c.setInsecure();   // public ntfy.sh, nothing secret in the message
    HTTPClient h; h.setConnectTimeout(4000); h.setTimeout(4000); h.setReuse(false);
    if (h.begin(c, "https://ntfy.sh/")) {
      h.addHeader("Content-Type", "application/json");
      code = h.POST(askJob);
      h.end();
    }
  }
  askLastCode = code; askDoneMs = millis(); askBusy = false;
  Serial.printf("[ask] ntfy %d\n", code);
  vTaskDelete(nullptr);
}
bool askStart(const String& json, uint8_t kind) {
  if (askBusy || ESP.getFreeHeap() < 50000) return false;
  askJob = json; askBusy = true; askLastKind = kind;
  if (xTaskCreatePinnedToCore(askTask, "ask", 10240, nullptr, 1, nullptr, 0) != pdPASS) { askBusy = false; return false; }
  return true;
}
// ntfy JSON publish with two http buttons. The buttons use the feeder's IP (phones resolve it more reliably than
// dogtreat.local); they work only while the phone is on the home Wi-Fi.
String askBody(const String& title, const String& msg, const String& yesUrl, const String& noUrl, const String& tag = "") {   // v2.9.8: + tag (e.g. "sid-12" = sound id, for the feeder app)
  String base = "http://" + WiFi.localIP().toString();
  String j = "{\"topic\":" + askJ(cfg.ntfyTopic) + ",\"title\":" + askJ(title) + ",\"message\":" + askJ(msg);
  j += ",\"tags\":[\"dog\",\"question\"" + (tag.length() ? "," + askJ(tag) : String("")) + "],\"priority\":4,\"click\":" + askJ(base + "/#ask");
  j += ",\"actions\":[{\"action\":\"http\",\"label\":\"כן\",\"url\":" + askJ(base + yesUrl) + ",\"method\":\"POST\",\"clear\":true}";
  j += ",{\"action\":\"http\",\"label\":\"לא\",\"url\":" + askJ(base + noUrl) + ",\"method\":\"POST\",\"clear\":true}]}";
  return j;
}

// called by classifyBurst for every "לא בטוח" burst (not while recording a bark)
void askNote(uint16_t id, float p) { askPendId = id; askPendPct = (uint8_t)lroundf(p * 100); }

void askTick() {
  if (!askPendId) return;
  uint16_t id = askPendId; uint8_t pct = askPendPct; askPendId = 0;
  if (!cfg.pushOn || !cfg.askPush || !cfg.ntfyTopic.length()) { askLastSkip = 1; return; }
  if (!askWifiOk()) { askLastSkip = 2; return; }
  uint32_t now = millis();
  if (askLastPushMs && now - askLastPushMs < ASK_GAP_MS) { askLastSkip = 3; return; }
  int32_t k = currentDayKey(); if (k < 0) k = -1000 - (int32_t)(now / 86400000UL);
  if (k != askDayK) { askDayK = k; askDayN = 0; }
  if (askDayN >= ASK_MAX_DAY) { askLastSkip = 4; return; }
  String when = "";
  if (clockValid()) { struct tm t; time_t nw = time(nullptr); localtime_r(&nw, &t); char b[8]; strftime(b, sizeof b, "%H:%M", &t); when = String(b) + " · "; }
  String msg = "שמעתי משהו לא בטוח — נביחה?\n" + when + "ציון " + String(pct) + "%";
  String q = "/api/bark-label?id=" + String(id) + "&bark=";
  if (!askStart(askBody("המתקן שואל", msg, q + "1", q + "0", "sid-" + String(id)), 1)) { askLastSkip = 5; return; }
  askLastPushMs = now ? now : 1; askDayN++; askLastSkip = 0;
}

// POST /api/ask-test — "שלח בדיקה": a sample question whose buttons only report back (/api/ask-ping)
void handleAskTest() {
  const char* why = nullptr;
  if (!cfg.ntfyTopic.length()) why = "notopic";
  else if (!askWifiOk()) why = "nowifi";
  else if (!askStart(askBody("המתקן שואל (בדיקה)", "בדיקה: ככה תיראה שאלה.\nלחץ כן או לא כדי לבדוק שהטלפון מגיע למתקן.", "/api/ask-ping?ans=1", "/api/ask-ping?ans=0"), 2)) why = "busy";
  if (why) { server.send(200, "application/json", String("{\"ok\":false,\"why\":\"") + why + "\"}"); return; }
  askPingMs = 0;
  server.send(200, "application/json", "{\"ok\":true}");
}
// POST /api/ask-ping?ans=1|0 — a button of the TEST push was pressed on the phone. Changes nothing else.
void handleAskPing() { askPingMs = millis(); if (!askPingMs) askPingMs = 1; askPingAns = server.arg("ans") == "1"; server.send(200, "application/json", "{\"ok\":true}"); }
// GET /api/ask — state for the settings section
void handleAskState() {
  uint32_t now = millis();
  String j = "{\"busy\":" + String(askBusy ? 1 : 0) + ",\"code\":" + String((int)askLastCode) + ",\"kind\":" + String(askLastKind);
  j += ",\"doneAgo\":" + String(askDoneMs ? (long)((now - askDoneMs) / 1000) : -1L);
  j += ",\"pushAgo\":" + String(askLastPushMs ? (long)((now - askLastPushMs) / 1000) : -1L);
  j += ",\"today\":" + String(askDayN) + ",\"max\":" + String(ASK_MAX_DAY) + ",\"gapS\":" + String(ASK_GAP_MS / 1000);
  j += ",\"skip\":" + String(askLastSkip) + ",\"wifi\":" + String(askWifiOk() ? 1 : 0);
  j += ",\"pingAgo\":" + String(askPingMs ? (long)((now - askPingMs) / 1000) : -1L) + ",\"pingAns\":" + String(askPingAns);
  j += ",\"ip\":\"" + WiFi.localIP().toString() + "\"}";
  server.send(200, "application/json", j);
}
